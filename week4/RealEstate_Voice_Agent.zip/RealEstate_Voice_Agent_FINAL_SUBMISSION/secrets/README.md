Put `google_credentials.json` (OAuth client, downloaded from Google Cloud Console) here, then run
`python scripts/google_auth.py` once. It will write `google_token.json` next to it (auto-refreshing).
Neither file is committed to git (see .gitignore).
