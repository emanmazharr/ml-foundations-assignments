"""Live demo of Step 1: hybrid knowledge engine + context-aware recommendations.
Run:  python scripts/demo_step1.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import engine
from app.db import pkr_words
from app.nlp.entities import parse_utterance
from app.recommender import Profile, recommend

print("=" * 70, "\nPART 1 - Hybrid knowledge engine (SQL + RAG)\n" + "=" * 70)
for q in ["Property 1 ki price kya hai?", "Bahria Town Lahore mein schools kahan hain?",
          "Is property 14 available?", "Property 11 ki installment plan kya hai?",
          "Kya Bahria Town Lahore mein helipad hai?"]:
    o = engine.ask(q)
    print(f"\nCaller : {q}\n[{o['route']}]  {o['answer']}")

print("\n" + "=" * 70, "\nPART 2 - Context memory across turns (Day 3, Task 3)\n" + "=" * 70)
prof = Profile()
turns = ["Budget 3.5 crore hai.", "DHA mein kya options hain? Ghar chahiye.", "Us se sasti koi option?"]
last_top = None
for t in turns:
    e = parse_utterance(t)
    prof = Profile.from_entities(e, prof)
    if e.wants_cheaper and last_top:
        prof.cheaper_than = last_top
    print(f"\nCaller : {t}\n  memory -> budget={pkr_words(prof.budget_max) if prof.budget_max else None}, area={prof.area}, type={prof.ptype}")
    if prof.area or e.wants_cheaper:
        res = recommend(prof, limit=2)
        for m in res["matches"]:
            p = m["property"]
            print(f"  Agent  : Property {p['id']} - {p['title']} @ {pkr_words(p['price_pkr'])} (score {m['score']}) because: {'; '.join(m['reasons'])}")
        if res["relaxed"]:
            print(f"  (relaxed: {res['relaxed']})")
        if res["matches"]:
            prof.remember_choice(res["matches"][0]["property"])
            last_top = prof.cheaper_than
