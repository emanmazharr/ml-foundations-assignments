"""Run a disposable, offline API smoke check: python scripts/smoke_demo_api.py"""
from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
WORK = ROOT / "work" / "api_smoke"
WORK.mkdir(parents=True, exist_ok=True)
os.environ["DATABASE_URL"] = f"sqlite:///{(WORK / 'smoke.db').as_posix()}"
os.environ["VECTOR_BACKEND"] = "numpy"
os.environ["CHROMA_DIR"] = str(WORK / "unused_chroma")
os.environ["KB_DIR"] = str(WORK / "kb")
os.environ["LLM_PROVIDER"] = "mock"
os.environ["CALENDAR_MODE"] = "mock"
os.environ["EMAIL_MODE"] = "mock"
os.environ["OUTBOX_DIR"] = str(WORK / "outbox")
os.environ["STT_PROVIDER"] = "browser"
os.environ["TTS_PROVIDER"] = "browser"

from fastapi.testclient import TestClient  # noqa: E402
from scripts.build_kb import main as build_kb  # noqa: E402

build_kb()

from app.main import app  # noqa: E402

with TestClient(app) as client:
    health = client.get("/health")
    assert health.status_code == 200, health.text
    assert health.json()["status"] == "ok", health.json()

    voice_page = client.get("/demo")
    assert voice_page.status_code == 200 and "UrduLish Property Voice Demo" in voice_page.text
    voice_status = client.get("/voice/status")
    assert voice_status.status_code == 200 and voice_status.json()["browser_demo"] is True
    no_live_tts = client.post("/voice/speak", json={"text": "test"})
    assert no_live_tts.status_code == 503, no_live_tts.text

    started = client.post("/call/start", json={})
    assert started.status_code == 200, started.text
    call_id = started.json()["call_id"]

    turn = client.post("/call/turn", json={
        "call_id": call_id,
        "text": "DHA Lahore mein 3.5 crore tak ghar chahiye",
    })
    assert turn.status_code == 200, turn.text
    assert turn.json()["response"], turn.json()

    property_response = client.get("/properties/1")
    assert property_response.status_code == 200, property_response.text
    print({
        "health": health.json(),
        "call_id": call_id,
        "agent_response": turn.json()["response"],
        "property": property_response.json()["title"],
        "voice_demo": voice_status.json(),
    })
