"""Build the demo knowledge base.

Creates:
  * SQL database  (properties, prices, areas, schools, hospitals, developers,
                   agents, payment plans)         -> structured retrieval
  * data/kb/*.md / faqs.json  (brochures, area guides, developer profiles,
                   policies, FAQs)                -> semantic retrieval (RAG)

IMPORTANT: this is a *synthetic demo dataset* for "RealEstate Hub".
Replace it with the client's real inventory before go-live. Because the
brochures are generated from the same rows as the SQL tables, facts never
contradict each other.

Run:  python scripts/build_kb.py
"""
from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy import insert  # noqa: E402

from app import db  # noqa: E402
from app.config import get_settings  # noqa: E402
from app.db import pkr_words  # noqa: E402

KB = Path(get_settings().kb_dir)

# --------------------------------------------------------------------------- #
# Reference data
# --------------------------------------------------------------------------- #
DEVELOPERS = [
    (1, "Crescent Developers", 2004, "Lahore", "LDA approved", 18,
     "Delivered 18 residential and mixed-use projects on or before the committed date; known for gated-community houses."),
    (2, "Noor Builders", 2010, "Karachi", "SBCA approved", 11,
     "Specialises in mid-range apartment towers with generator backup and secure parking."),
    (3, "Skyline Properties", 2012, "Islamabad", "CDA approved", 9,
     "Boutique developer of premium apartments in Islamabad sectors; strong resale record."),
    (4, "Green Valley Group", 2008, "Lahore", "Society-approved layouts", 14,
     "Develops plots and houses inside large societies with park and mosque provisions."),
    (5, "Metro Heights Pvt Ltd", 2015, "Karachi", "SBCA approved", 7,
     "Commercial plazas and shopping arcades in high-footfall locations."),
]

AGENTS = [
    (1, "Ahmed Raza", "ahmed.raza@realestatehub.example", "+92-300-1111001", "Lahore", "Urdu, English, Punjabi"),
    (2, "Sana Malik", "sana.malik@realestatehub.example", "+92-300-1111002", "Lahore", "Urdu, English"),
    (3, "Bilal Hussain", "bilal.hussain@realestatehub.example", "+92-321-2222001", "Karachi", "Urdu, English, Sindhi"),
    (4, "Ayesha Siddiqui", "ayesha.siddiqui@realestatehub.example", "+92-321-2222002", "Karachi", "Urdu, English"),
    (5, "Usman Tariq", "usman.tariq@realestatehub.example", "+92-333-3333001", "Islamabad", "Urdu, English, Pashto"),
    (6, "Hira Farooq", "hira.farooq@realestatehub.example", "+92-333-3333002", "Islamabad", "Urdu, English"),
]

# key -> (id, area name, city, summary, [(school, level, km)], [(hospital, speciality, km)])
AREAS = {
    "dha6": (1, "DHA Phase 6", "Lahore",
             "A well-planned, gated, premium residential phase with wide roads, parks, commercial belts and 24/7 security.",
             [("Iqra Grammar School", "Primary-Secondary", 1.2), ("City Foundation College", "Secondary-A Levels", 2.0)],
             [("Meraj Care Hospital", "General & Emergency", 2.5), ("Noor Children Hospital", "Paediatrics", 3.4)]),
    "gulberg": (2, "Gulberg III", "Lahore",
                "Central business and lifestyle hub with high-rise apartments, offices, cafes and easy access to the main boulevard.",
                [("Lahore Model Academy", "Primary-Matric", 1.0), ("Gulberg Girls College", "College", 1.6)],
                [("Shifa Central Hospital", "General & Emergency", 1.4), ("Heart Care Institute", "Cardiology", 2.8)]),
    "bahria_lhr": (3, "Bahria Town Lahore", "Lahore",
                   "A large secure society with underground utilities, mosques, parks, a commercial hub and its own schools.",
                   [("Bahria Garden School", "Primary-Secondary", 0.8), ("Beacon Point Academy", "Montessori-O Levels", 1.5)],
                   [("Bahria Medical Centre", "General & Emergency", 1.8)]),
    "johar": (4, "Johar Town", "Lahore",
              "Established family neighbourhood with strong resale demand, markets, universities and hospitals nearby.",
              [("Johar Grammar School", "Primary-Matric", 0.7), ("Modern Science College", "College", 1.3)],
              [("Johar Care Hospital", "General & Emergency", 1.1), ("Zaitoon Women Hospital", "Gynaecology", 2.2)]),
    "dha8_khi": (5, "DHA Phase 8", "Karachi",
                 "Premium gated waterfront-adjacent community with wide roads, community clubs and controlled entry.",
                 [("Seaview Grammar School", "Primary-A Levels", 1.5), ("Defence Junior Academy", "Primary", 0.9)],
                 [("Creek General Hospital", "General & Emergency", 2.4)]),
    "clifton": (6, "Clifton", "Karachi",
                "Karachi's iconic upscale locality with sea-facing apartments, malls, restaurants and quick access to Defence.",
                [("Clifton Grammar Junior", "Primary-O Levels", 1.1), ("Harbour Girls School", "Secondary", 1.9)],
                [("Sea Breeze Hospital", "General & Emergency", 1.3), ("Karachi Eye Centre", "Ophthalmology", 2.6)]),
    "gulshan": (7, "Gulshan-e-Iqbal", "Karachi",
                "Densely populated, well-connected family area with markets, universities and excellent value for apartments.",
                [("Gulshan Public School", "Primary-Matric", 0.6), ("Karachi Science University Campus", "University", 2.1)],
                [("Gulshan Medical Complex", "General & Emergency", 0.9)]),
    "bahria_khi": (8, "Bahria Town Karachi", "Karachi",
                   "Large planned society off the Super Highway with villas, plots, a grand mosque, and full security and utilities.",
                   [("Bahria Academy Karachi", "Primary-O Levels", 1.0)],
                   [("Bahria General Hospital", "General & Emergency", 1.6)]),
    "f11": (9, "F-11", "Islamabad",
            "Green, upscale sector known for high-rise apartments, Markaz shopping and quick access to the Margalla side.",
            [("F-11 Public School", "Primary-Matric", 0.8), ("Capital Grammar College", "A Levels", 1.7)],
            [("Capital Care Hospital", "General & Emergency", 1.2), ("Margalla Specialist Clinic", "Specialist OPD", 2.0)]),
    "e11": (10, "E-11", "Islamabad",
            "Popular for reasonably priced apartments, strong rental demand from professionals and a busy commercial Markaz.",
            [("E-11 Model School", "Primary-Matric", 0.5), ("Islamabad Junior College", "College", 1.4)],
            [("E-11 Family Hospital", "General & Emergency", 1.0)]),
    "bahria_enc": (11, "Bahria Enclave", "Islamabad",
                   "Quiet gated community with sector-wise development, parks, mosque and a peaceful family environment.",
                   [("Enclave Grammar School", "Primary-Matric", 0.9)],
                   [("Enclave Health Centre", "General", 1.4)]),
    "dha2_isb": (12, "DHA Phase 2", "Islamabad",
                 "Secure, planned phase on the GT Road side with wide boulevards, a clubhouse and steady capital appreciation.",
                 [("Phase 2 International School", "Primary-A Levels", 1.3), ("DHA Junior Academy", "Primary", 0.9)],
                 [("DHA Medical Centre", "General & Emergency", 1.5)]),
}

# Properties: (area_key, ptype, purpose, beds, baths, size, unit, price_pkr, dev_id, agent_id,
#              status, amenities, yield_pct, possession, note)
G = "gated security"; SEC = "24/7 security"; PK = "park"; MQ = "mosque"; GYM = "gym"; POOL = "swimming pool"
UE = "underground electricity"; GAS = "gas"; PRK = "covered parking"; LIFT = "elevator"; GEN = "backup generator"
CLUB = "clubhouse"; MKT = "commercial market"; JOG = "jogging track"; KIDS = "kids play area"; SCH = "school in society"

P = [
    ("dha6", "house", "sale", 3, 3, 5, "marla", 3.4e7, 1, 1, "available", [G, SEC, PK, GAS, UE, PRK], 4.2, "Ready", "Modern 5 marla design with a lawn and car porch."),
    ("dha6", "house", "sale", 4, 5, 10, "marla", 6.2e7, 1, 1, "available", [G, SEC, PK, GAS, UE, PRK, JOG], 4.0, "Ready", "Double-storey home with a separate servant quarter."),
    ("dha6", "house", "sale", 5, 6, 1, "kanal", 11.5e7, 1, 2, "reserved", [G, SEC, PK, GAS, UE, PRK, POOL], 3.6, "Ready", "Luxury 1 kanal residence with a basement."),
    ("dha6", "plot", "sale", 0, 0, 10, "marla", 3.1e7, 4, 2, "available", [G, SEC, PK, UE, GAS], 0.0, "Ready for construction", "Possession-ready plot on a 60-ft road."),
    ("gulberg", "apartment", "sale", 2, 2, 1100, "sqft", 2.6e7, 3, 2, "available", [LIFT, GEN, PRK, SEC, GYM], 6.0, "Ready", "Tower apartment close to the main boulevard."),
    ("gulberg", "apartment", "sale", 3, 3, 1750, "sqft", 4.4e7, 3, 1, "available", [LIFT, GEN, PRK, SEC, GYM, POOL], 5.5, "Ready", "Corner unit with city views."),
    ("gulberg", "office", "sale", 0, 2, 1200, "sqft", 5.8e7, 5, 2, "available", [LIFT, GEN, PRK, SEC], 7.0, "Ready", "Grade-A office floor in a busy commercial corridor."),
    ("gulberg", "apartment", "rent", 2, 2, 1100, "sqft", 1.5e5, 3, 1, "available", [LIFT, GEN, PRK, SEC], 0.0, "Immediate", "Furnished 2-bed apartment for professionals."),
    ("bahria_lhr", "house", "sale", 3, 3, 5, "marla", 1.75e7, 4, 2, "available", [G, SEC, PK, MQ, UE, SCH], 5.0, "Ready", "Value-for-money family house near the commercial hub."),
    ("bahria_lhr", "house", "sale", 4, 4, 10, "marla", 3.3e7, 4, 1, "available", [G, SEC, PK, MQ, UE, SCH, GYM], 4.6, "Ready", "Spacious 10 marla house with a large lounge."),
    ("bahria_lhr", "plot", "sale", 0, 0, 5, "marla", 8.5e6, 4, 2, "available", [G, SEC, PK, MQ, UE], 0.0, "Ready for construction", "Developed 5 marla plot, ideal for phased construction."),
    ("bahria_lhr", "house", "rent", 4, 4, 10, "marla", 1.65e5, 4, 1, "available", [G, SEC, PK, UE, GAS], 0.0, "Immediate", "Family home available for long-term rent."),
    ("johar", "house", "sale", 3, 3, 5, "marla", 2.1e7, 4, 2, "available", [SEC, PK, GAS, PRK], 5.2, "Ready", "Corner 5 marla house near the main market."),
    ("johar", "house", "sale", 4, 4, 10, "marla", 4.2e7, 4, 1, "sold", [SEC, PK, GAS, PRK], 4.4, "Ready", "Spacious family house."),
    ("johar", "shop", "sale", 0, 1, 400, "sqft", 3.2e7, 5, 2, "available", [SEC, PRK], 7.5, "Ready", "Ground-floor shop on a busy market road."),
    ("dha8_khi", "house", "sale", 4, 4, 300, "sq_yd", 8.5e7, 2, 3, "available", [G, SEC, CLUB, PK, PRK, UE], 3.8, "Ready", "Contemporary villa with a rooftop terrace."),
    ("dha8_khi", "apartment", "sale", 3, 3, 2100, "sqft", 5.2e7, 2, 4, "available", [LIFT, GEN, SEC, PRK, GYM, POOL], 5.0, "Dec 2027", "Under-construction tower with sea-breeze views."),
    ("dha8_khi", "plot", "sale", 0, 0, 500, "sq_yd", 6.8e7, 2, 3, "available", [G, SEC, PK, UE], 0.0, "Ready for construction", "Prime 500 sq yd plot on a 60-ft road."),
    ("clifton", "apartment", "sale", 3, 3, 2400, "sqft", 7.9e7, 2, 4, "available", [LIFT, GEN, SEC, PRK, GYM, POOL], 4.5, "Ready", "Sea-facing apartment with a large balcony."),
    ("clifton", "apartment", "sale", 2, 2, 1500, "sqft", 4.6e7, 2, 3, "available", [LIFT, GEN, SEC, PRK], 5.4, "Ready", "Compact luxury unit close to malls."),
    ("clifton", "apartment", "rent", 3, 3, 2400, "sqft", 3.5e5, 2, 4, "available", [LIFT, GEN, SEC, PRK, GYM], 0.0, "Immediate", "Premium rental with sea view."),
    ("gulshan", "apartment", "sale", 2, 2, 1050, "sqft", 1.45e7, 2, 3, "available", [LIFT, GEN, SEC, PRK], 6.5, "Ready", "Affordable, high-rental-demand apartment."),
    ("gulshan", "apartment", "sale", 3, 3, 1600, "sqft", 2.4e7, 2, 4, "available", [LIFT, GEN, SEC, PRK, KIDS], 6.0, "Ready", "Family apartment on a high floor."),
    ("gulshan", "shop", "sale", 0, 1, 300, "sqft", 2.9e7, 5, 3, "available", [SEC, PRK], 8.0, "Ready", "High-footfall shop on the main road."),
    ("gulshan", "apartment", "rent", 2, 2, 1050, "sqft", 7.5e4, 2, 4, "available", [LIFT, GEN, SEC], 0.0, "Immediate", "Neat 2-bed apartment for small families."),
    ("bahria_khi", "house", "sale", 4, 4, 250, "sq_yd", 2.9e7, 4, 3, "available", [G, SEC, PK, MQ, UE, SCH], 5.5, "Ready", "Precinct villa with a garden."),
    ("bahria_khi", "house", "sale", 3, 3, 125, "sq_yd", 1.5e7, 4, 4, "available", [G, SEC, PK, MQ, UE], 6.0, "Ready", "Compact, budget-friendly villa."),
    ("bahria_khi", "plot", "sale", 0, 0, 250, "sq_yd", 1.1e7, 4, 3, "available", [G, SEC, PK, MQ, UE], 0.0, "Ready for construction", "Investment plot in a developed precinct."),
    ("f11", "apartment", "sale", 2, 2, 1250, "sqft", 4.8e7, 3, 5, "available", [LIFT, GEN, SEC, PRK, GYM], 5.0, "Ready", "Boutique apartment near F-11 Markaz."),
    ("f11", "apartment", "sale", 3, 3, 1900, "sqft", 7.3e7, 3, 6, "available", [LIFT, GEN, SEC, PRK, GYM, POOL], 4.6, "Ready", "Spacious apartment with Margalla views."),
    ("f11", "apartment", "rent", 2, 2, 1250, "sqft", 1.9e5, 3, 5, "available", [LIFT, GEN, SEC, PRK], 0.0, "Immediate", "Well-maintained rental with covered parking."),
    ("e11", "apartment", "sale", 2, 2, 1000, "sqft", 3.5e7, 3, 6, "available", [LIFT, GEN, SEC, PRK], 6.2, "Ready", "Good rental-yield apartment near E-11 Markaz."),
    ("e11", "apartment", "sale", 1, 1, 650, "sqft", 1.9e7, 3, 5, "available", [LIFT, GEN, SEC], 6.8, "Ready", "Studio-style unit for investors."),
    ("e11", "apartment", "rent", 3, 3, 1500, "sqft", 2.2e5, 3, 6, "available", [LIFT, GEN, SEC, PRK], 0.0, "Immediate", "Spacious rental for families."),
    ("e11", "shop", "sale", 0, 1, 350, "sqft", 4.1e7, 5, 5, "available", [SEC, PRK], 7.2, "Ready", "Shop in the busy E-11 Markaz."),
    ("bahria_enc", "house", "sale", 3, 3, 8, "marla", 2.6e7, 4, 6, "available", [G, SEC, PK, MQ, UE], 4.8, "Ready", "Quiet street, family-friendly layout."),
    ("bahria_enc", "plot", "sale", 0, 0, 10, "marla", 1.2e7, 4, 5, "available", [G, SEC, PK, MQ, UE], 0.0, "Ready for construction", "Developed 10 marla plot."),
    ("bahria_enc", "house", "sale", 5, 5, 1, "kanal", 5.9e7, 4, 5, "available", [G, SEC, PK, MQ, UE, PRK], 4.0, "Ready", "Large 1 kanal home with a garden."),
    ("dha2_isb", "house", "sale", 4, 4, 10, "marla", 6.5e7, 1, 6, "available", [G, SEC, CLUB, PK, UE, GAS], 4.3, "Ready", "Spacious 10 marla house near the clubhouse."),
    ("dha2_isb", "plot", "sale", 0, 0, 1, "kanal", 5.5e7, 1, 5, "available", [G, SEC, CLUB, PK, UE], 0.0, "Ready for construction", "Corner 1 kanal plot on a wide road."),
    ("dha2_isb", "house", "rent", 4, 4, 10, "marla", 2.8e5, 1, 6, "available", [G, SEC, PK, UE, GAS], 0.0, "Immediate", "Family house for rent near the clubhouse."),
    ("dha6", "office", "sale", 0, 2, 2000, "sqft", 9.5e7, 5, 2, "available", [LIFT, GEN, PRK, SEC], 6.8, "Ready", "Sky-tower office floor with a corporate lobby."),
]

SIZE_LABEL = {"marla": "marla", "kanal": "kanal", "sqft": "sq ft", "sq_yd": "sq yd"}


def size_str(v: float, unit: str) -> str:
    return f"{int(v) if float(v).is_integer() else v} {SIZE_LABEL[unit]}"


def payment_plan(price: float, ptype: str, possession: str) -> tuple | None:
    """Return (name, down%, installments, monthly, token) - sale only."""
    if ptype in ("plot",):
        down, n, name = 40.0, 24, "Plot Easy-24"
    elif ptype in ("shop", "office"):
        down, n, name = 35.0, 36, "Commercial Flex-36"
    elif possession.lower() == "ready":
        down, n, name = 30.0, 36, "Home Ready-36"
    else:
        down, n, name = 25.0, 48, "Under-Construction-48"
    monthly = round(price * (1 - down / 100) / n, -3)
    token = round(price * 0.02, -4)
    return name, down, n, monthly, token


# --------------------------------------------------------------------------- #
def build_db() -> list[dict]:
    db.init_db(drop=True)
    with db.conn() as c:
        c.execute(insert(db.developers), [
            dict(id=i, name=n, established=e, headquarters=h, approvals=a, projects_delivered=p, track_record=t)
            for i, n, e, h, a, p, t in DEVELOPERS])
        c.execute(insert(db.agents), [
            dict(id=i, name=n, email=e, phone=ph, city=ci, languages=l,
                 calendar_id=f"{e}", work_start="10:00", work_end="19:00")
            for i, n, e, ph, ci, l in AGENTS])
        c.execute(insert(db.areas), [
            dict(id=v[0], name=v[1], city=v[2], summary=v[3]) for v in AREAS.values()])
        sid = hid = 1
        for v in AREAS.values():
            for n, lvl, km in v[4]:
                c.execute(insert(db.schools), dict(id=sid, area_id=v[0], name=n, level=lvl, distance_km=km)); sid += 1
            for n, sp, km in v[5]:
                c.execute(insert(db.hospitals), dict(id=hid, area_id=v[0], name=n, speciality=sp, distance_km=km)); hid += 1

        out = []
        for pid, row in enumerate(P, start=1):
            (ak, ptype, purpose, beds, baths, size, unit, price, dev, agent, status, amen, yld, poss, note) = row
            area = AREAS[ak]
            category = "commercial" if ptype in ("shop", "office") else "residential"
            title = (f"{size_str(size, unit)} {ptype.title()} in {area[1]}, {area[2]}"
                     if ptype in ("plot", "house") else
                     f"{beds}-Bed Apartment in {area[1]}, {area[2]}" if ptype == "apartment"
                     else f"{size_str(size, unit)} {ptype.title()} in {area[1]}, {area[2]}")
            rec = dict(id=pid, title=title, ptype=ptype, category=category, purpose=purpose,
                       area_id=area[0], bedrooms=beds, bathrooms=baths, size_value=size,
                       size_unit=unit, price_pkr=price, status=status, developer_id=dev,
                       agent_id=agent, amenities=json.dumps(amen), rental_yield_pct=yld,
                       possession=poss, description=note)
            c.execute(insert(db.properties), rec)
            plan = payment_plan(price, ptype, poss) if purpose == "sale" else None
            if plan:
                c.execute(insert(db.payment_plans), dict(
                    property_id=pid, plan_name=plan[0], down_payment_pct=plan[1],
                    installments=plan[2], monthly_installment_pkr=plan[3], token_pkr=plan[4]))
            out.append(dict(rec, area=area[1], city=area[2], plan=plan, amenities_list=amen,
                            developer=DEVELOPERS[dev - 1][1], agent=AGENTS[agent - 1][1],
                            dev_row=DEVELOPERS[dev - 1]))
    return out


# --------------------------------------------------------------------------- #
# KB documents
# --------------------------------------------------------------------------- #
def write_brochures(props: list[dict]) -> None:
    d = KB / "brochures"
    d.mkdir(parents=True, exist_ok=True)
    for p in props:
        area = next(v for v in AREAS.values() if v[0] == p["area_id"])
        # NOTE: price / status / instalments are deliberately NOT written to brochures.
        # They change often and live only in SQL (structured retrieval) so they can never go stale.
        lines = [
            f"# Property {p['id']}: {p['title']}",
            "",
            f"## Overview",
            f"Property ID {p['id']} is a {p['ptype']} for {p['purpose']} in {p['area']}, {p['city']}. {p['description']}",
            f"Size: {size_str(p['size_value'], p['size_unit'])}."
            + (f" Bedrooms: {p['bedrooms']}. Bathrooms: {p['bathrooms']}." if p["ptype"] in ("house", "apartment") else ""),
            f"Possession: {p['possession']}.",
            "",
            "## Amenities",
            "Amenities: " + ", ".join(p["amenities_list"]) + ".",
            "",
            "## Developer",
            f"Developed by {p['developer']} ({p['dev_row'][4]}). Assigned sales agent: {p['agent']}.",
        ]
        if p["rental_yield_pct"]:
            lines += ["", "## Investment note",
                      f"Indicative rental yield estimate: {p['rental_yield_pct']}% per year (company research estimate, not a guarantee)."]
        lines += ["", "## Nearby",
                  "Schools nearby: " + "; ".join(f"{n} ({km} km)" for n, _, km in area[4]) + ".",
                  "Hospitals nearby: " + "; ".join(f"{n} ({km} km)" for n, _, km in area[5]) + "."]
        (d / f"property_{p['id']:02d}.md").write_text("\n".join(lines), encoding="utf-8")


def write_area_guides() -> None:
    d = KB / "areas"
    d.mkdir(parents=True, exist_ok=True)
    for v in AREAS.values():
        txt = [f"# Area Guide: {v[1]}, {v[2]}", "", "## About the area", v[3], "",
               "## Schools", *[f"- {n} ({lvl}) is {km} km away." for n, lvl, km in v[4]], "",
               "## Hospitals", *[f"- {n} ({sp}) is {km} km away." for n, sp, km in v[5]]]
        (d / f"area_{v[0]:02d}.md").write_text("\n".join(txt), encoding="utf-8")


def write_developers() -> None:
    d = KB / "developers"
    d.mkdir(parents=True, exist_ok=True)
    for i, n, e, h, a, p, t in DEVELOPERS:
        (d / f"developer_{i}.md").write_text(
            f"# Developer Profile: {n}\n\n{n} was established in {e} and is headquartered in {h}. "
            f"Approvals: {a}. Projects delivered: {p}.\n\n## Track record\n{t}\n", encoding="utf-8")


FAQS = [
    ("What are the property visit timings?", "Property visits are free of charge and available Monday to Saturday between 10:00 AM and 7:00 PM. Each visit slot is 30 minutes. Sunday visits are not scheduled by the AI assistant."),
    ("Is there any charge for visiting a property?", "No. Property visits with our sales agent are completely free and carry no obligation to buy."),
    ("How do I book, reschedule or cancel a visit?", "You can book, reschedule or cancel a visit by phone. The agent confirms the slot, updates the calendar and emails the assigned sales executive. Please give at least 3 hours notice for reschedules and cancellations."),
    ("How much is the token amount?", "The token amount to reserve a sale property is 2% of the price. It is recorded against the property and the reservation is confirmed by the assigned agent in writing."),
    ("What documents are needed to buy a property?", "Buyers need a copy of their CNIC, recent passport-size photographs and proof of funds. Overseas Pakistanis need a valid passport, NICOP or CNIC and can complete the purchase through a registered power of attorney."),
    ("Can overseas Pakistanis buy through RealEstate Hub?", "Yes. Overseas Pakistanis can buy remotely using a registered power of attorney, and our team arranges video walkthroughs of the property."),
    ("What taxes and fees apply on a purchase?", "Government taxes, stamp duty and transfer fees follow FBR and provincial rules that change from time to time. Our legal team shares the exact, current figure in writing before you pay anything. The AI assistant does not quote tax rates."),
    ("What is the company commission?", "For sale transactions RealEstate Hub charges 1% commission from the buyer and 1% from the seller. For rentals, the commission is 50% of one month's rent."),
    ("How does renting work?", "For rentals the tenant pays one month advance and two months security deposit. A written tenancy agreement is prepared by our team. Rent increases follow the agreement terms."),
    ("Do you offer installment plans?", "Yes. Most sale properties have an installment plan. Ready houses typically follow the Home Ready-36 plan with 30% down payment and 36 monthly instalments. Plots use Plot Easy-24 with 40% down and 24 instalments. Commercial units use Commercial Flex-36 with 35% down and 36 instalments. Under-construction apartments use a 25% down payment with 48 instalments."),
    ("Can I get a home loan?", "Bank financing is possible for eligible customers. RealEstate Hub can introduce you to partner banks, but approval and rates are decided by the bank. The AI assistant cannot promise loan approval."),
    ("Is the property legally verified?", "Every listing is checked by our legal team for title, society approval and NOC status before it is published. The assigned agent shares the verified documents during the visit."),
    ("What if a property I like is already sold?", "Availability is checked live from our system. If a property is sold or reserved, the agent suggests the closest alternatives in the same area and budget."),
    ("Are your prices negotiable?", "Prices shown are the listed prices. Negotiation, if any, is handled by the assigned sales agent with the owner or developer. The AI assistant never promises a discount."),
    ("Is investment in real estate guaranteed to give profit?", "No investment is guaranteed. Rental yield and appreciation figures shared by the company are indicative research estimates, not promises."),
    ("What maintenance charges apply to apartments?", "Apartment buildings charge monthly maintenance for security, lifts, generator backup and common areas. The exact monthly amount depends on the building and is shared by the agent before you decide."),
    ("What happens if construction is delayed?", "For under-construction properties, the developer's committed possession date is written in the booking letter. Our agents share the developer's delivery record so you can judge reliability."),
    ("Which cities do you cover?", "RealEstate Hub covers Lahore, Karachi and Islamabad, with listings in DHA, Bahria Town, Gulberg, Johar Town, Clifton, Gulshan-e-Iqbal, F-11, E-11 and more."),
    ("Do you deal with commercial properties?", "Yes. We list shops and office floors for sale in Lahore, Karachi and Islamabad, mostly in high-footfall commercial areas."),
    ("Can I sell or rent out my own property with you?", "Yes. Our sales agents can list your property. The AI assistant records your details and a human agent calls you back to complete verification and valuation."),
    ("What are your office hours?", "The AI assistant answers calls 24/7. Human agents are available Monday to Saturday, 10:00 AM to 7:00 PM."),
    ("How can I speak to a human agent?", "Just say you would like to speak to a human agent. The assistant will note your details and arrange a call-back from the assigned agent during office hours."),
    ("What is the difference between a marla and a kanal?", "One kanal equals 20 marla. A 5 marla plot is a quarter of a kanal. In our listings a marla is about 225 square feet for planning purposes, and exact measurements come from the title documents."),
]


def write_faqs_and_policies() -> None:
    d = KB / "faqs"
    d.mkdir(parents=True, exist_ok=True)
    (d / "faqs.json").write_text(json.dumps(
        [{"question": q, "answer": a} for q, a in FAQS], indent=2, ensure_ascii=False), encoding="utf-8")
    pol = KB / "policies"
    pol.mkdir(parents=True, exist_ok=True)
    (pol / "company_overview.md").write_text(
        "# RealEstate Hub - Company Overview\n\n## Who we are\n"
        "RealEstate Hub is a Pakistani real estate advisory firm serving buyers, renters and investors in Lahore, Karachi and Islamabad. "
        "The firm lists residential and commercial properties, arranges free property visits and supports customers through the whole purchase or rental journey.\n\n"
        "## Services\nBuying, selling, renting, investment advisory, payment-plan guidance and property visit scheduling.\n\n"
        "## Working hours\nHuman sales agents: Monday to Saturday, 10:00 AM to 7:00 PM. The AI voice assistant answers calls 24/7.\n", encoding="utf-8")


def main() -> None:
    if KB.exists():
        shutil.rmtree(KB)
    KB.mkdir(parents=True)
    props = build_db()
    write_brochures(props)
    write_area_guides()
    write_developers()
    write_faqs_and_policies()
    n_docs = sum(1 for _ in KB.rglob("*") if _.is_file())
    print(f"DB built: {len(props)} properties, {len(AREAS)} areas, {len(AGENTS)} agents, {len(DEVELOPERS)} developers")
    print(f"KB built: {n_docs} documents in {KB}")


if __name__ == "__main__":
    main()
