"""Build a captioned walkthrough using the local mock agent.

Run: python scripts/render_demo_video.py
Install optional media packages with: pip install -r requirements-video.txt
All application examples are generated against a separate disposable SQLite DB.
The companion demo_video_script.md is a read-aloud voiceover script.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT / "work" / "demo_video"
OUTPUT = ROOT / "demo_video.mp4"
FPS, WIDTH, HEIGHT = 24, 1920, 1080
SCENE_SECONDS = [7, 8, 10, 10, 9, 10, 8]
NARRATION = [
    "RealEstate Hub is a local capstone MVP for property inquiries in Urdu and English. This video shows a text call flow and the optional browser voice demo.",
    "A text or browser speech turn enters FastAPI and follows the LangGraph flow. Exact property facts come from SQLite; descriptive information uses semantic retrieval. Optional Deepgram and Fish Audio adapters provide speech-to-text and text-to-speech.",
    "The caller asks in Roman Urdu for a home in DHA Lahore, within a budget of thirty-five million Pakistani rupees. The agent responds using the sample inventory.",
    "The agent can carry property context into a follow-up question. The listing and its details shown here are synthetic demo data, not a real property offer.",
    "The workflow can collect visit details and record an appointment. In this demonstration, calendar, email and CRM steps use local mock services only.",
    "The local checks passed: one hundred six tests, forty-nine conversation cases, and twenty RAG questions. The finite security suite caught all thirty-one tested attacks. Provider requests were mocked in tests.",
    "The browser demo can use your device voice, and a signed turn-based Twilio webhook is included. Real phone calls need account keys and a public HTTPS deployment. Open slash demo to try the local browser experience.",
]

sys.path.insert(0, str(ROOT))
WORK.mkdir(parents=True, exist_ok=True)
os.environ["DATABASE_URL"] = f"sqlite:///{(WORK / 'demo_video.db').as_posix()}"
os.environ["VECTOR_BACKEND"] = "numpy"
os.environ["CHROMA_DIR"] = str(WORK / "unused_chroma")
os.environ["LLM_PROVIDER"] = "mock"
os.environ["CALENDAR_MODE"] = "mock"
os.environ["EMAIL_MODE"] = "mock"
os.environ["OUTBOX_DIR"] = str(WORK / "outbox")

from PIL import Image, ImageDraw, ImageFont  # noqa: E402
import imageio_ffmpeg  # noqa: E402


NAVY = (8, 19, 35)
PANEL = (17, 34, 54)
PANEL2 = (24, 45, 68)
WHITE = (241, 246, 251)
MUTED = (164, 181, 198)
TEAL = (42, 211, 184)
GOLD = (255, 192, 92)
RED = (255, 120, 115)
GREEN = (93, 220, 152)
FONT_DIR = Path("C:/Windows/Fonts")


def font(size: int, bold: bool = False):
    names = ["seguisb.ttf", "arialbd.ttf"] if bold else ["segoeui.ttf", "arial.ttf"]
    for name in names:
        p = FONT_DIR / name
        if p.exists():
            return ImageFont.truetype(str(p), size)
    return ImageFont.load_default()


def wrap(text: str, fnt, max_width: int) -> list[str]:
    draw = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    out: list[str] = []
    for paragraph in str(text).splitlines() or [""]:
        words = paragraph.split()
        line = ""
        for word in words:
            test = f"{line} {word}".strip()
            if draw.textbbox((0, 0), test, font=fnt)[2] <= max_width:
                line = test
            else:
                if line:
                    out.append(line)
                line = word
        if line:
            out.append(line)
    return out


def paragraph(draw, text, xy, fnt, fill, max_width, line_gap=12, max_lines=None):
    x, y = xy
    lines = wrap(text, fnt, max_width)
    if max_lines:
        lines = lines[:max_lines]
        if wrap(text, fnt, max_width).__len__() > max_lines and lines:
            lines[-1] = lines[-1].rstrip(" .") + "..."
    height = draw.textbbox((0, 0), "Ag", font=fnt)[3]
    for line in lines:
        draw.text((x, y), line, font=fnt, fill=fill)
        y += height + line_gap
    return y


def base(kicker: str, title: str, subtitle: str):
    im = Image.new("RGB", (WIDTH, HEIGHT), NAVY)
    d = ImageDraw.Draw(im)
    # Quiet technical grid and edge accents
    for x in range(80, WIDTH, 160):
        d.line((x, 0, x, HEIGHT), fill=(13, 28, 45), width=1)
    for y in range(80, HEIGHT, 160):
        d.line((0, y, WIDTH, y), fill=(13, 28, 45), width=1)
    d.rectangle((0, 0, WIDTH, 12), fill=TEAL)
    d.text((92, 54), kicker.upper(), font=font(23, True), fill=TEAL)
    d.text((92, 108), title, font=font(54, True), fill=WHITE)
    paragraph(d, subtitle, (94, 188), font(27), MUTED, 1700, 7, 2)
    d.line((92, 263, 1828, 263), fill=(48, 70, 92), width=2)
    d.text((92, 1040), "SYNTHETIC DEMO DATA • LOCAL MVP • NO LIVE PROVIDERS", font=font(17, True), fill=MUTED)
    return im, d


def pill(draw, x, y, text, color=TEAL, width=None):
    f = font(20, True)
    w = width or draw.textbbox((0, 0), text, font=f)[2] + 36
    draw.rounded_rectangle((x, y, x + w, y + 46), radius=20, fill=(23, 46, 66), outline=color, width=2)
    draw.text((x + 18, y + 9), text, font=f, fill=color)


def box(draw, xy, title, detail, accent=TEAL, detail_color=MUTED):
    x1, y1, x2, y2 = xy
    draw.rounded_rectangle(xy, radius=24, fill=PANEL, outline=(57, 82, 107), width=2)
    draw.rectangle((x1, y1, x1 + 8, y2), fill=accent)
    draw.text((x1 + 28, y1 + 24), title, font=font(27, True), fill=WHITE)
    paragraph(draw, detail, (x1 + 28, y1 + 74), font(21), detail_color, x2 - x1 - 56, 7, 5)


def collect_demo():
    """Generate real local app text on an isolated database for the video."""
    from scripts.build_kb import main as build_kb

    build_kb()
    from app.agent.session import CallSession
    from app import db
    from app.recommender import Profile, recommend

    s = CallSession(caller_phone="+923000000000")
    greeting = s.greet()
    caller = "DHA Lahore mein 3.5 crore tak 5 marla ghar chahiye"
    answer = s.say(caller)
    followup = "Is property ki amenities kya hain?"
    follow_answer = s.say(followup)
    matches = recommend(Profile(budget_max=35_000_000, city="Lahore", area="DHA Phase 6", bedrooms=3, purpose="sale", ptype="house"), limit=3)
    property_row = db.get_property(1) or {}
    content = {
        "greeting": greeting,
        "caller": caller,
        "answer": answer,
        "followup": followup,
        "follow_answer": follow_answer,
        "matches": matches,
        "property": property_row,
    }
    (WORK / "demo_transcript.json").write_text(json.dumps(content, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return content


def build_scenes(data):
    scenes = []
    # 1 — honest title and context
    im, d = base("Week 4 Capstone • Local Demo", "UrduLish Real Estate Agent", "An offline-first text prototype for property questions, recommendations and visit workflows.")
    pill(d, 96, 340, "LOCAL MVP", TEAL)
    pill(d, 260, 340, "SYNTHETIC LISTINGS", GOLD)
    d.text((100, 472), "A guided demo of the implemented text path", font=font(38, True), fill=WHITE)
    paragraph(d, "The caller's message and agent replies are produced by the bundled local application. This MP4 is caption-only; the companion script is provided for a presenter to read or record.", (100, 550), font(27), MUTED, 1180, 15, 4)
    d.ellipse((1420, 360, 1740, 680), outline=(36, 97, 115), width=4)
    d.ellipse((1490, 430, 1670, 610), fill=(19, 49, 68), outline=TEAL, width=4)
    d.text((1538, 486), "RE", font=font(76, True), fill=TEAL)
    scenes.append(im)

    # 2 — actual and future boundary
    im, d = base("01 / Architecture", "Local flow and optional provider adapters", "The browser voice and turn-based phone paths are in code; external services still need owner credentials and deployment.")
    nodes = [
        ("Browser", "Text / microphone\nvoice demo", TEAL),
        ("FastAPI", "HTTP text endpoints", TEAL),
        ("LangGraph", "Stateful turn flow", TEAL),
        ("Knowledge", "SQLite + semantic RAG", TEAL),
        ("Workflows", "Mock calendar / email", GOLD),
    ]
    xs = [100, 455, 810, 1165, 1520]
    for i, (title, detail, color) in enumerate(nodes):
        box(d, (xs[i], 405, xs[i] + 290, 570), title, detail, color)
        if i < len(nodes) - 1:
            d.line((xs[i] + 298, 487, xs[i + 1] - 14, 487), fill=TEAL, width=4)
            d.polygon([(xs[i + 1] - 14, 479), (xs[i + 1], 487), (xs[i + 1] - 14, 495)], fill=TEAL)
    d.rounded_rectangle((100, 674, 1810, 830), radius=20, fill=(24, 29, 43), outline=(100, 92, 75), width=2)
    pill(d, 130, 704, "OPTIONAL SETUP", GOLD)
    d.text((430, 711), "Deepgram STT  •  Fish Audio TTS  •  signed Twilio Gather webhook", font=font(27, True), fill=WHITE)
    d.text((130, 780), "Requires credentials and public HTTPS; no live provider or phone call was tested.", font=font(22), fill=MUTED)
    scenes.append(im)

    # 3 — real utterance and agent output
    im, d = base("02 / Live application output", "Property inquiry", "Captured from the local LangGraph session • illustrative transcript layout")
    d.rounded_rectangle((100, 335, 1785, 480), radius=24, fill=(19, 47, 65), outline=TEAL, width=2)
    pill(d, 132, 357, "CALLER", TEAL)
    paragraph(d, data["caller"], (360, 356), font(34, True), WHITE, 1350, 7, 2)
    d.rounded_rectangle((230, 522, 1785, 808), radius=24, fill=PANEL, outline=(57, 82, 107), width=2)
    pill(d, 262, 547, "AGENT • LOCAL MOCK LLM", GOLD)
    paragraph(d, data["answer"], (262, 617), font(26), WHITE, 1460, 12, 5)
    scenes.append(im)

    # 4 — real structured property row + context follow-up
    im, d = base("03 / SQL + follow-up context", "Exact listing facts stay structured", "A selected demo row is retrieved from the bundled synthetic inventory.")
    prop = data["property"]
    title = prop.get("title") or prop.get("name") or "Demo property 1"
    loc = ", ".join(str(prop.get(k)) for k in ("area", "city") if prop.get(k)) or "DHA Phase 6, Lahore"
    price = prop.get("price_pkr") or prop.get("price") or 34_000_000
    try:
        price_text = f"PKR {int(float(price)):,}"
    except Exception:
        price_text = f"PKR {price}"
    bedrooms = prop.get("bedrooms", 3)
    box(d, (100, 350, 865, 750), str(title), f"{loc}\n\n{bedrooms} bedrooms\n{price_text}\n\nSynthetic demo data", TEAL)
    d.text((990, 355), "FOLLOW-UP QUESTION", font=font(21, True), fill=GOLD)
    paragraph(d, data["followup"], (990, 405), font(30, True), WHITE, 760, 12, 3)
    d.text((990, 540), "LOCAL AGENT RESPONSE", font=font(21, True), fill=TEAL)
    paragraph(d, data["follow_answer"], (990, 590), font(23), WHITE, 760, 10, 5)
    scenes.append(im)

    # 5 — workflow design accurately labeled
    im, d = base("04 / Scheduling workflow", "Booking rules before external actions", "The project has local appointment logic and service interfaces; this is a mock-mode design walkthrough.")
    steps = [
        ("Collect", "name • phone\nproperty • slot"),
        ("Validate", "availability\nnotice window"),
        ("Record", "SQLite appointment\nlocal demo event"),
        ("Queue", "mock email outbox\nCRM trace"),
    ]
    x = 110
    for title, detail in steps:
        box(d, (x, 430, x + 360, 625), title, detail, GOLD if title == "Queue" else TEAL)
        x += 425
    d.line((180, 734, 1740, 734), fill=(63, 89, 111), width=3)
    for x in (290, 715, 1140, 1565):
        d.ellipse((x - 11, 723, x + 11, 745), fill=TEAL)
    pill(d, 110, 795, "MOCK ONLY", GOLD)
    d.text((290, 804), "No Google Calendar, email, CRM, or customer account was contacted in this recording.", font=font(24), fill=WHITE)
    scenes.append(im)

    # 6 — evidence and caveats
    im, d = base("05 / Trust and verification", "What the demo proves", "A functional local prototype is a solid capstone milestone; production readiness requires further checks.")
    box(d, (110, 352, 860, 548), "Included", "Python API • LangGraph • SQL/RAG • mock workflows • synthetic data", TEAL)
    box(d, (1000, 352, 1750, 548), "Verified in this handoff", "106 tests passed\n49 / 49 conversations passed\n20 / 20 RAG questions correct", GREEN)
    box(d, (110, 610, 860, 806), "Still required", "Real inventory • authenticated deployment • durable sessions • live provider smoke tests", GOLD)
    box(d, (1000, 610, 1750, 806), "Security evaluation", "31 tested attacks caught • no end-to-end leak in this finite suite. This is not proof of complete security.", RED)
    scenes.append(im)

    # 7 — run/demo close
    im, d = base("06 / Try it locally", "Run the browser demo", "Open the interactive voice page after starting the local FastAPI service.")
    lines = ["python -m pip install -r requirements.txt", "python scripts/build_kb.py", "uvicorn app.main:app --reload", "Open  http://127.0.0.1:8000/demo"]
    y = 360
    for i, line in enumerate(lines, 1):
        d.ellipse((125, y + 4, 173, y + 52), fill=TEAL)
        d.text((139, y + 10), str(i), font=font(23, True), fill=NAVY)
        d.text((210, y), line, font=font(33, True), fill=WHITE)
        y += 112
    pill(d, 1120, 770, "LOCAL VOICE", TEAL)
    d.text((1300, 779), "Browser/device support varies; API keys are optional.", font=font(22), fill=MUTED)
    scenes.append(im)
    return scenes


def render(scenes):
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    writer = imageio_ffmpeg.write_frames(
        str(OUTPUT), (WIDTH, HEIGHT), fps=FPS, codec="libx264", quality=8,
        pix_fmt_in="rgb24", pix_fmt_out="yuv420p", macro_block_size=1,
        ffmpeg_log_level="error", output_params=["-preset", "ultrafast"],
    )
    writer.send(None)
    timeline = []
    cursor = 0.0
    for idx, (scene, seconds, caption) in enumerate(zip(scenes, SCENE_SECONDS, NARRATION)):
        overlay = scene.copy()
        d = ImageDraw.Draw(overlay)
        d.rounded_rectangle((90, 875, 1830, 1012), radius=16, fill=(14, 31, 49), outline=(42, 211, 184), width=2)
        paragraph(d, caption, (118, 897), font(21), WHITE, 1680, 7, 3)
        # Brief crossfade between title cards.
        if idx:
            prev = scenes[idx - 1].copy().convert("RGB")
            current = overlay.convert("RGB")
            for f in range(8):
                blended = Image.blend(prev, current, (f + 1) / 8)
                writer.send(blended.tobytes())
        rgb = overlay.convert("RGB").tobytes()
        for _ in range(max(1, round(seconds * FPS) - (8 if idx else 0))):
            writer.send(rgb)
        timeline.append((cursor, cursor + seconds, caption))
        cursor += seconds
    writer.close()
    def stamp(seconds):
        millis = round(seconds * 1000)
        hh, millis = divmod(millis, 3_600_000)
        mm, millis = divmod(millis, 60_000)
        ss, millis = divmod(millis, 1000)
        return f"{hh:02d}:{mm:02d}:{ss:02d},{millis:03d}"
    srt = ROOT / "demo_video.srt"
    with srt.open("w", encoding="utf-8", newline="\n") as f:
        for idx, (start, end, caption) in enumerate(timeline, 1):
            f.write(f"{idx}\n{stamp(start)} --> {stamp(end)}\n{caption}\n\n")


def main():
    data = collect_demo()
    scenes = build_scenes(data)
    # Keep the static architecture visual consistent with the real runtime boundary.
    scenes[1].save(ROOT / "docs" / "diagrams" / "architecture_diagram.png")
    render(scenes)
    print(f"Created {OUTPUT} ({OUTPUT.stat().st_size:,} bytes)")
    print("Transcript used for scene text: work/demo_video/demo_transcript.json")
    print("All displayed listings and business records are synthetic; integrations use mock mode. See demo_video_script.md for narration.")


if __name__ == "__main__":
    main()
