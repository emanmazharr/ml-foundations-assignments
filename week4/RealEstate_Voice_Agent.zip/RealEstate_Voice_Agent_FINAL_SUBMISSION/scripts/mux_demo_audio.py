"""Mux a recorded narration track into the captioned demo using bundled ffmpeg."""
from __future__ import annotations

import subprocess
import argparse
from pathlib import Path

import imageio_ffmpeg

ROOT = Path(__file__).resolve().parent.parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("audio", type=Path, help="Your recorded WAV, MP3, or M4A narration")
parser.add_argument("--video", type=Path, default=ROOT / "demo_video.mp4")
parser.add_argument("--output", type=Path, default=ROOT / "demo_video_with_audio.mp4")
args = parser.parse_args()
video = args.video.resolve()
voice = args.audio.resolve()
output = args.output.resolve()
if not video.is_file() or not voice.is_file():
    raise SystemExit("Provide an existing source video and recorded narration audio file")
output.parent.mkdir(parents=True, exist_ok=True)

ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
command = [
    ffmpeg, "-y", "-i", str(video), "-i", str(voice),
    "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy",
    "-af", "apad", "-c:a", "aac", "-b:a", "160k",
    "-movflags", "+faststart", "-shortest", str(output),
]
subprocess.run(command, check=True, capture_output=True, text=True)
print(f"Created narrated video: {output} ({output.stat().st_size:,} bytes)")
