"""Export every SQL table to CSV (Day 2 Task 1: the knowledge-base datasets)."""
import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from sqlalchemy import text  # noqa: E402
from app import db  # noqa: E402

out = Path(__file__).resolve().parent.parent / "data" / "datasets"
out.mkdir(parents=True, exist_ok=True)
with db.conn() as c:
    for t in db.metadata.sorted_tables:
        rows = c.execute(text(f"SELECT * FROM {t.name}")).all()
        with open(out / f"{t.name}.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow([col.name for col in t.columns])
            w.writerows([list(r) for r in rows])
        print(f"{t.name}.csv  ({len(rows)} rows)")
