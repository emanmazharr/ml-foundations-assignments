"""One-time Google Calendar OAuth setup (only needed when CALENDAR_MODE=google).
1. Google Cloud Console -> new project -> enable "Google Calendar API".
2. OAuth consent screen (External, testing) -> add yourself as a test user.
3. Credentials -> Create OAuth client ID -> Desktop app -> download JSON.
4. Save it as secrets/google_credentials.json (gitignored) and run:  python scripts/google_auth.py
This opens a browser once, then writes secrets/google_token.json which auto-refreshes after that.
Alternative for servers: use a Service Account with domain-wide delegation instead (no browser step)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.config import get_settings  # noqa: E402
from app.services.calendar_service import GoogleCalendar  # noqa: E402

s = get_settings()
cred = Path(s.google_credentials_file)
if not cred.exists():
    sys.exit(f"Missing {cred}. Download your OAuth client JSON from Google Cloud Console and save it there.")
from google_auth_oauthlib.flow import InstalledAppFlow  # noqa: E402

flow = InstalledAppFlow.from_client_secrets_file(str(cred), GoogleCalendar.SCOPES)
creds = flow.run_local_server(port=0)
Path(s.google_token_file).parent.mkdir(parents=True, exist_ok=True)
Path(s.google_token_file).write_text(creds.to_json())
print(f"Saved {s.google_token_file}. Set CALENDAR_MODE=google in .env and you're done.")
