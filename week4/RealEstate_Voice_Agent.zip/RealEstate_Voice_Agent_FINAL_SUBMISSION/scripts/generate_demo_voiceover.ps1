param(
    [string]$SubtitlePath = (Join-Path $PSScriptRoot '..\demo_video.srt'),
    [string]$OutputPath = (Join-Path $PSScriptRoot '..\work\demo_video\voiceover.wav'),
    [string]$VoiceName = 'Microsoft Zira Desktop',
    [switch]$UseFishAudio,
    [string]$ApiBaseUrl = 'http://127.0.0.1:8000'
)

$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $SubtitlePath)) {
    throw "Subtitle file not found: $SubtitlePath. Run scripts/render_demo_video.py first."
}

Add-Type -AssemblyName System.Speech
$text = (Get-Content -LiteralPath $SubtitlePath -Raw) -replace '(?m)^\d+\s*$','' -replace '(?m)^\d{2}:\d{2}:\d{2},\d{3}\s+-->.*$',''
$captions = @($text -split '\r?\n\s*\r?\n' | ForEach-Object { ($_ -replace '\r?\n',' ').Trim() } | Where-Object { $_ })
if ($captions.Count -eq 0) { throw 'No subtitle captions were found.' }

if ($UseFishAudio) {
    $payload = @{ text = ($captions -join "`n") } | ConvertTo-Json -Compress
    $headers = @{}
    if ($env:DEMO_API_KEY) { $headers['X-Demo-Key'] = $env:DEMO_API_KEY }
    $mp3Path = [System.IO.Path]::ChangeExtension([System.IO.Path]::GetFullPath($OutputPath), '.mp3')
    try {
        $response = Invoke-WebRequest -Uri "$($ApiBaseUrl.TrimEnd('/'))/voice/speak" -Method Post `
            -ContentType 'application/json' -Headers $headers -Body $payload
        [System.IO.File]::WriteAllBytes($mp3Path, $response.Content)
        Write-Output "Created Fish Audio narration MP3: $mp3Path"
        Write-Output "The generated audio came from the configured Fish Audio account."
        exit 0
    }
    catch {
        throw "Fish Audio narration failed. Confirm the app is running, TTS_PROVIDER=fish, FISH_AUDIO_API_KEY is configured, and DEMO_API_KEY is set if needed. $($_.Exception.Message)"
    }
}

$synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {
    $available = @($synth.GetInstalledVoices() | ForEach-Object { $_.VoiceInfo.Name })
    if ($VoiceName -notin $available) {
        throw "Voice '$VoiceName' is unavailable. Installed voices: $($available -join ', ')"
    }
    try { $synth.SelectVoice($VoiceName) }
    catch { throw "Windows reports '$VoiceName' but the speech engine cannot access it. Try -UseFishAudio with a configured local server or record a voiceover. $($_.Exception.Message)" }
    $synth.Rate = -1
    $synth.Volume = 100
    $resolvedOutput = [System.IO.Path]::GetFullPath($OutputPath)
    $parent = Split-Path -Parent $resolvedOutput
    New-Item -ItemType Directory -Force -Path $parent | Out-Null
    $synth.SetOutputToWaveFile($resolvedOutput)
    foreach ($caption in $captions) { $synth.Speak($caption) }
    $synth.SetOutputToNull()
    Write-Output "Created offline computer-narrated WAV: $resolvedOutput"
    Write-Output "Voice: $VoiceName; captions: $($captions.Count). This is English narration, not Fish Audio or an UrduLish quality benchmark."
}
finally {
    $synth.Dispose()
}
