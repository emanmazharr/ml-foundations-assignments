"""Verify your Gemini key: lists usable models and makes one live test call.
Usage:  set GEMINI_API_KEY in .env, then  python scripts/check_gemini.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from app.config import get_settings  # noqa: E402

s = get_settings()
if not s.gemini_api_key:
    sys.exit("GEMINI_API_KEY is empty. Put it in .env (GEMINI_API_KEY=...) and set LLM_PROVIDER=gemini")
from google import genai  # noqa: E402

client = genai.Client(api_key=s.gemini_api_key)
names = [m.name.replace("models/", "") for m in client.models.list()
         if "generateContent" in (getattr(m, "supported_actions", None) or [])]
print("Models your key can use for text generation:")
for n in names:
    if "flash" in n:
        print("  ", n)
print(f"\nConfigured GEMINI_MODEL = {s.gemini_model}")
import os  # noqa: E402
os.environ["LLM_PROVIDER"] = "gemini"
get_settings.cache_clear()
from app import llm  # noqa: E402
out = llm.generate("You are a Pakistani real-estate sales agent.", "Say 'Assalam-o-Alaikum' greeting in one short UrduLish sentence.")
print("\nLive test:", out or "FAILED - check key / model name / quota")
