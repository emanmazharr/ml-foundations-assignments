# 10-Minute Slide Deck

1. Title — Production-Grade AI Voice Agent for Real Estate
2. Problem & Objective
3. End-to-End Architecture
4. UrduLish Persona & Conversation Design
5. RAG + Structured Property Intelligence
6. LangGraph State & Tool Orchestration
7. Calendar, Email & CRM Automation
8. Security, Guardrails & Evaluation
9. Fish Audio vs ElevenLabs
10. Demo Flow, Limitations & Future Roadmap
