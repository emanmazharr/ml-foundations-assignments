# Demo Video — Narrator and Agent Script

The captioned MP4 is about one minute long. Use the narration column for the narrator. To present the call interaction, switch roles for the two indented lines: speak as the caller first, pause, then answer in a calm agent voice using the agent's visible response. You can act both roles yourself; a small pause and a slightly different pace are enough. A second person or the browser's available speech voices can also read the agent lines.

| Time | Narration |
|---|---|
| 00:00–00:07 | RealEstate Hub is a local capstone MVP for property inquiries in Urdu and English. This video shows a text call flow and the optional browser voice demo. |
| 00:07–00:15 | A text or browser speech turn enters FastAPI and follows the LangGraph flow. Exact property facts come from SQLite; descriptive information uses semantic retrieval. Optional Deepgram and Fish Audio adapters provide speech recognition and generated voice. |
| 00:15–00:25 | The caller asks in Roman Urdu for a home in DHA Lahore, within a budget of thirty-five million Pakistani rupees. The agent responds using the sample inventory. |
| 00:25–00:35 | The agent can carry property context into a follow-up question. The listing and its details shown here are synthetic demo data, not a real property offer. |
| 00:35–00:44 | The workflow can collect visit details and record an appointment. In this demonstration, calendar, email and CRM steps use local mock services only. |
| 00:44–00:54 | The local checks passed: one hundred six tests, forty-nine conversation cases, and twenty RAG questions. The security suite caught all thirty-one tested cases. Provider requests were mocked in tests. |
| 00:54–01:02 | The browser demo can use device voices, and a signed turn-based Twilio webhook is included. A real call needs account keys and public HTTPS. Open slash demo to try the local browser experience. |

The video subtitles and `demo_video.srt` contain the same narrator script. The MP4 is caption-only because no local TTS engine can generate audio in this environment and no provider key is available. The subtitles are not an audio track and the visuals are not a live phone-call UI. The interactive `/demo` page can speak through supported browser voices; optional Fish Audio can generate actual MP3 speech after setup.

## Add a recorded voice track

Record yourself reading the narration above on a phone or computer, save it as WAV, MP3, or M4A, then place that file in this project folder. Or on a Windows computer with an accessible System.Speech voice, try the included offline narrator helper. Install the optional video dependencies if needed and run:

```bash
python -m pip install -r requirements-video.txt
pwsh -NoProfile -File scripts/generate_demo_voiceover.ps1
python scripts/mux_demo_audio.py work/demo_video/voiceover.wav
```

If you have Fish Audio configured in the running local API, use `pwsh -NoProfile -File scripts/generate_demo_voiceover.ps1 -UseFishAudio`; this writes an MP3 which can be passed to the same mux command. The offline helper writes a WAV only when Windows System.Speech is accessible. If both options are unavailable, record a voice track yourself. You may narrate in English or UrduLish. For a two-role sample, say the caller's line first, pause, and answer as the agent; do not pretend the generated narrator is a live agent call.
