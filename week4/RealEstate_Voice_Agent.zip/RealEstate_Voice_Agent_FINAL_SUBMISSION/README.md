# RealEstate Hub — Production-Grade AI Voice Agent (UrduLish)

Capstone: AI voice sales agent for a Pakistani real-estate company — RAG, LangGraph, Fish Audio, Google Calendar, n8n, FastAPI.

## Status: feature-complete, fully tested
| Day | Scope | Status |
|---|---|---|
| 1 | Architecture, conversation flows, UrduLish persona, Fish Audio evaluation, system prompt | ✅ `docs/day1_foundations.md`, `prompts/system_prompt.md`, `app/persona.py` |
| 2 | Knowledge base, SQL DB, RAG pipeline, chunk-size eval, structured-vs-semantic split, recommender, hallucination eval | ✅ `docs/rag_design.md` — 0% hallucination on 20 questions |
| 3 | Voice-ready text pipeline, natural speech fillers, context memory, objection handling | ✅ `app/persona.py`, `app/recommender.py` (memory), `app/agent/nodes.py::objection_node` |
| 4 | Google Calendar, email automation, appointment management, n8n workflow, CRM logging | ✅ `app/services/*`, `n8n/realestate_voice_agent.json` |
| 5 | LangGraph state, graph design, tool integration, validation, execution traces | ✅ `app/agent/*` |
| 6 | 49-scenario evaluation suite, prompt-injection testing, performance metrics, monitoring, Docker/CI | ✅ `eval/*`, `Dockerfile`, `.github/workflows/ci.yml` — 92/92 unit tests, 49/49 conversations, 100% end-to-end security |
| 7 | Deployment config, executive report, monitoring plan, demo script, roadmap | ✅ `docs/executive_report.md`, `docs/monitoring_and_maintenance.md`, `docs/demo_script.md`, `docs/future_enhancements.md` |

## Quick start (fully offline — no API keys needed)
```bash
pip install -r requirements.txt
python scripts/build_kb.py          # builds SQLite DB + knowledge-base documents
python -m pytest -q                 # 92 tests
python eval/rag_eval.py             # 20-question hallucination evaluation
python eval/chunk_eval.py           # chunk-size experiment
python eval/conversation_eval.py    # 49 end-to-end scripted conversations
python eval/security_eval.py        # 31 prompt-injection / security attacks
uvicorn app.main:app --reload       # API docs at http://localhost:8000/docs
```
Try a call:
```bash
curl -X POST localhost:8000/call/start -H "Content-Type: application/json" -d '{"caller_phone":"+923001234567"}'
curl -X POST localhost:8000/call/turn -H "Content-Type: application/json" -d '{"call_id":"<from above>","text":"DHA Lahore mein 3.5 crore tak ghar chahiye"}'
```

## Going live
1. Copy `.env.example` to `.env`.
2. `LLM_PROVIDER=gemini` + `GEMINI_API_KEY=...` — run `python scripts/check_gemini.py` to confirm.
3. `CALENDAR_MODE=google` — put your OAuth client JSON in `secrets/google_credentials.json`, run `python scripts/google_auth.py` once.
4. `EMAIL_MODE=resend` (or `smtp` with a Gmail App Password).
5. `DATABASE_URL=postgresql+psycopg2://...` for production (SQLite is fine for the demo).
6. `docker compose up --build`, or deploy the `Dockerfile` to Railway/Render/AWS.
Everything defaults to a fully offline mock mode until you flip these — nothing breaks if a key is missing, it just degrades gracefully (see `app/llm.py`, `app/services/email_service.py`, `app/services/calendar_service.py`).

## Layout
```
app/
  config.py, db.py, engine.py, recommender.py, guardrails.py, persona.py, llm.py, timeutil.py, logging_setup.py
  nlp/            UrduLish normaliser, budget/date/entity/slot parsers
  rag/             loader, chunker, embeddings, vector store, retriever, generator
  agent/           LangGraph state, nodes, graph wiring, call session runner
  services/        appointments, calendar (mock/Google), email (mock/Resend/SMTP), CRM
  main.py          FastAPI: /health /knowledge/ask /recommend /properties/{id} /call/* /admin/*
scripts/           build_kb.py, export_datasets.py, demo_step1.py, check_gemini.py, google_auth.py
eval/              questions.py, conversations.py (49 scenarios), rag_eval.py, chunk_eval.py,
                   conversation_eval.py, security_eval.py, results/*.md (generated reports)
n8n/               realestate_voice_agent.json (Call -> Intent -> Match -> Appointment -> Calendar -> Email -> CRM)
docs/              day1_foundations.md, rag_design.md, executive_report.md, monitoring_and_maintenance.md,
                   demo_script.md, future_enhancements.md
prompts/           system_prompt.md
Dockerfile, docker-compose.yml, .github/workflows/ci.yml
tests/             92 pytest tests across every module
```

## Evaluation results (reproducible — run the commands above)
- **92/92** unit + integration tests passing
- **0%** hallucination rate, **100%** grounding, **100%** correct abstention (20-question RAG eval)
- **49/49** end-to-end conversation scenarios passing (buyer, seller, investor, rental, appointment, cancel, reschedule, off-topic, injection ×6, angry customer, silent caller)
- **100%** end-to-end security pass rate across 31 adversarial prompt-injection attacks (one Layer-1 pattern-screen gap is documented and still caught downstream)

*All property/agent data is a synthetic demo set — replace via `scripts/build_kb.py` with the client's real inventory before go-live. See `docs/executive_report.md` §5 for full, honest limitations.*
