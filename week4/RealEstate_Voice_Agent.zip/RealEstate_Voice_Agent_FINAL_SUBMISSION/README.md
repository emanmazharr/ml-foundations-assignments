# RealEstate Hub — UrduLish Real Estate Agent (Capstone MVP)

An offline-first real estate agent prototype for Pakistani property inquiries. It combines a FastAPI/LangGraph conversation flow, SQL facts, semantic retrieval, recommendations, a browser microphone/speech demo, optional Deepgram STT and Fish Audio TTS adapters, and mock calendar/email/CRM services.

## Delivery status

This is a **local capstone MVP**, not a deployed production phone service. The repository includes a FastAPI text API and in-process sessions, a browser voice demonstration, optional Deepgram/Fish Audio adapters, and a signed, turn-based Twilio webhook adapter. A Twilio number, public HTTPS host, and provider credentials are not included; no phone call or cloud deployment was live-tested. Browser speech support depends on browser/device voices. The app also includes a LangGraph agent graph, SQLite demo database, Chroma/NumPy retrieval adapters, synthetic datasets, appointment and outbox workflows, security checks, evaluation scripts, Docker/CI configuration, diagrams, docs, and slides. Calendar/email modes need credentials and live validation.

| Week 4 day | Included artifacts | Status in this ZIP |
|---|---|---|
| 1 — Foundations | `docs/day1_foundations.md`, `docs/CONVERSATION_FLOWS.md`, `prompts/system_prompt.md`, persona code, provider comparison | Design + offline text implementation |
| 2 — Knowledge/RAG | `data/datasets/`, `data/kb/`, `app/db.py`, `app/rag/`, `app/recommender.py`, `docs/rag_design.md` | Local synthetic-data implementation |
| 3 — Conversation | `app/nlp/`, `app/agent/`, `app/persona.py`, `app/guardrails.py`, `app/voice.py`, `/demo` | Text graph plus browser mic/speech fallback and optional provider-backed audio turns |
| 4 — Workflows | `app/services/`, `n8n/realestate_voice_agent.json` | Local/mock implementations; external services optional |
| 5 — Agent | `app/agent/state.py`, `graph.py`, `nodes.py`, `session.py` | Implemented; requires dependencies to execute |
| 6 — Evaluation/security | `tests/`, `eval/`, `eval/results_snapshot/` | 106 tests passed; 49/49 conversation cases; 20/20 RAG questions correct; 31/31 tested security inputs caught |
| 7 — Delivery | `Dockerfile`, `docker-compose.yml`, `.github/workflows/ci.yml`, `docs/`, `slides/` | Configuration and handoff materials included; deployment not performed |

All property, agent, company and conversation examples are synthetic. Do not treat them as actual listings or customer information.

## Quick start

Use Python 3.12 in a virtual environment, then install the project dependencies:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/build_kb.py
python -m pytest -q
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/demo` for the interactive browser voice demo or `/docs` for the API. Click **Start a demo call**, then speak or type (for example, `DHA Lahore mein 3.5 crore tak 5 marla ghar chahiye`). The browser mic uses the browser's speech recognition if available; browser support and Urdu voice availability vary. To use Deepgram and Fish Audio, add their keys and see `docs/VOICE_SETUP.md`. The core local demo uses mock/default providers. `data/realestate.db` is a demo artifact; `scripts/build_kb.py` rebuilds it from the bundled synthetic CSV and KB material.

To use Docker Compose, first copy `.env.example` to `.env`, then run `docker compose up --build`; the app starts with mock providers by default. To update an existing GitHub repo from the delivery archive, follow [`docs/GITHUB_UPDATE_GUIDE.md`](docs/GITHUB_UPDATE_GUIDE.md).

## Demo video

The submission includes `demo_video.mp4`, a captioned walkthrough of local text-agent output. The MP4 remains caption-only; interactive `/demo` can speak with browser voices or optional Fish Audio when configured. The optional signed Twilio turn-based webhook is described in `docs/TELEPHONY_SETUP.md`, but is not connected to a real number. To add a separately recorded narration to the MP4, run `python scripts/mux_demo_audio.py my_voiceover.wav`; details are in `demo_video_script.md`. To regenerate the captioned walkthrough, run `python scripts/render_demo_video.py`. It uses a disposable database under `work/demo_video/` and does not overwrite `data/realestate.db`.

Automated checks run with a project-local Python environment, NumPy retrieval and mock business integrations. Fish Audio/Deepgram and Twilio network calls are mocked in tests. Calendar/email, live audio/phone, and deployment still require account credentials and external connectivity.

## Available HTTP endpoints

- `GET /health`
- `GET /demo`, `GET /voice/status`, `POST /voice/transcribe`, `POST /voice/speak`
- `POST /knowledge/ask`
- `POST /recommend`
- `GET /properties/{property_id}`
- `POST /call/start`
- `POST /call/turn`
- `GET /call/{call_id}/transcript`
- `POST /twilio/voice`, `POST /twilio/turn` (optional signed Twilio webhooks)
- `POST /admin/retry-outbox`, `POST /admin/retry-calendar-sync`, `GET /admin/stats`

The exact request models are documented by FastAPI at `/docs`. Protected demo routes require `X-Demo-Key` outside development; admin routes require `X-Admin-Key`. Twilio routes validate `X-Twilio-Signature` and also need Fish Audio TTS for audible responses; see `docs/TELEPHONY_SETUP.md`.

## Optional integrations

Copy `.env.example` to `.env` only if you need to configure optional providers. Never commit credentials. `CALENDAR_MODE=mock` and `EMAIL_MODE=mock` are safe defaults. Google Calendar, Resend/SMTP, Deepgram and Fish Audio need credentials and live smoke tests. See `docs/VOICE_SETUP.md` for audio setup and scope, and `docs/demo_script.md` for the 10-minute stakeholder presentation.

## Project map

`app/` contains the API, database, agent graph, NLP, RAG, voice and workflow services. `data/` contains synthetic source datasets, generated KB documents, a sample SQLite database and mock outbox. `eval/` contains scripts and dated-result snapshots. `tests/` contains 106 automated cases (including parametrized cases). `docs/` contains system design, prompts, API and operator guidance. The final deck is linked in the handoff document; the original source deck is retained beside it.
