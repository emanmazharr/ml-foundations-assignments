# Archive inspection and validation record

Inspection and local reruns performed 29 September 2026.

## Inventory and environment

- Original ZIP: 188 entries. The final GitHub update archive contains 203 files, including application/tests/docs, demo video, final slides, synthetic data, CI/Docker files, and setup guidance.
- Test source: pytest collects 106 cases with parameterization (latest run 29 September 2026).
- Runtime validation used a project-local Python 3.12 environment, mock integrations, `VECTOR_BACKEND=numpy`, and temporary SQLite databases under `work/`. The supplied `data/realestate.db` was not used as the test database.
- Windows needed the IANA `tzdata` package for `ZoneInfo("Asia/Karachi")`; it is now listed in `requirements.txt`.

## Checks run

- ZIP extraction paths checked for traversal: none found.
- `python -m compileall -q app scripts eval tests`: passed.
- `python -m pytest -q`: **106 passed**, including signed Twilio webhook and media-cache tests. Provider requests are mocked.
- `python eval/rag_eval.py`: 20 questions; 100% retrieval accuracy, answer accuracy, grounding, and correct abstention; 0 measured hallucinations.
- `python eval/conversation_eval.py`: **49/49 passed**, 0 node errors.
- `python eval/security_eval.py`: **31/31** caught by the first guardrail screen; 0 observed end-to-end leaks/fake bookings in this finite set.
- `python eval/chunk_eval.py`: hit@4 was 100% for both main and held-out questions at tested chunk sizes; 350-character size retained as a compact tie.
- `python scripts/smoke_demo_api.py`: health, browser demo, call start, call turn, and property lookup returned successfully.
- Smoke validation now uses its own disposable DB and KB under `work/api_smoke` so it does not collide with pytest KB generation.
- `python eval/conversation_eval.py`: 49/49 passed. `python eval/security_eval.py`: 31/31 tested cases caught.
- Twilio webhook tests use generated valid/invalid signatures and mocked audio; no live callback was performed.
- `python scripts/render_demo_video.py`: created `demo_video.mp4`, timed captions (`demo_video.srt`), and updated the architecture image to distinguish implemented and future integrations. MP4 was decoded and sampled visually.
- SQLite sample database integrity check: `ok`; PowerPoint ZIP integrity check: passed.

Fresh dated evaluation outputs are stored under `eval/results_snapshot/current_2026-09-29_*`. Existing original snapshot files were retained for provenance. Docker Compose YAML was parsed successfully, but Docker is not installed here, so image build/container health, ChromaDB backend, live integrations, live STT/TTS, Twilio call, and external deployment were not tested. The included video is caption-only; interactive browser speech runs at `/demo` and Fish Audio can generate a voice response when configured.
