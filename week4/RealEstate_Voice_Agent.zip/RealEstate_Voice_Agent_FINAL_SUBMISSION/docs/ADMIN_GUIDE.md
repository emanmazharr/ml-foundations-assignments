# Admin Guide — demo environment

## Refresh synthetic inventory and knowledge base

The bundled source-of-truth demo files are under `data/datasets/` (CSV tables) and `data/kb/` (Markdown/JSON knowledge). `scripts/build_kb.py` builds the SQLite database and retrieval index from this project data. Review the script before adapting it to a client's format; the input mapping is not an automatic live feed. Keep property facts consistent between structured records and brochures.

## Update the persona

Edit `prompts/system_prompt.md` and `app/persona.py` together, then review `app/agent/nodes.py` and `app/guardrails.py` for behavior that is enforced in code. The active MVP uses an offline/mock language path by default. The prompt file alone does not activate a hosted LLM.

## Optional services

- Calendar: `app/services/calendar_service.py` selects mock or Google Calendar behavior. Google OAuth configuration is in `.env.example` and the setup helper is `scripts/google_auth.py`.
- Email: `app/services/email_service.py` supports a local/mock outbox and optional provider modes. No credentials are included.
- CRM: `app/services/crm.py` writes local demo records; a production CRM connector is not included.
- Voice: `/demo` serves the browser mic/text UI. `app/voice.py` implements turn-based Deepgram upload transcription and Fish Audio speech output when keys are configured. This is not a streaming phone integration; see `docs/VOICE_SETUP.md`.

## Secrets and deployment

Copy `.env.example` to `.env`, add only credentials required for the chosen optional provider, and keep both files out of version control. Set a strong `ADMIN_API_KEY` whenever `APP_ENV` is not `development`. `secrets/README.md` describes local secret handling. Docker and compose files are deployment starting points; no cloud deployment or live credential validation was performed. See `docs/API.md` for endpoint security and session limitations before exposing the service.
