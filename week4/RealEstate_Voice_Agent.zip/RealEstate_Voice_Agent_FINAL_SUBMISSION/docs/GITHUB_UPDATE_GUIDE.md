# Update your GitHub repository from this ZIP (Windows)

The archive contains a complete folder named `RealEstate_Voice_Agent_FINAL_SUBMISSION`. GitHub does not unpack a project ZIP as repository files by uploading the ZIP itself: extract it and copy the **contents** into your repository checkout.

## GitHub Desktop method

1. Download and extract `RealEstate_Voice_Agent_FINAL_SUBMISSION.zip`.
2. Open your repository with GitHub Desktop and choose **Show in Explorer**.
3. Open the extracted `RealEstate_Voice_Agent_FINAL_SUBMISSION` folder in another Explorer window.
4. Copy its project files—including hidden files such as `.gitignore` and `.env.example`—into the repository folder. Merge/replace matching project files. Do not delete the repository's hidden `.git` folder. Do not copy local `.env`, `.venv`, or `work` files from your computer.
5. Review GitHub Desktop's **Changes** list. Confirm no API keys, Google credential JSON, local virtual environment, or private customer data are selected.
6. Commit with a message such as `Complete Week 4 real estate voice agent MVP`, then push to GitHub.

## Git command-line method

Open PowerShell in the parent folder containing the ZIP and your cloned repository. Replace the repo folder name with your actual one:

```powershell
Expand-Archive -LiteralPath .\RealEstate_Voice_Agent_FINAL_SUBMISSION.zip -DestinationPath .\week4-update -Force
robocopy .\week4-update\RealEstate_Voice_Agent_FINAL_SUBMISSION .\my-realestate-repo /E /XD .git .venv work .pytest_cache /XF .env .env.local
Set-Location .\my-realestate-repo
git status --short
git diff --check
git add -A
git commit -m "Complete Week 4 real estate voice agent MVP"
git push
```

`robocopy` uses exit code 1 when files were copied successfully; that is normal. Review `git status` before committing. Never add real API keys or customer data. If your repository has unrelated work, commit or back it up before replacing overlapping files.

The app expects Python 3.12. A virtual environment is intentionally not included in the ZIP; install dependencies from `requirements.txt`. Follow the root README to run the app. Docker Compose currently reads `.env`, so copy `.env.example` to `.env` before `docker compose up --build` (leave mock providers enabled for the offline demo).
