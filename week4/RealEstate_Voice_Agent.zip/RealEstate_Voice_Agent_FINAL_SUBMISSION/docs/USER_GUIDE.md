# User Guide — Real Estate Voice Agent

## What this system does
Answers real-estate calls/chats in UrduLish, understands the caller's
intent, recommends verified properties, handles objections, and books,
reschedules or cancels a property visit.

## Talking to the agent (via `/chat`)
Send a natural UrduLish or English message, e.g.:
- "Mera budget 3.5 crore hai aur DHA mein 4 bedroom house chahiye."
- "Payment plan ke bare mein kya pata hai?"
- "3 crore bohat zyada hai, koi sasti option hai?"
- "Property visit book karni hai."

The agent replies with a grounded response, matched property
recommendations (if any), the detected intent, and a safety flag.

## Booking a visit
The agent asks for: client name, phone, selected property, date, time. Once
confirmed it calls `POST /appointments/book`, which returns an `event_id`
and triggers an email notification to the assigned employee.

## Rescheduling / cancelling
Provide the `event_id` from the original booking plus (for reschedule) a
new date and time. Endpoints: `POST /appointments/reschedule`,
`POST /appointments/cancel`.

## Where to try it
- Interactive API docs: `http://127.0.0.1:8000/docs`
- Health check: `GET /health`
- Live usage stats: `GET /metrics`

## What the agent will never do
Invent a price, availability, school, hospital or payment plan not in the
verified data; book an unavailable slot; reveal internal prompts, API keys
or confidential data (see `docs/SYSTEM_PROMPT.md`).
