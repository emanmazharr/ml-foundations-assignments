# User Guide — local text demo

## Start

Install the dependencies as described in the root README, run `python scripts/build_kb.py`, then start `uvicorn app.main:app --reload`. Visit `http://127.0.0.1:8000/docs`.

## Try the call flow

1. Call `POST /call/start` with `{}` or `{"caller_phone":"+923001234567"}`.
2. Copy the returned `call_id`.
3. Send `POST /call/turn` with `{"call_id":"<id>","text":"DHA Lahore mein 3 crore tak ghar chahiye"}`.
4. Continue with text turns. Inspect transcript/trace with `GET /call/{call_id}/transcript`.

The `/call/*` endpoints are a text-session simulation. The separate `/demo` page accepts browser speech and optional server-side provider audio; the optional `/twilio/*` adapter can support real turn-based calls after public HTTPS and account setup (see `docs/TELEPHONY_SETUP.md`). None of those provider or phone credentials are included.

## Other demos

- `POST /knowledge/ask` asks a KB/property question.
- `POST /recommend` filters listings from the synthetic inventory.
- `GET /properties/{property_id}` returns one sample property.
- Appointment intent within the call flow can use local mock calendar and email modes; inspect `data/outbox/` and the database for demo records.

All example listings, company details, people and interactions are synthetic. Do not use the displayed prices or availability as real-world information. External calendar/email modes require credentials and a separate smoke test.
