# Executive Report — RealEstate Hub AI Voice Agent

## 1. Objective
Replace inconsistent, expensive manual phone coverage with an AI voice agent that answers property inquiries 24/7 in natural UrduLish, gives factually grounded answers, recommends suitable properties, handles objections, and books/reschedules/cancels visits — integrated with the company's calendar, email, and CRM.

## 2. What was built
A LangGraph-orchestrated conversational agent (`app/agent`) backed by:
- A **hybrid knowledge engine** (`app/engine.py`): SQL for exact, changeable facts (price, availability, size, agent, instalments) and a RAG pipeline (`app/rag`) over ChromaDB for descriptive knowledge (brochures, area guides, FAQs, developer profiles) — see `docs/rag_design.md` for the full justification and measured results.
- A **UrduLish understanding layer** (`app/nlp`): budget/date/entity parsing for Roman-Urdu phrases like "dhai crore", "kal shaam 5 baje", "us se sasti".
- A **recommendation engine** (`app/recommender.py`) with hard availability/budget constraints and explainable, disclosed relaxation when no exact match exists.
- **Appointment management** (`app/services/appointments.py`) with hard-coded policy (hours, notice period, no double-booking) that cannot be overridden by any prompt, plus Google Calendar and email (Gmail/Resend) integration with automatic retry on outage.
- **CRM logging** (`app/services/crm.py`): every call, transcript, preference, appointment, and follow-up reminder, ready to export to Salesforce/HubSpot.
- **Defence-in-depth guardrails** (`app/guardrails.py` + system prompt + tool validation) against prompt injection, data exfiltration, and abuse of the booking system.

## 3. Evaluation results (all reproducible — see `eval/`)
| Suite | Result | What it measures |
|---|---|---|
| Unit + integration tests | **92/92 passing** | Every module: NLP parsing, DB queries, RAG routing, booking policy, CRM, agent nodes, guardrails |
| Hallucination evaluation (20 Q) | **0% hallucination, 100% grounding, 100% correct abstention** | The agent never asserts an unverified fact and correctly declines out-of-scope questions |
| Chunk-size experiment | 350 chars chosen (ties for best on held-out questions) | RAG retrieval quality is stable across the tested KB |
| 49-scenario conversation suite | **49/49 passing**, incl. 6/6 buyer, 5/5 booking, 2/2 reschedule/cancel, 6/6 objections, 6/6 injection attacks | End-to-end behaviour across every required category (buyer, seller, investor, rental, appointment, cancellation, rescheduling, off-topic, injection, angry customer, silent caller) |
| Security / prompt-injection (31 attacks) | **100% layer-1 catch rate** (excl. one documented obfuscation gap), **100% end-to-end safety** (zero leaks or fake bookings, including the documented gap — later layers hold) | Deliberately adversarial: instruction override, fake authority, data exfiltration, bulk/fake booking abuse |
| Latency (avg / p95, mock LLM path) | 108ms / 194ms per turn (text-processing only, excludes STT/TTS/network) | Full voice round-trip depends on the chosen telephony/STT/TTS stack; architecture targets < 2s end-to-end per the brief |

All numbers above come from a synthetic 42-property demo dataset (`scripts/build_kb.py`) and should be re-measured on the client's real inventory before go-live — see the **Limitations** section of `docs/monitoring_and_maintenance.md`.

## 4. Architecture summary
See `docs/day1_foundations.md` for the full diagram. In one sentence: telephony → STT → **deterministic LangGraph agent** (policy in code, language in the LLM) → SQL/RAG knowledge → Calendar/Email/CRM → TTS → caller, with n8n handling cross-cutting retries and ops alerts.

## 5. Limitations (disclosed, not hidden)
1. Demo data is synthetic; real hallucination/retrieval numbers must be re-measured on the client's inventory.
2. Fish Audio's Urdu pronunciation quality has not been empirically A/B tested with real audio in this project — required before launch.
3. The Layer-1 guardrail pattern screen has one documented bypass class (character-spaced obfuscation of instruction-override phrases); mitigated by downstream layers today, worth adding an LLM-based classifier layer for defense-in-depth at scale.
4. Voice pipeline latency (STT+LLM+TTS end-to-end) has not been measured against live telephony in this environment — the < 2s target is an architecture goal, not yet a measured production number.
5. This is a v1: no WhatsApp/SMS, no multi-agent load balancing, no analytics dashboard yet — see the Roadmap.

## 6. Roadmap
See `docs/future_enhancements.md`.

## 7. Recommendation
The system is functionally complete and passes its full evaluation suite. Recommended next steps before client go-live: (a) load the client's real property inventory, (b) a live Fish Audio Urdu pilot, (c) a short shadow-mode period (agent runs alongside human agents, not yet answering real calls) to validate against real caller phrasing.
