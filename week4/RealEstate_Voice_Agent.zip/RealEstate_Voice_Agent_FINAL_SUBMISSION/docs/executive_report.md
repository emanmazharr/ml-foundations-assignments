# Executive Report — RealEstate Hub UrduLish Agent MVP

## Objective and delivery

This capstone demonstrates a property inquiry workflow in UrduLish. The archive includes an interactive browser speech demo, optional Deepgram/Fish Audio adapters and an optional signed turn-based Twilio webhook, alongside the FastAPI API, LangGraph conversation flow, synthetic inventory and KB, SQLite/RAG split, recommendation logic, appointment rules, mock calendar/email/CRM workflows, security checks, CI/Docker configuration, diagrams, documentation, and slide deck.

It is a local browser/text MVP, not a deployed production phone agent. Listings and company/person records are synthetic. Browser audio APIs are device-dependent; external STT/TTS requires API credentials and was not live-tested. Twilio webhook code is included but no phone number/public deploy exists; it is turn-based and process-local. Calendar and email demo modes are local mocks. UrduLish pronunciation quality has not been tested.

## Current verification (29 September 2026)

| Check | Result |
|---|---|
| Unit/integration tests | **106 passed** (including parameterized and signed-webhook test cases) |
| Text conversation evaluation | **49/49 passed**; 0 node errors |
| RAG evaluation | **20/20 checks correct**, retrieval/grounding 100%, measured hallucination 0%, correct abstention 100% |
| Security evaluation | **31/31 tested inputs caught**; zero end-to-end leaks or fake bookings in this finite suite |
| Chunk experiment | Hit@4 100% on held-out and main RAG questions at all tested sizes; 350 characters chosen as a compact tie |
| API smoke check | `/health`, `/demo`, `/call/start`, `/call/turn`, and `/properties/1` returned successfully |
| Demo video | MP4 decoded and sampled for visual review; caption-only, with a matching SRT and read-aloud script |

Checks used synthetic data, the NumPy retrieval fallback, and mock integrations. Dated results are under `eval/results_snapshot/current_2026-09-29_*`. They measure this small demo corpus, not a client inventory or a production phone call.

## Limits before production

1. Replace synthetic property data with approved, regularly refreshed client inventory and re-run the evaluations.
2. Add authentication and authorization, rate limits, durable shared call state, backup/retention controls, and operational monitoring.
3. Configure the optional Twilio/Deepgram/Fish Audio paths with real accounts, then run an UrduLish listening, interruption, security, and latency pilot. Full-duplex voice remains future work.
4. Configure and smoke-test live Calendar/email permissions and recovery behavior.
5. Deploy first in shadow mode with human fallback; no hosting deployment or production SLA has been tested.

See `SUPERVISOR_HANDOFF.md` for the quick demo instructions and a short presentation explanation.
