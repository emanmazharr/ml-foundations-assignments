# Monitoring & Maintenance Plan (Day 6 Task 4, Day 7 Task 3)

## What is tracked and where
| Signal | Source | Where to look |
|---|---|---|
| Latency per turn (avg, p95) | `crm.log_node_event` per graph node | `GET /call/{id}/transcript` (trace); aggregate via `eval/conversation_eval.py` metrics |
| LLM call count / error rate / avg latency | `app/llm.py::stats()` | `GET /admin/stats` |
| Booking success / conflicts / validation failures | `app/services/appointments.py` results (`ok`, `reason`) | `node_events` table, `tool_outputs` in state |
| Email delivery (sent/pending/failed) | `outbox` table | `GET /admin/stats`, `email_service.outbox_stats()` |
| Calendar sync failures | `appointments.sync_status='pending'` | `POST /admin/retry-calendar-sync` (also fixes them) |
| RAG grounding / hallucination | `eval/rag_eval.py` | `eval/results/rag_eval.md` (run in CI on every push) |
| Guardrail effectiveness | `eval/security_eval.py` | `eval/results/security_eval.md` (run in CI) |
| Conversation-level success rate | `eval/conversation_eval.py` | `eval/results/conversation_eval.md` (run in CI) |
| Structured application logs | `app/logging_setup.py` (JSON to stdout in production) | Docker/Railway/Render log viewer, or forward to Datadog/CloudWatch |
| Liveness / dependency health | `GET /health` | Docker `HEALTHCHECK`, uptime monitor (UptimeRobot/BetterStack) |

## Alert thresholds (recommended starting points — tune after 2 weeks of real traffic)
| Metric | Warning | Page on-call |
|---|---|---|
| p95 turn latency | > 2.0s | > 4.0s |
| `/health` failing | 1 consecutive failure | 3 consecutive failures (≈90s) |
| Email outbox `pending` count | > 5 | > 20 |
| Calendar `sync_status='pending'` count | > 3 | > 10 |
| LLM error rate (`llm.stats()['errors']/['calls']`) | > 10% over 15 min | > 30% over 15 min (agent auto-degrades to templates, so this is not an outage, but should be investigated) |
| Conversation success rate (weekly `eval/conversation_eval.py` run) | < 95% | < 85% |
| Hallucination rate (weekly `eval/rag_eval.py` run) | > 0% on any non-abstain question | any regression from the last approved baseline |

## Uptime target
99.5% for the API (≈ 3.6 hours/month downtime budget) is a reasonable starting SLA for a v1 client deployment on Railway/Render with the built-in health check and 2 uvicorn workers. Tighten to 99.9% only after the client's call volume and the calendar/email provider's own SLAs justify multi-region deployment.

## Recurring maintenance
| Task | Cadence | How |
|---|---|---|
| Vector index refresh (new/changed properties) | On every inventory change (ideally same-day) | Re-run `python scripts/build_kb.py` against the client's real data source, then redeploy or hot-reload the retriever |
| Outbox / calendar-sync retry | Every 5 minutes | n8n cron node (`n8n/realestate_voice_agent.json`) calling `/admin/retry-outbox` and `/admin/retry-calendar-sync` |
| Conversation + security + RAG eval suite | Every push (CI) + weekly on production data samples | `.github/workflows/ci.yml`; add a scheduled workflow for weekly production-sample review |
| Prompt updates | After any evaluation regression or new objection pattern observed in real calls | Edit `prompts/system_prompt.md` and/or `app/persona.py`; re-run the full eval suite before deploying |
| Backup strategy | Daily automated DB snapshot (Railway/Render managed Postgres backups, or `pg_dump` cron to S3) | Retain 14 daily + 4 weekly snapshots; test restore quarterly |
| Security review | Monthly, or after any guardrail change | Re-run `python eval/security_eval.py`, review `eval/results/security_eval.md` for new gaps, update `app/guardrails.py` |
| Dependency updates | Monthly | `pip list --outdated`; re-run full test suite before merging |
| Google/Gemini/Fish Audio API key rotation | Per provider's recommended cadence (typically quarterly) | Update `.env` / deployment secrets; no code change needed |

## Known limitations to disclose to the client
- Guardrails are a deterministic pattern screen plus system-prompt instructions plus hard-coded booking validation (defence in depth) — not a formal proof. `eval/security_eval.py` documents one known gap (character-spaced obfuscation of "ignore instructions") and should be re-run after any prompt/model change.
- The demo knowledge base (`scripts/build_kb.py`) is synthetic. Hallucination-rate and retrieval-accuracy numbers in `docs/rag_design.md` should be re-measured on the client's real inventory before go-live.
- Fish Audio's Urdu/UrduLish pronunciation quality has not been empirically tested in this project (see `docs/day1_foundations.md` Task 4) — a short pilot with real audio is a prerequisite for launch, not an afterthought.
