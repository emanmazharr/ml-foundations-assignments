# API Reference — implemented local MVP

The API is a FastAPI local agent service. Open `/docs` while it is running for generated schemas. The browser demonstration is at `/demo`. Voice routes are turn-based; the optional Twilio path is a webhook/Gather loop, not low-latency streaming.

## Voice demonstration and provider routes

- `GET /demo` serves the self-contained microphone/text conversation page.
- `GET /voice/status` reports provider readiness without exposing key values.
- `POST /voice/transcribe?language=ur|en|multi` accepts raw audio bytes (WAV, WebM, OGG, MP3, M4A, AAC or FLAC, maximum 20 MB) and sends them to Deepgram Nova-3 when `DEEPGRAM_API_KEY` is set.
- `POST /voice/speak` accepts `{"text":"Ji bilkul"}` and returns Fish Audio MP3 when `FISH_AUDIO_API_KEY` is set.
- `POST /twilio/voice` handles the configured inbound-call webhook and returns TwiML; `POST /twilio/turn` processes the speech transcript supplied by Twilio.
- `GET /twilio/media/{token}.mp3` serves short-lived generated audio referenced by TwiML. The opaque URL token expires after ten minutes.

The browser fallback uses built-in browser speech APIs if available. Browser recognition may send audio to the browser's speech provider. Provider modes require network access and may incur provider charges; see `docs/VOICE_SETUP.md`.

Twilio webhooks require `TWILIO_AUTH_TOKEN`, a public `https://` `TWILIO_PUBLIC_BASE_URL`, a configured Twilio number, and Fish Audio TTS credentials. Requests are signature-checked. Call sessions and media cache are process-memory only; use one worker for this demo. See `docs/TELEPHONY_SETUP.md` for setup and limits.

## `GET /health`

Returns database/retriever status and loaded property/chunk counts. This is a local service health check, not a full external-provider readiness check.

## `POST /knowledge/ask`

Request: `{"question":"Property 1 ki price kya hai?"}`. Returns a factual answer using the SQL/RAG engine and latency for the request.

## `POST /recommend`

Accepts structured filters such as `budget_max`, `city`, `area`, `bedrooms`, `purpose`, `ptype`, and `limit`; an optional `utterance` is parsed for UrduLish preferences. Response is based on the synthetic demo inventory unless it is replaced.

## `GET /properties/{property_id}`

Returns one property and its payment-plan rows, or `404` if it is not in the local database.

## Text call-session endpoints

1. `POST /call/start` with optional `{"caller_phone":"+92300..."}` creates an in-process session and returns `call_id` plus a greeting.
2. `POST /call/turn` with `{"call_id":"...","text":"DHA Lahore mein 3 crore tak ghar chahiye"}` processes a text turn.
3. `GET /call/{call_id}/transcript` returns the stored transcript and graph-node trace.

Sessions live in process memory. They are not durable or shared between multiple workers. The Dockerfile runs one worker for the local demo; multi-replica deployment needs shared state or sticky routing.

## Admin endpoints

- `POST /admin/retry-outbox` retries queued mock/provider email work.
- `POST /admin/retry-calendar-sync` retries pending calendar synchronization.
- `GET /admin/stats` summarizes local call/appointment/outbox counts.

In local development, admin endpoints remain available for the demo. When `APP_ENV` is not `development`, they fail closed until `ADMIN_API_KEY` is configured and require `X-Admin-Key`. Add rate limiting, account authorization, TLS and secrets-management before exposing the service publicly.
