# API Documentation

## GET /health
Returns service health.

## POST /voice/synthesize
Body: `{"text": "..."}`. Returns `audio/mpeg` bytes from Fish Audio when
`FISH_API_KEY` is set (see `docs/FISH_AUDIO_EVALUATION.md`); returns a
`text/plain` stub in demo mode. 502 with the upstream error message if
Fish Audio fails after 3 retries.

## GET /voice/status
Returns `{"provider": "fish-audio"|"demo", "live": true|false}` so the
frontend/telephony layer knows whether real audio is configured.

## POST /chat
Request:
```json
{"session_id":"demo-001","message":"Mera budget 3 crore hai aur DHA mein 4 bedroom house chahiye.","history":[]}
```

Response contains intent, response, recommendations, safety flag and trace.

## POST /appointments/book
Requires client name, phone, property, date and time.

## POST /appointments/reschedule
Requires event ID, date and time.

## POST /appointments/cancel
Requires event ID.

Swagger UI: `/docs`
