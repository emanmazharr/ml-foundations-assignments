# System Architecture

![Local MVP architecture with future audio adapters labeled](diagrams/architecture_diagram.png)

## Implemented runtime

Browser text/mic -> FastAPI -> LangGraph conversation state -> SQLite exact-property lookups + semantic KB retrieval -> local mock calendar/email services and CRM trace -> agent text -> browser voice or optional Fish Audio MP3. Browser-recognized speech or optional Deepgram upload transcription provides text input.

The call session is held in process memory. The default data is synthetic, SQLite is used for the local demo, and calendar/email integrations default to mock mode. The `/demo` browser UI supports browser speech APIs; server-side Deepgram transcription and Fish Audio TTS are optional key-based adapters. An optional signed Twilio Gather webhook at `/twilio/voice` and `/twilio/turn` is implemented, but no phone number, public HTTPS deployment or live provider access was configured/tested.

## Designed extensions

Continuous audio streaming, barge-in, and interruption-aware duplex operation remain future integrations. The turn-based Twilio adapter and optional Deepgram/Fish Audio adapters require account credentials, deployment, and end-to-end tests; run an UrduLish voice-quality/latency pilot before any client use. Google Calendar and email modes have optional code paths but were not configured or live-tested for this submission.

## Retrieval split

Use structured SQL fields for price, availability, bedrooms, city, area, property type, agents and payment-plan values. Use semantic retrieval for brochures, FAQs, policies, area guides and developer profiles. Keep facts consistent between the two stores.

## State and safety

The graph carries call ID, conversation turns, customer preferences, intent, property focus, recommendations and tool results. Guardrails and booking constraints are enforced in code. In development, admin operations remain open for the classroom demo. In other environments, they require the configured `ADMIN_API_KEY` via `X-Admin-Key`. Public deployment still requires TLS, user authorization, rate limiting, and monitoring.

## Operations

The app exposes `/health` and local trace/statistics endpoints. It does not expose the `/metrics` endpoint or request middleware described in the original project notes. Runtime monitoring, multi-worker shared sessions, deployment SLAs and alerting require additional implementation and operational setup.
