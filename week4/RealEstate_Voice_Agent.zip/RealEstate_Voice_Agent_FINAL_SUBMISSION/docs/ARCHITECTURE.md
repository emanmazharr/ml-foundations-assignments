# System Architecture

![Architecture diagram](diagrams/architecture_diagram.png)

## End-to-end pipeline

Caller -> Telephony -> Speech-to-Text -> FastAPI -> LangGraph -> Intent -> Structured Property SQL/Data -> RAG -> Recommendation -> Tool Call -> Calendar/Email/CRM -> LLM Response -> TTS -> Caller

## Layers

1. **Voice layer:** telephony + STT + TTS.
2. **API layer:** FastAPI endpoints.
3. **Agent layer:** LangGraph state machine.
4. **Knowledge layer:** structured property records plus semantic company knowledge.
5. **Workflow layer:** calendar, email and CRM tools.
6. **Safety layer:** prompt-injection detection, availability validation, human escalation.
7. **Observability:** node traces, CRM records and evaluation suite.

## Structured vs semantic retrieval

SQL/structured data is used for price, availability, bedrooms, city, area, property type and developer because exact filters must be deterministic.

Semantic retrieval is used for brochures, FAQs, payment explanations and descriptive knowledge because meaning-based matching is more useful than exact field filters.

## State

- conversation history
- user profile
- property preferences
- budget
- intent
- retrieved context
- recommendations
- tool outputs
- appointment status
- trace

## Monitoring

Every request is timed by a FastAPI middleware and appended to
`logs/monitoring.jsonl` (path, status code, latency). `GET /metrics`
aggregates this into request count, average latency, error rate and a
per-endpoint breakdown, so latency thresholds and API failures can be
tracked without an external APM tool.

## Failure handling

- Missing booking fields -> ask for the missing fields.
- Unavailable slot/property -> do not book; ask for another slot/property.
- Provider/API failure -> retry, log, then escalate.
- Prompt injection -> refuse protected request and continue with safe real-estate assistance.
