# Official Sources Used for Voice Provider Comparison

Fish Audio Developers: https://fish.audio/developers/
Fish Audio TTS API: https://fish.audio/text-to-speech-api/
Deepgram STT models and language support: https://developers.deepgram.com/docs/models-languages-overview
Deepgram streaming STT guide: https://developers.deepgram.com/docs/live-streaming-audio
Twilio request signature security: https://www.twilio.com/docs/usage/security
Twilio Voice TwiML Gather reference: https://www.twilio.com/docs/voice/twiml/gather
Twilio Media Streams (full-duplex streaming is not implemented): https://www.twilio.com/docs/voice/media-streams
ElevenLabs Streaming TTS: https://elevenlabs.io/docs/api-reference/text-to-speech/stream
ElevenLabs API Pricing: https://elevenlabs.io/docs/api-reference/text-to-speech/stream
ElevenLabs TTS overview: https://elevenlabs.io/docs/overview/capabilities/text-to-speech
