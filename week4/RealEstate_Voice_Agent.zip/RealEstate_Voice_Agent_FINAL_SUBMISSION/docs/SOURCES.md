# Official Sources Used for Voice Provider Comparison

Fish Audio Developers: https://fish.audio/developers/
Fish Audio TTS API: https://fish.audio/text-to-speech-api/
ElevenLabs Streaming TTS: https://elevenlabs.io/docs/api-reference/text-to-speech/stream
ElevenLabs API Pricing: https://elevenlabs.io/docs/api-reference/text-to-speech/stream
ElevenLabs TTS overview: https://elevenlabs.io/docs/overview/capabilities/text-to-speech
