# Conversation Flow Diagrams

![Conversation flow diagrams](diagrams/conversation_flows.png)

Six flows are designed and diagrammed above, matching the Day 1 Task 2
requirement:

1. **Buyer inquiry** — greet → detect intent → extract budget/city/area/
   bedrooms → structured search + RAG → present grounded recommendations →
   offer to book a visit.
2. **Rental inquiry** — greet → detect intent (`rental`) → extract budget/
   area → search `purpose=rent` → present options → handle objection or
   move to booking.
3. **Commercial inquiry** — greet → detect intent (`commercial`) → extract
   city/area/type → search `purpose=commercial` → present verified
   listings → offer booking.
4. **Investment inquiry** — greet → detect intent (`investment`) → ask
   investment goals → search `purpose=investment` → present ROI-relevant
   options → confirm interest → book or send details.
5. **Appointment rescheduling** — greet → detect intent → collect event ID
   + new date/time → check availability → update calendar + notify
   employee → confirm to caller.
6. **Appointment cancellation** — greet → detect intent → collect event ID
   → validate the event exists → cancel in calendar + notify employee →
   confirm to caller → log in CRM.

**Returning customer** flow is handled through LangGraph state rather than
a separate branch: `property_preferences` and `budget` persist in
`AgentState` across turns within a session, so "Budget 3 crore hai" →
"DHA mein kya options hain?" → "Us se sasti koi option?" resolves using
memory instead of asking the customer to repeat themselves (see
`app/agent.py::extract_preferences` and the `T{31-33}` test cases in
`evaluation/test_cases.json`).
