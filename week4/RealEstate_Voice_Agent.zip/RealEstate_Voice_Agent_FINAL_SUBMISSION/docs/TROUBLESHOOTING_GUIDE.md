# Troubleshooting Guide

## Server will not start

- `ModuleNotFoundError`: activate the intended virtual environment and run `python -m pip install -r requirements.txt`.
- Port in use: choose another port with `uvicorn app.main:app --reload --port 8001`.
- DB/index errors: run `python scripts/build_kb.py` from the project root and check `DATABASE_URL`, `CHROMA_DIR` and `VECTOR_BACKEND` in `.env`.

## Recommendation is empty

No available synthetic demo property may satisfy every requested filter. Check the bundled demo tables in `data/datasets/` and try a wider budget, area or bedroom constraint. Do not promise a listing until availability is verified.

## Guardrail does not flag a phrase

The pattern checks in `app/guardrails.py` are limited and are not a security proof. Add a test for any proposed rule change in `tests/test_guardrails.py`, then run the tests and `python eval/security_eval.py` after installing dependencies. The security script documents a known obfuscation case.

## Booking does not proceed

The text agent collects missing customer/property/date/time details and applies booking policy in `app/services/appointments.py`. Inspect the turn response and local state/transcript via `GET /call/{call_id}/transcript`. External calendar synchronization is optional; mock mode records locally.

## Email or calendar not delivered externally

The default modes are mock. Check `EMAIL_MODE` or `CALENDAR_MODE`, credentials and provider permissions, then check the outbox/sync status using `/admin/stats` and the retry endpoints. Provider delivery has not been validated just because a local outbox item exists.

## Evaluation suite

From the project root, after installing requirements, run `python -m pytest -q`, then individual scripts such as `python eval/conversation_eval.py`. The checked-in `eval/results_snapshot/` files are historical examples and may not match a fresh run.

## Security before deployment

In development, admin endpoints are open for local demonstrations. Outside development, set a strong `ADMIN_API_KEY`; otherwise admin actions fail closed with 503. Requests must send `X-Admin-Key`. The call-session registry remains in process memory and properties remain synthetic. Before public exposure, add account-level authorization, rate limits, shared durable call state and real-data validation.

## Voice demo issues

- Open `http://127.0.0.1:8000/demo` in a supported browser. The microphone permission typically requires `localhost` or HTTPS.
- If **Speak (browser mic)** is disabled, the browser does not expose the Web Speech recognition API; type the turn instead or configure Deepgram.
- If **Record & transcribe** is disabled, set `STT_PROVIDER=deepgram` and `DEEPGRAM_API_KEY`, then restart the API.
- If replies are text-only, check `speechSynthesis` support or configure `TTS_PROVIDER=fish` and `FISH_AUDIO_API_KEY`. Urdu voice availability varies by browser/device.
- For provider errors, check `/voice/status`, key permissions/quota, outbound network access, audio type and the 20 MB upload limit. Never paste API keys into the browser page or the issue tracker.
