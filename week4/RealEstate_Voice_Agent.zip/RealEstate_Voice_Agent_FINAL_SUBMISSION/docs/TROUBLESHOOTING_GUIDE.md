# Troubleshooting Guide

## Server won't start
- `ModuleNotFoundError` → run `pip install -r requirements.txt` inside the
  active virtual environment.
- Port already in use → change `--port` in the `uvicorn` command or stop
  the process using port 8000.

## `/chat` returns empty recommendations
Expected when no property matches the filters (e.g. budget below every
listing in that area/bedroom combination) — this is a genuine "no match",
not a bug. Verify against `app/data/properties.json` directly.

## Prompt-injection guardrail not triggering on new phrasing
Add the new phrase (lowercase substring) to `INJECTION_PATTERNS` in
`app/agent.py`, then re-run `python -m evaluation.run_eval` and
`pytest tests/` to confirm both the new case and existing cases pass.

## Booking/reschedule/cancel returns `ok: false`
Check the response `reason` field — it means a required field
(client_name/phone/property/date/time, or event_id) was missing. This is
intentional input validation, not a server error.

## Calendar/email "not really sending"
By design in demo mode: `calendar_book`/`send_email` in `app/services.py`
are safe local mock adapters until `GOOGLE_SERVICE_ACCOUNT_JSON` and Gmail
credentials are added — see `docs/ADMIN_GUIDE.md`.

## Evaluation suite fails
Run `pytest tests/ -q` and `python -m evaluation.run_eval` from the project
root (not from inside `app/` or `evaluation/`) so relative imports resolve.

## CI pipeline fails on GitHub Actions
Confirm `requirements.txt` installs cleanly on a clean `ubuntu-latest`
runner (no system-only packages) and that `tests/` and `evaluation/` are
committed to the repo, not gitignored.
