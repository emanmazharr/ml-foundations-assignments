# Future Enhancements (Day 7 Task 5)

| Enhancement | Value | Rough effort |
|---|---|---|
| WhatsApp integration | Caller can continue by text; send visit confirmations/reminders where they already read messages | Medium — WhatsApp Business API + reuse `app/agent` via a text channel |
| SMS confirmations | Lower-friction booking confirmation for callers without WhatsApp | Small — Twilio SMS, template from `email_service.employee_email` |
| CRM integration (Salesforce/HubSpot) | Sales team keeps using their existing CRM; our `customers`/`appointments` tables are already CRM-shaped for a straight export/sync | Medium — nightly sync job or real-time webhook from `crm.py` |
| Multilingual (Urdu script, Punjabi) | Wider caller reach beyond UrduLish | Medium — persona phrase banks + STT/TTS language packs already support this |
| Voice cloning for a brand voice | Consistent, recognisable brand identity across calls | Small with Fish Audio (~$0.1/voice, 10-30s sample) |
| Analytics dashboard | Ops visibility into conversion, objection frequency, drop-off points | Medium — the data already exists in `node_events`/`calls`/`appointments`; needs a front-end |
| Lead scoring | Prioritise human follow-up on high-intent callers | Small — `crm.bump_lead_score` already exists; needs a scoring model refinement pass |
| Automatic follow-up campaigns | Re-engage callers who didn't book | Small — `follow_ups` table already populated on every no-match/cancel/abandon; needs an outbound scheduler |
| Payment gateway integration | Token payment collection during/after the call | Large — compliance, PCI scope; keep out of the voice flow itself, use a secure follow-up link |
| Live MLS/property feed integration | Inventory always current without manual re-runs of `build_kb.py` | Medium — replace `scripts/build_kb.py`'s static data with a scheduled feed importer into the same SQL schema |
