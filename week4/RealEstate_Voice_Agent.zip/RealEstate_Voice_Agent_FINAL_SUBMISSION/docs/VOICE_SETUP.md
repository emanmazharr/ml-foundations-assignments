# Voice demo setup

The project has a turn-based browser voice demo at `http://127.0.0.1:8000/demo`. It uses the existing FastAPI call session and LangGraph flow. It accepts typed text, browser-recognized speech, or a short microphone recording transcribed by Deepgram. Responses can be spoken by an installed browser voice or generated as MP3 by Fish Audio.

## Run the no-key browser demo

1. Start the API as described in the README.
2. Open `/demo` in a current Chrome or Edge browser on `localhost`.
3. Select **Start a demo call**.
4. Use **Speak (browser mic)** if supported, or type a turn. A browser may use its configured speech service for recognition; check its settings and privacy policy.
5. The fallback uses `speechSynthesis` and voices exposed by the browser. Urdu/UrduLish availability and quality depend on the device. If no suitable voice is available, the agent text remains visible.

This is browser speech, not Fish Audio or a phone call. It is a practical local demo, but we do not claim an UrduLish voice benchmark.

## Optional provider-backed speech

Copy `.env.example` to `.env`. Keep keys on the server; never put them in HTML or commit `.env`.

```dotenv
STT_PROVIDER=deepgram
DEEPGRAM_API_KEY=your-key
DEEPGRAM_MODEL=nova-3
TTS_PROVIDER=fish
FISH_AUDIO_API_KEY=your-key
FISH_AUDIO_MODEL=s2.1-pro-free
# Optional existing Fish voice/model reference ID:
FISH_AUDIO_VOICE_ID=
```

Restart the API. `/voice/status` reports whether keys are configured without returning key values. The UI enables **Record & transcribe** when a Deepgram key is present. It records a short clip and submits it to `/voice/transcribe`; the `ur` option is for Urdu-dominant speech and `en` for English-dominant speech. Code-switching quality must be tested with local speakers. Agent replies are sent to Fish Audio when configured; otherwise the page uses browser speech synthesis.

Fish Audio's current developer documentation shows bearer-authenticated requests to `POST https://api.fish.audio/v1/tts`, MP3 format, an optional `reference_id`, and a model request header. Deepgram documents raw audio uploads to `POST https://api.deepgram.com/v1/listen` and lists Urdu (`ur`) support for Nova-3. These are provider APIs; configure keys and verify service access/quotas in your own accounts before a demo. [Fish Audio API example](https://fish.audio/developers/), [Fish Audio TTS API](https://fish.audio/text-to-speech-api/), [Deepgram language/model support](https://developers.deepgram.com/docs/models-languages-overview).

## API examples

Check provider state without exposing credentials:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/voice/status
```

Fish Audio test (response is an MP3 binary):

```powershell
Invoke-WebRequest http://127.0.0.1:8000/voice/speak -Method Post `
  -ContentType 'application/json' `
  -Body '{"text":"Assalam-o-Alaikum. Aap kis area mein ghar dekh rahe hain?"}' `
  -OutFile work\voice-test.mp3
```

The transcription API accepts a raw audio request to `/voice/transcribe?language=ur` with `audio/wav`, `audio/webm`, `audio/ogg`, `audio/mpeg`, `audio/mp4`, `audio/aac`, or `audio/flac`. The maximum upload is 20 MB.

## Scope and privacy

- This is request/response audio (record one utterance, then wait for a result), not continuous streaming or interruption-aware duplex speech.
- The optional turn-based Twilio webhook is implemented under `/twilio/voice` and `/twilio/turn`, but no number, public HTTPS deploy, or live credentials are configured. Follow `docs/TELEPHONY_SETUP.md`. Full-duplex streaming remains unimplemented.
- Browser recognition may send audio to a browser-selected service. Deepgram mode sends the recording to Deepgram. Fish Audio mode sends generated response text to Fish Audio. Do not send real customer calls or personal data without consent and company privacy approval.
- `demo_video.mp4` remains a captioned video artifact; the interactive voice demonstration is the local `/demo` page.
