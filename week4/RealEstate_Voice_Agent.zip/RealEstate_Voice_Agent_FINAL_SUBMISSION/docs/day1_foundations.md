# Day 1 — Foundations of AI Voice Agents & Conversation Design

## Task 1 — Voice agent architecture

```mermaid
flowchart LR
    Caller[Text or browser microphone] --> API[FastAPI]
    API --> Agent[LangGraph agent]
    Agent --> DB[(SQLite exact facts)]
    Agent --> Vec[(Chroma / NumPy semantic KB)]
    Agent --> Mock[Mock calendar and email services]
    Agent --> CRM[Local CRM trace]
    Agent --> Reply[Text response]
    Reply --> BrowserTTS[Browser speech fallback]
    Reply -.optional provider.-> Fish[Fish Audio MP3]
    Tel[Telephony] -.future adapter.-> API
    STT[Browser speech or Deepgram upload] --> API
    Tel[Twilio phone] -.future adapter.-> API
```

The browser voice path and Deepgram/Fish Audio provider adapters are included. An optional turn-based Twilio webhook is implemented and signature-tested; no Twilio number or live endpoint is configured. Provider services require credentials and were not live-tested.

| Layer | Component | Why this choice |
|---|---|---|
| Telephony | Optional signed Twilio inbound webhook with turn-based speech gather | Requires a public HTTPS app, Twilio number/token, Fish key and account-specific Gather language verification; no live call was tested |
| STT | Browser recognition fallback or optional Deepgram upload API | Browser/device support varies; Deepgram requires a key and an UrduLish test |
| Reasoning | LangGraph agent (`app/agent`) | Local conversation graph with deterministic policy paths |
| Retrieval | SQLite (exact facts) + Chroma/NumPy (semantic) | See `docs/rag_design.md` |
| Tool calling | Python functions in graph nodes and `app/services/` | Local mock modes are the safe demo default |
| Memory | In-process LangGraph state + SQL customer preferences | Session state is not shared between workers; SQL preferences persist in the demo DB |
| TTS | Browser speech fallback or optional Fish Audio REST API | Fish requires a key; test suite mocks it and no provider MP3 was generated |
| Orchestration | n8n workflow artifact supplied | Requires endpoint/credential review and was not run live |

**Why a graph, not a single LLM prompt loop?** Booking rules (no Sunday, 3-hour notice, no double-booking) are *hard requirements* that must hold 100% of the time — an LLM asked nicely to "never book Sundays" will eventually fail under an adversarial or just unusual conversation. The graph enforces these in code (`app/services/appointments.py::validate_slot`) so the LLM's job is limited to language, never policy.

## Task 2 — Conversation flows

```mermaid
flowchart TD
    Start([Call starts]) --> Greet[Greeting node]
    Greet --> Intent{Intent detection}
    Intent -->|buyer/rental/commercial/investment| Rec[Recommendation node]
    Rec -->|has focus property| RAG[RAG / property_question node]
    RAG --> Objection{Objection?}
    Objection -->|yes| Obj[Objection node: empathise+fact+close]
    Objection -->|no| Book{Wants visit?}
    Obj --> Book
    Book -->|yes| BookFlow[Booking: property -> date -> time -> name -> phone -> confirm]
    BookFlow --> ValidSlot{Slot valid?}
    ValidSlot -->|no| Alt[Offer 2-3 alternatives]
    Alt --> BookFlow
    ValidSlot -->|yes| Confirm[Read back + explicit yes]
    Confirm --> DoBook[Book: Calendar+CRM+Email]
    DoBook --> Goodbye([Goodbye])
    Book -->|no| Goodbye

    Return([Returning customer]) --> Greet2[Greeting: recall prefs + upcoming visit]
    Greet2 --> Intent

    Resched([Reschedule request]) --> FindAppt[Find appointment by phone/date]
    FindAppt --> NewSlot[Collect new date/time]
    NewSlot --> ValidSlot

    Cancel([Cancel request]) --> FindAppt2[Find appointment]
    FindAppt2 --> ConfirmCancel[Confirm cancellation]
    ConfirmCancel --> DoCancel[Cancel: Calendar+CRM+Email]
    DoCancel --> Goodbye
```

Six flows (buyer, rental, commercial, investment, returning customer, reschedule, cancel) all reduce to the **same graph** (`app/agent/graph.py`) — they differ only in which `Profile`/`Entities` fields get filled and which node the intent router selects. This is deliberate: one tested graph, not six divergent scripts. See `eval/conversations.py` for a scripted example of each.

## Task 3 — UrduLish persona ("Zain")
Implemented in `app/persona.py`. Design principles and phrase banks (greeting, confirmations, hesitation, acknowledgement, objection handling) are documented inline there — see the module docstring and the `OBJECTIONS` dict for the empathise → verified-fact → soft-close pattern used on every objection.

Illustrative example (the code includes objection responses; no freshly generated evaluation report is included in this archive):
> **Caller:** "yeh mehnga hai"
> **Zain:** "Ji sir, main samajhta hoon, itni bari investment ke liye budget dekhna zaroori hai. Property 5 par 30% down payment ke baad 36 mahine ki qist hai... Agar aap chahen to main aap ke budget ke andar options bhi dikha sakta hoon..."

## Task 4 — Fish Audio vs ElevenLabs

See [`docs/FISH_AUDIO_EVALUATION.md`](FISH_AUDIO_EVALUATION.md) for the provider review checked 29 September 2026 against current official documentation. Both vendors offer streaming and multilingual speech features; Eleven v3 explicitly lists Urdu. Fish Audio advertises sub-second conversational performance and current published pricing. These are vendor statements, not project benchmarks. No matched UrduLish audio A/B test was run, so neither provider is declared the quality winner. Fish Audio remains the assignment's candidate pending a speaker-rated pilot.

## Task 5 — System prompt
See `prompts/system_prompt.md` (scope, goals, truthfulness guardrails, persuasion rules, booking policy, escalation rules, security and style). `app/agent/nodes.py::_system_prompt` reads this file when building the agent context.
