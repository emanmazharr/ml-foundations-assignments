# Day 1 — Foundations of AI Voice Agents & Conversation Design

## Task 1 — Voice agent architecture

```mermaid
flowchart LR
    Caller((Caller)) -->|PSTN/SIP| Tel[Telephony: Twilio/SIP]
    Tel -->|audio stream| STT[Speech-to-Text: Deepgram Nova-3]
    STT -->|text| Agent[LangGraph Agent - app/agent]
    Agent -->|SQL queries| DB[(PostgreSQL: properties, agents, appointments, CRM)]
    Agent -->|semantic search| Vec[(ChromaDB: brochures, FAQs, guides)]
    Agent -->|generate/polish| LLM[Gemini / GPT / Claude]
    Agent -->|book/reschedule/cancel| Cal[Google Calendar API]
    Agent -->|notify employee| Mail[Gmail/Resend API]
    Agent -->|text reply| TTS[Fish Audio TTS]
    TTS -->|audio stream| Tel
    Tel -->|audio| Caller
    Agent -.state per call.-> Checkpoint[(LangGraph MemorySaver, thread_id=call_id)]
    n8n[n8n workflow] -.orchestrates retries, Slack alerts, cron.-> Agent
```

| Layer | Component | Why this choice |
|---|---|---|
| Telephony | Twilio Voice / SIP trunk | Industry standard, streams audio in/out over WebSocket |
| STT | Deepgram Nova-3 (Whisper fallback) | Sub-300ms streaming latency, good Urdu/English code-switch accuracy |
| Reasoning | LangGraph agent (`app/agent`) | Deterministic state machine + LLM only where judgment is needed — see "why not pure-LLM" below |
| Retrieval | SQL (exact facts) + ChromaDB (semantic) | See `docs/rag_design.md` for the full justification |
| Tool calling | Python functions wrapped as graph nodes (`app/services/*`) | Type-safe, testable, no prompt-injectable tool schema exposed to the LLM |
| Memory | LangGraph `MemorySaver` (per-call) + SQL `customers.preferences` (cross-call) | Short-term = in-process; long-term = durable, survives restarts |
| TTS | Fish Audio | See Task 4 evaluation below |
| Orchestration | n8n (`n8n/realestate_voice_agent.json`) | Retries, ops notifications, cron jobs — kept OUT of the agent so business logic stays testable Python |

**Why a graph, not a single LLM prompt loop?** Booking rules (no Sunday, 3-hour notice, no double-booking) are *hard requirements* that must hold 100% of the time — an LLM asked nicely to "never book Sundays" will eventually fail under an adversarial or just unusual conversation. The graph enforces these in code (`app/services/appointments.py::validate_slot`) so the LLM's job is limited to language, never policy.

## Task 2 — Conversation flows

```mermaid
flowchart TD
    Start([Call starts]) --> Greet[Greeting node]
    Greet --> Intent{Intent detection}
    Intent -->|buyer/rental/commercial/investment| Rec[Recommendation node]
    Rec -->|has focus property| RAG[RAG / property_question node]
    RAG --> Objection{Objection?}
    Objection -->|yes| Obj[Objection node: empathise+fact+close]
    Objection -->|no| Book{Wants visit?}
    Obj --> Book
    Book -->|yes| BookFlow[Booking: property -> date -> time -> name -> phone -> confirm]
    BookFlow --> ValidSlot{Slot valid?}
    ValidSlot -->|no| Alt[Offer 2-3 alternatives]
    Alt --> BookFlow
    ValidSlot -->|yes| Confirm[Read back + explicit yes]
    Confirm --> DoBook[Book: Calendar+CRM+Email]
    DoBook --> Goodbye([Goodbye])
    Book -->|no| Goodbye

    Return([Returning customer]) --> Greet2[Greeting: recall prefs + upcoming visit]
    Greet2 --> Intent

    Resched([Reschedule request]) --> FindAppt[Find appointment by phone/date]
    FindAppt --> NewSlot[Collect new date/time]
    NewSlot --> ValidSlot

    Cancel([Cancel request]) --> FindAppt2[Find appointment]
    FindAppt2 --> ConfirmCancel[Confirm cancellation]
    ConfirmCancel --> DoCancel[Cancel: Calendar+CRM+Email]
    DoCancel --> Goodbye
```

Six flows (buyer, rental, commercial, investment, returning customer, reschedule, cancel) all reduce to the **same graph** (`app/agent/graph.py`) — they differ only in which `Profile`/`Entities` fields get filled and which node the intent router selects. This is deliberate: one tested graph, not six divergent scripts. See `eval/conversations.py` for a scripted example of each.

## Task 3 — UrduLish persona ("Zain")
Implemented in `app/persona.py`. Design principles and phrase banks (greeting, confirmations, hesitation, acknowledgement, objection handling) are documented inline there — see the module docstring and the `OBJECTIONS` dict for the empathise → verified-fact → soft-close pattern used on every objection.

Example (from `eval/results/conversation_eval.md`, a real run of this codebase):
> **Caller:** "yeh mehnga hai"
> **Zain:** "Ji sir, main samajhta hoon, itni bari investment ke liye budget dekhna zaroori hai. Property 5 par 30% down payment ke baad 36 mahine ki qist hai... Agar aap chahen to main aap ke budget ke andar options bhi dikha sakta hoon..."

## Task 4 — Fish Audio vs ElevenLabs

| Criterion | Fish Audio | ElevenLabs | Notes |
|---|---|---|---|
| Latency | Streaming, sub-150ms on newer models (S2) | ~500ms typical | Fish Audio materially faster for a live phone call where the < 2s end-to-end budget matters |
| Naturalness | Ranked #1 on TTS-Arena blind tests in several 2026 comparisons; WER/CER on par with ElevenLabs | Very strong, widely regarded as the naturalness benchmark | Close; both are usable, Fish Audio is competitive not clearly worse |
| Emotion control | Open-domain natural-language emotion tags, e.g. `(chuckling)`, `(in a hurry)` | Preset styles, more limited | Fish Audio's tag system is a better fit for "Ji bilkul", hesitation, warmth |
| Streaming | Native streaming API, built for real-time agents | Streaming supported, higher latency | |
| Voice cloning | ~$0.1/voice, 10-30s sample | Instant/Pro cloning, pricier | Useful for a branded company voice later |
| Pricing | ~$15/1M characters, no subscription; roughly 50-80% cheaper than ElevenLabs at API scale | $5-$1,320/month tiers, $99/mo Pro is the realistic production tier | Meaningful cost difference at call-center volume |
| Multilingual support | 10-30+ languages depending on model generation | 29+ languages | Both list Urdu-adjacent language support; live testing with actual Urdu audio is still required before launch |
| Urdu pronunciation / code-switching | Not independently benchmarked for Urdu specifically in public sources found — **must be verified with real audio samples before committing** | Same caveat | This is the one claim in this document that is NOT yet empirically verified for this project — flagged honestly rather than asserted |

**Conclusion:** Fish Audio is the recommended choice on latency, cost, and emotion control — the three factors that matter most for a live, human-like UrduLish phone agent — provided a short pilot confirms acceptable Urdu/UrduLish pronunciation quality with real sample text from `prompts/system_prompt.md` before full commitment. This matches the brief's own recommendation. Sources: TTS provider comparison articles retrieved 2026 (see chat citations); pricing and latency figures are third-party reported and should be re-verified against Fish Audio's current published pricing before a procurement decision.

## Task 5 — System prompt
See `prompts/system_prompt.md` (scope, goals, truthfulness guardrails, persuasion rules, booking policy, escalation rules, security, style — all in one production-grade prompt used verbatim by `app/agent/nodes.py::_system_prompt`).
