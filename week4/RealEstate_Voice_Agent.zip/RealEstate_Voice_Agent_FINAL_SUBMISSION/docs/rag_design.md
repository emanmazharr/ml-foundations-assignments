# Day 2 — Knowledge Base, RAG & Property Intelligence (Design & Results)

## 1. Knowledge-base design (Task 1)
| Dataset | Where it lives | Rows | Retrieval path |
|---|---|---|---|
| Properties (size, type, purpose, status) | SQL `properties` | 42 | Structured |
| Prices / rents | SQL `properties.price_pkr` | 42 | Structured |
| Locations (areas, cities) | SQL `areas` + `areas/*.md` guides | 12 | Structured + Semantic |
| Amenities | SQL JSON column + brochure text | 42 | Structured filter + Semantic |
| Schools | SQL `schools` + area guides | 22 | Semantic (via guide) / SQL |
| Nearby hospitals | SQL `hospitals` + area guides | 17 | Semantic (via guide) / SQL |
| Payment plans | SQL `payment_plans` | 35 | Structured |
| Developers | SQL `developers` + profiles | 5 | Semantic |
| FAQs & policies | `faqs/faqs.json`, `policies/*.md` | 23 + 1 | Semantic |
| Agents (employees) | SQL `agents` | 6 | Structured |

CSV exports of all tables are in `data/datasets/`. **The data is a synthetic demo set** – replace it with the client's inventory
(`scripts/build_kb.py` is the only file to adapt). Brochures are generated from the same rows as the SQL tables so
the two stores cannot contradict each other.

## 2. RAG pipeline (Task 2)
`Loader → Header-aware chunker → Embedder → Vector store → Retriever (+re-rank) → Grounded generator`

| Stage | Implementation | Production alternative (env switch) |
|---|---|---|
| Loader | `app/rag/loader.py` (Markdown + JSON, metadata: doc_type, property_id, city, area) | — |
| Chunking | `app/rag/chunker.py` — sentence → comma → word fallback; every chunk prefixed with `[document title]`; overlap carry-over | — |
| Embedding | `HashingEmbedder` (offline hashed uni+bi-gram TF-IDF, Roman-Urdu query expansion) | `EMBEDDING_PROVIDER=openai` (text-embedding-3-small, multilingual) |
| Vector store | ChromaDB persistent, cosine (NumPy fallback) | `VECTOR_BACKEND=…` (Pinecone/Weaviate adapters follow the same 3-method interface) |
| Retriever | top-k over-fetch ×4, then re-rank: explicit property id (+0.5), area/city match, doc-type priors (school→area guides, developer→profiles, policy→FAQs) | — |
| Generator | grounded prompt; `NOT_IN_KB` ⇒ abstain; offline extractive fallback (IDF-weighted, location-agnostic, heading-aware) | `LLM_PROVIDER=openai|anthropic` |

**Why prefix every chunk with its title?** A chunk that only says “Amenities: gym, pool” is unusable without knowing *which property*.
**Why an offline embedder?** The whole system (tests, CI, demo) must run with zero API keys and zero cost; it is a swappable component.

### Chunk-size experiment (`python eval/chunk_eval.py`)
Held-out set = 15 questions never used while tuning; “main” = the 10 RAG questions of the evaluation set.

| Chunk size | Chunks | Mean length | Held-out Hit@1 | Hit@4 | MRR | Main Hit@1 |
|---|---|---|---|---|---|---|
| 200 | 323 | 161 | 0.933 | 1.0 | 0.967 | 1.0 |
| **350** | **162** | **263** | **0.933** | **1.0** | **0.967** | **1.0** |
| 600 | 111 | 362 | 0.867 | 1.0 | 0.933 | 1.0 |
| 900 | 83 | 455 | 0.933 | 1.0 | 0.967 | 1.0 |
| 1400 | 83 | 455 | 0.933 | 1.0 | 0.967 | 1.0 |

**Reading the result honestly:** with 15 held-out questions one miss = 6.7 pp, so differences are within noise. 900 and 1400 are identical because
every document is < 900 characters (one chunk each). **Decision: 350 chars / 50 overlap** — ties for best retrieval, keeps the LLM context short (latency budget < 2 s),
and returns sentence-level precision. Re-run the experiment when the client's real brochures (much longer) are loaded; expect larger differences.

## 3. Structured vs semantic retrieval (Task 3) — the justification
| | SQL (structured) | Vector (semantic) |
|---|---|---|
| Content | prices, availability, plot size, agent, payment plan, budget/city/bedroom filters | brochures, descriptions, area guides, developer profiles, FAQs |
| Needs exactness? | **Yes** – “PKR 3.4 crore” must not be “approximately 3.4” | No – paraphrase is fine |
| Changes often? | **Daily** (sold/reserved, price revisions) | Rarely |
| Query type | Filter / sort / join (`price ≤ 3 crore AND bedrooms ≥ 4`) | “What is it like? Is there a gym?” |
| Failure if wrong store | Stale or approximate price → **legal/commercial risk** | SQL can’t search free text |

Design rule enforced in code: **volatile facts are never written into brochures** (price, status, instalments). They are fetched live from SQL,
so a property that just sold cannot be recommended from a stale vector index. `app/engine.py::route()` picks the path per question
(`sql`, `sql_search`, `rag`); SQL answers are template-built from rows, so they cannot be hallucinated.

## 4. Recommendation engine (Task 4)
`app/recommender.py` — **hard constraints** (availability, purpose, city, budget ceiling, type, bedrooms) then an explainable 0-100 **score**
(budget fit, area match, bedrooms, amenities, investment yield, “cheaper than previous”). If nothing matches, constraints are relaxed in a fixed,
*disclosed* order (same city other areas → budget +15% → fewer bedrooms) and the agent is told what was relaxed.
Two behaviours found & fixed during testing: (1) “us se sasti” must stay in the caller’s city (`Profile.remember_choice`);
(2) ambiguous areas (“DHA” exists in 3 cities) return `needs_clarification="city"` instead of guessing.

## 5. Hallucination evaluation (Task 5) — `python eval/rag_eval.py`
20 questions: 10 semantic, 7 structured, 3 unanswerable (helipad, CEO salary, non-existent property).

| Metric | Result |
|---|---|
| Retrieval accuracy | 1.00 |
| Answer accuracy | 1.00 |
| Grounding rate | 1.00 |
| Hallucination rate | 0.00 |
| Correct abstention | 1.00 (3/3) |

**Caveat (read before presenting):** these 20 questions were also used while debugging the pipeline, so 1.00 is an *upper bound*, not a generalisation estimate.
The held-out chunk experiment above (Hit@1 ≈ 0.93) is the more honest number for retrieval. Before go-live, extend `eval/questions.py` with 50+ questions
written by someone who has not seen the code, and re-run with the production LLM/embedder (`LLM_PROVIDER=openai`), where grounding must be measured with an LLM judge.

Metric definitions — *Grounded*: every number in the answer appears in retrieved context and each sentence has ≥ 75% content-token support.
*Hallucinated*: answered when the KB has no answer, OR unsupported claim/number, OR confident but wrong.
