# Fish Audio vs ElevenLabs — provider review

**Research checked 29 September 2026. No live provider request or UrduLish audio comparison was run for this project.** Vendor feature and latency statements below are vendor-published claims, not independently verified results. Selection should follow a blinded UrduLish listening test using the same script, voice style, network and audio settings.

| Factor | Fish Audio | ElevenLabs |
|---|---|---|
| TTS API/streaming | Official developer page shows REST TTS, WebSocket streaming, and Python/TypeScript SDKs. | Official API docs list HTTP streaming and realtime-oriented models. |
| Urdu evidence | Fish advertises multilingual TTS, but the material reviewed did not give a clear Urdu-specific quality guarantee. Treat Urdu and Urdu-English code switching as unverified. | Eleven v3's official supported-language page explicitly lists Urdu. Language support does not guarantee Pakistani accent or Roman Urdu/English code-switch quality. |
| Latency | Vendor advertises sub-second conversational operation; actual end-to-end latency depends on network, model, turn size and telephony. | Vendor-published model descriptions include low-latency models; published figures are not comparable to a complete telephony round trip. |
| Pricing | The developer page currently displays S2.1 Pro as free for developers and $15 per 1M UTF-8 bytes for paid API use. Confirm account-specific terms before budgeting. | Pricing varies by plan and model; use the current pricing page for a like-for-like estimate. |
| Voice and prosody | Vendor describes voice cloning and inline direction tags. | Vendor documents voice options and model-specific expressive controls. |

## Recommendation for this capstone

Keep Fish Audio as the **candidate** requested by the assignment, with ElevenLabs as the comparison candidate. Do not claim Fish Audio is better for UrduLish until native Urdu speakers rate a matched set of greetings, property names, currency/date phrases, objections and code-switched sentences. Score pronunciation, intelligibility, naturalness, turn latency, consistency and cost. Record model/voice IDs and date with the results.

## Implementation status

The code includes a Fish Audio MP3 adapter at `POST /voice/speak`, exposed in the browser demo when configured. The optional Twilio request/response call flow also uses Fish Audio for `<Play>` audio. Tests mock the provider: no real Fish Audio request, saved provider-generated sound file, or UrduLish A/B listening test was available in this environment. Fish Audio is an implemented adapter, not a benchmarked winner or a credential-verified integration.

## Official references

- [Fish Audio developer page](https://fish.audio/developers/) — API shape, SDKs, streaming and vendor-published pricing/capability statements.
- [Fish Audio documentation](https://docs.fish.audio/) — API details; check current model-specific terms.
- [ElevenLabs language support](https://elevenlabs.io/docs/help-center/other/what-languages-do-you-support) — model-by-model language list including Urdu for Eleven v3.
- [ElevenLabs models](https://elevenlabs.io/docs/overview/models) — model capabilities and current documentation.
- [ElevenLabs API pricing](https://elevenlabs.io/pricing/api) — current account/model pricing.
