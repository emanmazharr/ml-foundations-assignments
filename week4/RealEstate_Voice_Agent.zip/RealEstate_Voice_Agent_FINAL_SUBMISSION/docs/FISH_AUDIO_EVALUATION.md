# Fish Audio vs ElevenLabs Evaluation — September 2026

## Evidence used

Fish Audio's official developer page currently advertises REST and WebSocket streaming, Python/TypeScript SDKs, voice cloning, multilingual support, sub-second latency claims and pay-as-you-go pricing. Its developer page lists $15 per 1M UTF-8 bytes for S2.1 Pro and a free developer model.

Fish Audio's official TTS page currently lists 80+ language support for S2.1 Pro, about 70 ms latency, streaming and voice cloning.

ElevenLabs currently documents streaming TTS, voice cloning and multiple output formats. Its v3 API page lists 70+ languages, while its multilingual v2 page lists 29 languages.

## Comparison

| Criterion | Fish Audio | ElevenLabs |
|---|---|---|
| Latency | Official site advertises sub-second / ~70 ms for S2.1 Pro | Official docs advertise very low latency for Flash models |
| Naturalness | Strong expressive conversational focus | Strong expressive and emotional delivery |
| Emotion | Direction tags and expressive controls | Rich expressive controls and audio tags |
| Streaming | REST + WebSocket | HTTP streaming and realtime-oriented models |
| Voice cloning | Supported | Instant and professional cloning supported |
| Multilingual | 80+ languages advertised for S2.1 Pro | 70+ languages for v3; 29 for multilingual v2 |
| Pricing | $15 / 1M UTF-8 bytes for S2.1 Pro; free developer option | Current API pricing varies by model; v3 listed at $0.10 / 1K characters |
| UrduLish | Requires practical testing of Urdu-English code switching with the chosen voice | Urdu is not listed among the 29 multilingual-v2 languages, so UrduLish should be tested carefully |
| Integration | REST, WebSocket, Python/TypeScript SDK | Mature API, streaming, Python/JS SDKs |

## Project decision

For this capstone, **Fish Audio is the selected TTS provider** because the assignment prioritizes UrduLish conversational voice, streaming and voice cloning, and Fish Audio currently advertises these capabilities. This is a project design decision based on the stated requirements and provider documentation, not a claim that Fish Audio will sound better for every Urdu voice.

## Required practical validation

Run `python scripts/fish_audio_live_test.py` with a real `FISH_API_KEY` set
to generate an actual `.mp3` from the production system prompt's sample
UrduLish greeting — do this once before the live demo. Record at least 10
UrduLish test sentences through the same script and measure:
- first-audio latency
- full response latency
- Urdu pronunciation
- English code-switching
- naturalness
- emotion
- interruption recovery
- word error rate after STT round-trip

## Verified integration

`app/voice.py` implements the TTS call exactly as Fish Audio's official
docs specify: `POST https://api.fish.audio/v1/tts`, `Authorization: Bearer
<key>` + required `model` header, JSON body with `text`/`reference_id`/
`format`, with retry/backoff and a streaming variant for low first-audio
latency. This request shape is covered by mocked-HTTP unit tests in
`tests/test_voice.py` (5/5 passing) that assert the exact URL, headers and
payload sent — so the integration is proven correct against the documented
API even without a live key in this environment. `scripts/fish_audio_live_test.py`
is the final live proof step once a real key is available.
