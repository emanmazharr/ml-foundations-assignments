"""Rule-based entity extraction for UrduLish utterances.

Extracts budget, city, area, bedrooms, purpose, property type, and conversational
intents ("cheaper", "investment", "visit") from a single caller utterance.
Rule-based on purpose: deterministic, instant (0 ms latency), testable.
In the LangGraph agent (Step 2) the LLM performs deeper intent detection; these
parsers are the fast-path and a safety net that validates the LLM's output.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field, asdict

from app.nlp.urdulish import normalise

NUM_WORDS = {
    "ek": 1, "aik": 1, "do": 2, "teen": 3, "char": 4, "chaar": 4, "paanch": 5, "panch": 5,
    "chhe": 6, "che": 6, "chay": 6, "saat": 7, "aath": 8, "nau": 9, "das": 10, "gyarah": 11, "barah": 12,
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "dhai": 2.5, "derh": 1.5, "dedh": 1.5, "sadhe": None, "sarhe": None,
}
UNIT = {"crore": 1e7, "cr": 1e7, "karor": 1e7, "کروڑ": 1e7, "lakh": 1e5, "lac": 1e5, "lakhs": 1e5, "lacs": 1e5, "لاکھ": 1e5}
_UNIT_RE = "|".join(sorted(map(re.escape, UNIT), key=len, reverse=True))
_NUM_RE = r"\d+(?:\.\d+)?"
_WORD_RE = "|".join(k for k, v in NUM_WORDS.items() if v is not None)

CITIES = {"lahore": "Lahore", "lhr": "Lahore", "karachi": "Karachi", "khi": "Karachi",
          "islamabad": "Islamabad", "isb": "Islamabad", "pindi": "Islamabad", "rawalpindi": "Islamabad"}

# area keyword -> (area search string, implied city or None)
AREAS = [
    ("bahria town", "Bahria Town", None), ("bahria enclave", "Bahria Enclave", "Islamabad"),
    ("dha", "DHA", None), ("gulberg", "Gulberg", "Lahore"), ("johar town", "Johar Town", "Lahore"),
    ("clifton", "Clifton", "Karachi"), ("gulshan", "Gulshan", "Karachi"),
    ("f-11", "F-11", "Islamabad"), ("f11", "F-11", "Islamabad"), ("e-11", "E-11", "Islamabad"), ("e11", "E-11", "Islamabad"),
    ("bahria", "Bahria", None),
]
PTYPES = {
    "house": "house", "ghar": "house", "makan": "house", "kothi": "house", "villa": "house", "home": "house",
    "plot": "plot", "plots": "plot", "zameen": "plot", "flat": "apartment", "flats": "apartment",
    "apartment": "apartment", "apartments": "apartment", "shop": "shop", "dukaan": "shop", "dukan": "shop",
    "office": "office", "دکان": "shop", "گھر": "house", "فلیٹ": "apartment",
}
RENT_W = {"rent", "kiraya", "kiraye", "kirayay", "kirayedar", "rental", "کرایہ", "tenant"}
BUY_W = {"buy", "kharidna", "kharidni", "kharidein", "khareedna", "purchase", "sale", "lena", "kharid"}
INVEST_W = {"invest", "investment", "sarmaya", "sarmayakari", "roi", "munafa", "profit", "yield", "returns", "return"}
CHEAPER_W = {"sasta", "sasti", "saste", "cheaper", "cheap", "kam", "lower", "affordable"}
COSTLIER_W = {"mehnga", "mehngi", "mehnge", "costlier", "expensive", "zyada", "bara", "bara", "premium", "upgrade"}


@dataclass
class Entities:
    budget_max: float | None = None
    budget_min: float | None = None
    city: str | None = None
    area: str | None = None
    bedrooms: int | None = None
    purpose: str | None = None       # sale | rent
    ptype: str | None = None
    category: str | None = None      # commercial
    wants_cheaper: bool = False
    wants_costlier: bool = False
    investment: bool = False
    property_id: int | None = None
    flags: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v not in (None, False, [])}


def parse_amount(text: str) -> float | None:
    """'3 crore' / '3.5cr' / 'dhai crore' / 'sarhe teen crore' / '80 lakh' / '1.5 lac' -> PKR."""
    t = normalise(text)
    # sarhe/sadhe X  => X + 0.5
    m = re.search(rf"(?:sarhe|sadhe)\s+({_NUM_RE}|{_WORD_RE})\s*({_UNIT_RE})", t)
    if m:
        n = float(m.group(1)) if re.match(_NUM_RE, m.group(1)) else NUM_WORDS[m.group(1)]
        return (n + 0.5) * UNIT[m.group(2)]
    m = re.search(rf"({_NUM_RE}|{_WORD_RE})\s*({_UNIT_RE})\b", t)
    if m:
        n = float(m.group(1)) if re.match(_NUM_RE, m.group(1)) else NUM_WORDS[m.group(1)]
        return n * UNIT[m.group(2)]
    m = re.search(r"\b(\d{1,3}(?:,\d{3})+|\d{6,})\b", t)  # plain rupees
    if m:
        return float(m.group(1).replace(",", ""))
    return None


def parse_utterance(text: str) -> Entities:
    t = normalise(text)
    words = set(re.findall(r"[\w\u0600-\u06FF-]+", t))
    e = Entities()

    amt = parse_amount(t)
    if amt:
        if re.search(r"(se\s+(zyada|ziada|upar|oopar)|above|minimum|at least|kam az kam)", t):
            e.budget_min = amt
        else:
            e.budget_max = amt

    for k, v in CITIES.items():
        if re.search(rf"\b{k}\b", t):
            e.city = v; break
    for kw, area, city in AREAS:
        if re.search(rf"(?<![\w-]){re.escape(kw)}(?![\w-])", t):
            e.area = area
            if city and not e.city:
                e.city = city
            break

    m = re.search(rf"(\d+)\s*(?:-?\s*)?(?:bed|beds|bedroom|bedrooms|kamr\w*|kamron|br)\b", t)
    if not m:
        m = re.search(rf"\b({_WORD_RE})\s+(?:bed|bedroom|bedrooms|kamr\w*|kamron)", t)
        if m:
            e.bedrooms = int(NUM_WORDS[m.group(1)])
    else:
        e.bedrooms = int(m.group(1))

    for w in words:
        if w in PTYPES:
            e.ptype = PTYPES[w]; break
    if "commercial" in words or e.ptype in ("shop", "office"):
        e.category = "commercial"

    if words & RENT_W:
        e.purpose = "rent"
    elif words & BUY_W or e.ptype in ("plot",):
        e.purpose = "sale"

    e.investment = bool(words & INVEST_W)
    e.wants_cheaper = bool(words & CHEAPER_W) or "se sasta" in t
    e.wants_costlier = bool(words & COSTLIER_W) and not e.wants_cheaper
    m = re.search(r"(?:property|id|number)\s*#?\s*(\d{1,3})\b", t)
    if m:
        e.property_id = int(m.group(1))

    for name, pat in {
        "reschedule": r"reschedul|time badal|date badal|aage kar|change (?:the )?(?:time|date)|kisi aur din",
        "cancel": r"cancel|mansookh|nahi aa sak|visit khatam",
        "visit": r"\bvisit\b|dekhna|dikha|dekhne|book",
        "human": r"human|insaan|agent se baat|kisi se baat|manager",
    }.items():
        if re.search(pat, t):
            e.flags.append(name)
    return e
