"""UrduLish (Roman-Urdu + English) helpers.

Callers speak mixed language: "DHA mein 3 kamron wala ghar ka price kya hai?".
Our knowledge base is English, so we (a) normalise the text and (b) *expand*
Roman-Urdu / Urdu-script words with English equivalents before retrieval.
This is a cheap, deterministic, zero-latency bridge that also works offline.
With OpenAI embeddings (multilingual) the expansion is still harmless.
"""
from __future__ import annotations

import re
import unicodedata

# Roman-Urdu / Urdu-script  ->  English retrieval keywords
LEXICON: dict[str, str] = {
    "ghar": "house home", "makan": "house home", "kothi": "house villa", "ghr": "house",
    "flat": "apartment", "flats": "apartment", "apartments": "apartment",
    "kamra": "bedroom", "kamre": "bedroom", "kamray": "bedroom", "kamron": "bedroom", "kamro": "bedroom",
    "bedrooms": "bedroom", "beds": "bedroom", "bed": "bedroom",
    "ghusalkhana": "bathroom", "washroom": "bathroom", "washrooms": "bathroom",
    "dukaan": "shop", "dukan": "shop", "dukanein": "shop",
    "qeemat": "price cost", "keemat": "price cost", "kimat": "price cost", "rate": "price",
    "kiraya": "rent", "kiraye": "rent", "kirayay": "rent", "kirayedar": "rent tenant",
    "sasta": "cheap affordable", "sasti": "cheap affordable", "saste": "cheap affordable",
    "mehnga": "expensive", "mehngi": "expensive", "mehnge": "expensive",
    "sarmaya": "investment", "sarmayakari": "investment", "invest": "investment", "munafa": "profit return yield",
    "qist": "instalment payment plan", "qisten": "instalment payment plan", "qistein": "instalment payment plan",
    "installment": "instalment", "installments": "instalment", "instalments": "instalment",
    "aspatal": "hospital", "hospitals": "hospital", "doctor": "hospital", "clinic": "hospital",
    "schools": "school", "school": "school", "taleem": "school education",
    "masjid": "mosque", "bijli": "electricity", "parking": "parking",
    "lift": "elevator", "security": "security", "guard": "security",
    "builder": "developer", "developers": "developer", "company": "developer",
    "maintenance": "maintenance charges",
    "paisa": "price", "paise": "price", "bajet": "budget", "budget": "budget",
    "visit": "visit", "dekhna": "visit", "dikhana": "visit", "mulaqat": "visit meeting",
    "commission": "commission", "token": "token amount", "documents": "documents", "kagzat": "documents",
    "tax": "taxes fees", "loan": "loan bank financing", "bank": "bank financing",
    "overseas": "overseas Pakistanis", "wakalat": "power of attorney",
    # Urdu script
    "گھر": "house home", "مکان": "house home", "فلیٹ": "apartment", "کمرے": "bedroom",
    "دکان": "shop", "قیمت": "price cost", "کرایہ": "rent", "سستا": "cheap affordable",
    "اسکول": "school", "ہسپتال": "hospital", "سرمایہ": "investment", "قسط": "instalment payment plan",
}

_STOP = set("""hai hain ka ki ke ko se mein me main aur ya to toh kya kis kuch koi aap ap mujhe mujhy mera meri
mere hum hamein wala wali wale liye lye tak bhi hi ho hoga hogi kar karo kariye please sir madam ji jee
the a an is are of in on for and or to at with""".split())


def normalise(text: str) -> str:
    text = unicodedata.normalize("NFKC", text or "").lower()
    text = re.sub(r"(?<=\d),(?=\d{3}\b)", "", text)  # 50,000,000 -> 50000000
    text = re.sub(r"[^\w\s\u0600-\u06FF.%:/-]", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def tokens(text: str) -> list[str]:
    return [t for t in re.findall(r"[\w\u0600-\u06FF]+(?:[-.][\w]+)*", normalise(text))]


def expand_query(text: str) -> str:
    """Return original tokens + English expansions (order preserved, no stopwords)."""
    out: list[str] = []
    for t in tokens(text):
        if t in _STOP:
            continue
        out.append(t)
        if t in LEXICON:
            out.append(LEXICON[t])
    return " ".join(out)
