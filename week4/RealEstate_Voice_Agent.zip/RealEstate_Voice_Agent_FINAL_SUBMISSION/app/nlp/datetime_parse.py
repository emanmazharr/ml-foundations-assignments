"""Parse UrduLish date/time phrases into concrete datetimes.

  "kal shaam 5 baje"        -> tomorrow 17:00
  "Saturday ko dopahar 2"   -> next Saturday 14:00
  "parson subah 11:30"      -> day-after-tomorrow 11:30
  "25 september 4 pm"       -> 25 Sep 16:00
  "dhai baje"               -> 14:30 (2:30)     "sawa 4" -> 16:15    "paune 5" -> 16:45

Ambiguity rule (business hours are 10:00-19:00): with no am/pm marker,
1-7 => PM, 8-11 => AM, 12 => noon.  The agent always reads the time back
("shaam 5 baje") so the caller can correct a wrong guess.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta

from app.nlp.entities import NUM_WORDS
from app.nlp.urdulish import normalise

WEEKDAYS = {
    0: ["monday", "mon", "peer", "pir", "somwar", "sомwar"],
    1: ["tuesday", "tue", "tues", "mangal", "mangar"],
    2: ["wednesday", "wed", "budh", "budhwar"],
    3: ["thursday", "thu", "thurs", "jumerat", "jumeraat", "jumayrat", "veer"],
    4: ["friday", "fri", "juma", "jumma", "jumah"],
    5: ["saturday", "sat", "hafta", "sanichar", "haftay"],
    6: ["sunday", "sun", "itwar", "ittwar", "itwaar", "etwar"],
}
MONTHS = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}
_WORD_NUM = {k: v for k, v in NUM_WORDS.items() if v is not None and isinstance(v, int)}
_WORD_NUM.update({"gyarah": 11, "barah": 12, "aik": 1, "ek": 1})
_HOUR_WORDS = "|".join(sorted(_WORD_NUM, key=len, reverse=True))


@dataclass
class When:
    date: date | None = None
    time: time | None = None
    has_am_pm: bool = False

    def combine(self, tz) -> datetime | None:
        if self.date and self.time:
            return datetime.combine(self.date, self.time, tzinfo=tz)
        return None


def _hour_from(tok: str) -> int | None:
    if tok.isdigit():
        return int(tok)
    return _WORD_NUM.get(tok)


def _resolve_hour(h: int, marker: str | None) -> int:
    if h >= 13:
        return h % 24
    if marker == "am":
        return 0 if h == 12 else h
    if marker == "pm":
        return h if h == 12 else h + 12
    if h == 12:
        return 12
    return h + 12 if h <= 7 else h          # 1-7 => PM, 8-11 => AM


def _marker(t: str) -> str | None:
    if re.search(r"\b(subah|subha|morning|savere|sawere|am|a\.m)\b", t):
        return "am"
    if re.search(r"\b(dopahar|dopehar|dupehar|shaam|sham|sham ko|evening|afternoon|raat|pm|p\.m|noon)\b", t):
        return "pm"
    return None


def parse_time(t: str) -> tuple[time | None, bool]:
    marker = _marker(t)
    # fractions: dhai baje / derh baje / sawa X / sarhe X / paune X
    if re.search(r"\bdhai\s+(?:baje|bje|bajay)\b", t):
        return time(_resolve_hour(2, marker), 30), bool(marker)
    if re.search(r"\b(derh|dedh)\s+(?:baje|bje|bajay)\b", t):
        return time(_resolve_hour(1, marker), 30), bool(marker)
    m = re.search(rf"\b(sawa|sava|sarhe|sadhe|paune|poune)\s+(\d{{1,2}}|{_HOUR_WORDS})\b", t)
    if m:
        h = _hour_from(m.group(2))
        if h:
            kind = m.group(1)
            if kind in ("sawa", "sava"):
                return time(_resolve_hour(h, marker), 15), bool(marker)
            if kind in ("sarhe", "sadhe"):
                return time(_resolve_hour(h, marker), 30), bool(marker)
            return time(_resolve_hour(h - 1 if h > 1 else 12, marker), 45), bool(marker)
    # 24h / hh:mm  (5:30, 17:00, 5.30)
    m = re.search(r"\b(\d{1,2})[:.](\d{2})\s*(am|pm|a\.m|p\.m)?", t)
    if m and int(m.group(2)) < 60 and int(m.group(1)) < 24:
        mk = "am" if (m.group(3) or "").startswith("a") else "pm" if m.group(3) else marker
        return time(_resolve_hour(int(m.group(1)), mk), int(m.group(2))), bool(mk)
    # "5 pm", "5 baje", "5 bje", "at 5", "paanch baje"
    m = re.search(rf"\b(\d{{1,2}}|{_HOUR_WORDS})\s*(am|pm|a\.m|p\.m|baje|bje|bajay|o'?clock)\b", t)
    if m:
        h = _hour_from(m.group(1))
        if h is not None and 0 <= h <= 24:
            mk = "am" if m.group(2).startswith("a") else "pm" if m.group(2).startswith("p") else marker
            return time(_resolve_hour(h, mk) % 24, 0), bool(mk)
    # "shaam 5", "dopahar 2", "subah 11"
    m = re.search(rf"\b(subah|subha|dopahar|dopehar|shaam|sham|raat|morning|evening|afternoon)\s+(?:ko\s+)?(\d{{1,2}}|{_HOUR_WORDS})\b", t)
    if m:
        h = _hour_from(m.group(2))
        if h is not None and h <= 12:
            return time(_resolve_hour(h, _marker(m.group(1))), 0), True
    return None, False


def parse_date(t: str, now: datetime) -> date | None:
    today = now.date()
    if re.search(r"\b(aaj|today|abhi)\b", t):
        return today
    if re.search(r"\b(parson|parsun|day after tomorrow|after tomorrow)\b", t):
        return today + timedelta(days=2)
    if re.search(r"\b(kal|tomorrow|tmrw|tommorow)\b", t):
        return today + timedelta(days=1)
    m = re.search(r"\b(\d{1,2})(?:st|nd|rd|th)?\s*(?:of\s+)?(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b", t)
    if m:
        d, mo = int(m.group(1)), MONTHS[m.group(2)]
        for yr in (today.year, today.year + 1):
            try:
                cand = date(yr, mo, d)
            except ValueError:
                return None
            if cand >= today:
                return cand
    m = re.search(r"\b(\d{4})-(\d{2})-(\d{2})\b", t)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    m = re.search(r"\b(\d{1,2})[/-](\d{1,2})\b(?![:.]\d)", t)
    if m and int(m.group(2)) <= 12 and int(m.group(1)) <= 31:
        try:
            cand = date(today.year, int(m.group(2)), int(m.group(1)))
            return cand if cand >= today else date(today.year + 1, int(m.group(2)), int(m.group(1)))
        except ValueError:
            return None
    words = set(re.findall(r"[a-z]+", t))
    for wd, names in WEEKDAYS.items():
        if words & set(names):
            ahead = (wd - today.weekday()) % 7
            if ahead == 0:
                ahead = 7
            if re.search(r"\b(agle|next|agla)\b", t) and ahead < 7 and False:
                ahead += 7
            return today + timedelta(days=ahead)
    return None


def parse_when(text: str, now: datetime) -> When:
    t = normalise(text)
    d = parse_date(t, now)
    tm, ap = parse_time(t)
    return When(d, tm, ap)
