"""Slot extraction for booking conversations: name, phone, yes/no."""
from __future__ import annotations

import re

_NAME_STOP = set("""hai hain hoon hun ho se ka ki ke ko ne mein me main mera meri aur or the is are am my name naam
bol raha rahi raha hoon bolna baat kar karna chahta chahti chahiye sir madam ji jee yeh ye woh wo aap ap
kal aaj parson subah shaam dopahar baje visit property dekhna booking book""".split())

_NAME_PATTERNS = [
    r"(?:mera|meri)\s+naam\s+(?:hai\s+)?([A-Za-z][A-Za-z.' -]{1,40}?)(?:\s+hai|\s+hoon|\s+hun|[,.!?]|$)",
    r"\bnaam\s+([A-Za-z][A-Za-z.' -]{1,40}?)(?:\s+hai|\s+hoon|[,.!?]|$)",
    r"my\s+name\s+is\s+([A-Za-z][A-Za-z.' -]{1,40}?)(?:[,.!?]|\s+and\b|\s+i\b|$)",
    r"\b(?:this is|i am|i'm|main)\s+([A-Za-z][A-Za-z.' -]{1,30}?)\s+(?:bol|here|speaking|hoon|hun)\b",
    r"^\s*([A-Za-z][A-Za-z.' -]{1,30}?)\s+(?:bol raha|bol rahi|bol raha hoon|bol rahi hoon|speaking)\b",
]


def extract_name(text: str) -> str | None:
    for pat in _NAME_PATTERNS:
        m = re.search(pat, text.strip(), re.I)
        if m:
            words = [w for w in m.group(1).split() if w.lower().strip(".") not in _NAME_STOP]
            if 1 <= len(words) <= 3:
                return " ".join(w.capitalize() for w in words)
    return None


def normalise_phone(raw: str) -> str | None:
    """Pakistani numbers -> +92XXXXXXXXXX. Returns None when it does not look valid."""
    digits = re.sub(r"\D", "", raw)
    if digits.startswith("0092"):
        digits = digits[2:]
    if digits.startswith("92") and len(digits) == 12:
        return "+" + digits
    if digits.startswith("0") and len(digits) == 11:
        return "+92" + digits[1:]
    if len(digits) == 10 and digits.startswith("3"):
        return "+92" + digits
    return None


def extract_phone(text: str) -> str | None:
    m = re.search(r"(?:\+?\d[\d\s\-]{8,16}\d)", text)
    return normalise_phone(m.group(0)) if m else None


_YES = r"\b(ji|jee|haan|han|haa|yes|yeah|yep|bilkul|theek|thik|sahi|ok|okay|confirm|kar do|kar dein|kardo|done|zaroor|pakka)\b"
_NO = r"\b(nahi|nahin|nai|no|nope|na|mat|galat|wrong|change|badal)\b"


def is_affirmative(text: str) -> bool:
    t = text.lower()
    return bool(re.search(_YES, t)) and not re.search(r"\b(nahi|nahin|nai|no|nope|mat)\b", t)


def is_negative(text: str) -> bool:
    t = text.lower()
    return bool(re.search(_NO, t)) and not re.search(r"ji nahi.*(ji haan)", t)


_NAME_BAD_BARE = _NAME_STOP | {
    "haan", "han", "haa", "nahi", "nahin", "nai", "ji", "jee", "yes", "no", "ok", "okay",
    "hello", "hi", "salam", "assalam", "shukriya", "thanks", "theek", "thik", "sahi", "bilkul",
}


def looks_like_bare_name(text: str) -> str | None:
    """'Sara Khan' -> 'Sara Khan'. Used only when the agent just asked 'what's your name?' -
    never as a general-purpose extractor (too many false positives otherwise)."""
    words = re.findall(r"[A-Za-z.'-]+", text.strip())
    if not (1 <= len(words) <= 3) or len(words) != len(text.strip().split()):
        return None
    if any(w.lower().strip(".") in _NAME_BAD_BARE for w in words):
        return None
    return " ".join(w.capitalize() for w in words)
