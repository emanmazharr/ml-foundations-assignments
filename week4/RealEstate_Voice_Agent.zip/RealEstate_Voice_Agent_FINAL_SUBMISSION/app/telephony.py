"""Optional turn-based Twilio voice webhook.

This is a small single-process demo adapter, not a streaming media service. Twilio
signature verification follows the published HMAC-SHA1 form-webhook algorithm;
for production deployments, prefer Twilio's official request-validator SDK.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import logging
import secrets
import time
from threading import Lock
from urllib.parse import parse_qs
from xml.etree.ElementTree import Element, SubElement, tostring

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import Response

from app.agent.session import CallSession
from app.config import get_settings
from app.voice import synthesize_fish_audio

log = logging.getLogger("telephony")
router = APIRouter(prefix="/twilio", tags=["optional telephony"])
_CALLS: dict[str, CallSession] = {}
_MEDIA: dict[str, tuple[float, bytes]] = {}
_LOCK = Lock()
MEDIA_TTL_SECONDS = 600
MEDIA_MAX_ITEMS = 128
MEDIA_MAX_BYTES = 25 * 1024 * 1024


def _public_url(path: str) -> str:
    s = get_settings()
    base = s.twilio_public_base_url.rstrip("/")
    if not base.startswith("https://"):
        raise HTTPException(503, "TWILIO_PUBLIC_BASE_URL must be a public HTTPS URL.")
    return base + path


def _valid_signature(url: str, form: dict[str, list[str]], signature: str, token: str) -> bool:
    # Twilio signs the exact public URL and alphabetically ordered form fields.
    signed = url + "".join(key + "".join(sorted(values)) for key, values in sorted(form.items()))
    expected = base64.b64encode(hmac.new(token.encode(), signed.encode(), hashlib.sha1).digest()).decode()
    return hmac.compare_digest(expected, signature)


async def _read_signed_form(request: Request) -> dict[str, list[str]]:
    s = get_settings()
    if not s.twilio_auth_token:
        raise HTTPException(503, "Twilio webhook is disabled; set TWILIO_AUTH_TOKEN.")
    content_type = request.headers.get("content-type", "").split(";", 1)[0].lower()
    if content_type != "application/x-www-form-urlencoded":
        raise HTTPException(415, "Twilio webhook must use application/x-www-form-urlencoded.")
    url = _public_url(request.url.path)
    # Fixed webhook routes have no query string; fail closed rather than validate
    # a proxy-rewritten host or an ambiguous URL.
    if request.url.query:
        raise HTTPException(400, "Query parameters are not supported on Twilio webhook routes.")
    try:
        form = parse_qs((await request.body()).decode("utf-8"), keep_blank_values=True, strict_parsing=False)
    except UnicodeDecodeError as exc:
        raise HTTPException(400, "Invalid webhook form encoding.") from exc
    signature = request.headers.get("X-Twilio-Signature", "")
    if not signature or not _valid_signature(url, form, signature, s.twilio_auth_token):
        raise HTTPException(403, "Invalid Twilio webhook signature.")
    return form


def _first(form: dict[str, list[str]], key: str) -> str:
    values = form.get(key, [])
    return values[0].strip() if values else ""


def _add_media(audio: bytes) -> str:
    now = time.time()
    with _LOCK:
        expired = [key for key, (deadline, _) in _MEDIA.items() if deadline <= now]
        for key in expired:
            del _MEDIA[key]
        current = sum(len(data) for _, data in _MEDIA.values())
        if len(_MEDIA) >= MEDIA_MAX_ITEMS or current + len(audio) > MEDIA_MAX_BYTES:
            raise HTTPException(503, "Temporary audio cache is full; retry shortly.")
        token = secrets.token_urlsafe(32)
        _MEDIA[token] = (now + MEDIA_TTL_SECONDS, audio)
    return token


def _audio_url(audio: bytes) -> str:
    token = _add_media(audio)
    return _public_url(f"/twilio/media/{token}.mp3")


def _twiml(*, audio: bytes | None = None, gather: bool = False, hangup: bool = False, redirect: bool = False) -> Response:
    root = Element("Response")
    if audio:
        SubElement(root, "Play").text = _audio_url(audio)
    if gather:
        url = _public_url("/twilio/turn")
        SubElement(root, "Gather", {
            "input": "speech", "action": url, "method": "POST",
            "speechModel": get_settings().twilio_stt_model,
            "language": get_settings().twilio_stt_language,
            "speechTimeout": "auto", "actionOnEmptyResult": "true",
        })
    if redirect:
        SubElement(root, "Redirect", method="POST").text = _public_url("/twilio/turn")
    if hangup:
        SubElement(root, "Hangup")
    return Response(tostring(root, encoding="utf-8", xml_declaration=True), media_type="application/xml")


@router.post("/voice", include_in_schema=True)
async def inbound_voice(request: Request):
    """Twilio number's voice webhook; creates one ephemeral agent session."""
    form = await _read_signed_form(request)
    call_sid = _first(form, "CallSid")
    if not call_sid or len(call_sid) > 128:
        raise HTTPException(400, "Missing or invalid CallSid.")
    session = CallSession(caller_phone=_first(form, "From") or None)
    with _LOCK:
        _CALLS[call_sid] = session
    try:
        audio = await synthesize_fish_audio(session.greet())
        return _twiml(audio=audio, gather=True)
    except HTTPException as exc:
        log.info("Twilio greeting could not be generated: %s", exc.status_code)
        with _LOCK:
            _CALLS.pop(call_sid, None)
        return _twiml(redirect=False, hangup=True)


@router.post("/turn", include_in_schema=True)
async def inbound_turn(request: Request):
    """Process one Twilio speech transcript and return the next spoken turn."""
    form = await _read_signed_form(request)
    call_sid = _first(form, "CallSid")
    with _LOCK:
        session = _CALLS.get(call_sid)
    if not session:
        # Do not invent a session after a process restart; ask Twilio to end safely.
        return _twiml(hangup=True)
    transcript = _first(form, "SpeechResult")
    if transcript:
        reply = session.say(transcript[:500])
    else:
        reply = session.silence()
    try:
        audio = await synthesize_fish_audio(reply)
        ended = bool(session.ended)
        if ended:
            with _LOCK:
                _CALLS.pop(call_sid, None)
        return _twiml(audio=audio, gather=not ended, hangup=ended)
    except HTTPException as exc:
        log.info("Twilio reply could not be generated: %s", exc.status_code)
        with _LOCK:
            _CALLS.pop(call_sid, None)
        return _twiml(hangup=True)


@router.get("/media/{token}.mp3", include_in_schema=False)
def media(token: str):
    """Serve short-lived provider audio to Twilio's <Play> verb."""
    now = time.time()
    with _LOCK:
        entry = _MEDIA.get(token)
        if not entry or entry[0] <= now:
            _MEDIA.pop(token, None)
            raise HTTPException(404, "Audio is expired or unavailable.")
        audio = entry[1]
    return Response(audio, media_type="audio/mpeg", headers={"Cache-Control": "no-store"})
