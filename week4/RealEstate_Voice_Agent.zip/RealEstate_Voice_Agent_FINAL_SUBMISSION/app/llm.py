"""LLM gateway.  One function, four providers, never crashes a live call.

    generate(system, prompt, ...) -> str | None

Returns None when LLM_PROVIDER=mock OR when the provider errors / times out /
is rate-limited (Gemini free tier!).  Every caller therefore has a deterministic
fallback (templates / rules) and the agent keeps talking instead of failing.
"""
from __future__ import annotations

import logging
import time

from app.config import get_settings

log = logging.getLogger("llm")
_STATS = {"calls": 0, "errors": 0, "total_ms": 0.0}


def stats() -> dict:
    n = max(1, _STATS["calls"])
    return {**_STATS, "avg_ms": round(_STATS["total_ms"] / n, 1)}


def is_enabled() -> bool:
    s = get_settings()
    return (s.llm_provider == "gemini" and bool(s.gemini_api_key)) or \
           (s.llm_provider == "openai" and bool(s.openai_api_key)) or \
           (s.llm_provider == "anthropic" and bool(s.anthropic_api_key))


def _gemini(system: str, prompt: str, json_mode: bool, temperature: float, max_tokens: int) -> str:
    from google import genai
    from google.genai import types
    s = get_settings()
    client = genai.Client(api_key=s.gemini_api_key,
                          http_options=types.HttpOptions(timeout=max(10000, int(s.llm_timeout_s * 1000))))
    base = dict(system_instruction=system or None, temperature=temperature, max_output_tokens=max_tokens)
    if json_mode:
        base["response_mime_type"] = "application/json"
    try:  # thinking off => lowest latency (voice!). Not every model supports it -> retry without.
        cfg = types.GenerateContentConfig(**base, thinking_config=types.ThinkingConfig(thinking_budget=0))
        r = client.models.generate_content(model=s.gemini_model, contents=prompt, config=cfg)
    except Exception as e:
        if "thinking" not in str(e).lower():
            raise
        r = client.models.generate_content(model=s.gemini_model, contents=prompt,
                                           config=types.GenerateContentConfig(**base))
    return (r.text or "").strip()


def _openai(system, prompt, json_mode, temperature, max_tokens) -> str:
    from openai import OpenAI
    s = get_settings()
    kw = {"response_format": {"type": "json_object"}} if json_mode else {}
    r = OpenAI(api_key=s.openai_api_key, timeout=s.llm_timeout_s).chat.completions.create(
        model=s.openai_model, temperature=temperature, max_tokens=max_tokens,
        messages=[{"role": "system", "content": system}, {"role": "user", "content": prompt}], **kw)
    return r.choices[0].message.content.strip()


def _anthropic(system, prompt, json_mode, temperature, max_tokens) -> str:
    import anthropic
    s = get_settings()
    r = anthropic.Anthropic(api_key=s.anthropic_api_key, timeout=s.llm_timeout_s).messages.create(
        model=s.anthropic_model, max_tokens=max_tokens, temperature=temperature, system=system or "",
        messages=[{"role": "user", "content": prompt}])
    return r.content[0].text.strip()


def generate(system: str, prompt: str, *, json_mode: bool = False, temperature: float = 0.4,
             max_tokens: int = 300) -> str | None:
    if not is_enabled():
        return None
    provider = get_settings().llm_provider
    fn = {"gemini": _gemini, "openai": _openai, "anthropic": _anthropic}[provider]
    t = time.perf_counter()
    _STATS["calls"] += 1
    try:
        out = fn(system, prompt, json_mode, temperature, max_tokens)
        return out or None
    except Exception as e:  # rate limit, timeout, network, bad model name ...
        _STATS["errors"] += 1
        log.warning("LLM call failed (%s): %s", provider, str(e)[:200])
        return None
    finally:
        _STATS["total_ms"] += (time.perf_counter() - t) * 1000
