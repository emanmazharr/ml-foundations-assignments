"""Time helpers: timezone-aware 'now', ISO round-trips and natural spoken time/date (UrduLish)."""
from __future__ import annotations

from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from app.config import get_settings

_NOW_OVERRIDE: datetime | None = None   # tests / demos can freeze the clock


def tz() -> ZoneInfo:
    return ZoneInfo(get_settings().timezone)


def now() -> datetime:
    return _NOW_OVERRIDE or datetime.now(tz())


def freeze(dt: datetime | None) -> None:
    global _NOW_OVERRIDE
    _NOW_OVERRIDE = dt


def iso(dt: datetime) -> str:
    return dt.isoformat(timespec="minutes")


def from_iso(s: str) -> datetime:
    return datetime.fromisoformat(s)


def spoken_time(dt: datetime) -> str:
    h12 = dt.hour % 12 or 12
    part = "subah" if dt.hour < 12 else "dopahar" if dt.hour < 16 else "shaam" if dt.hour < 19 else "raat"
    clock = f"{h12}" if dt.minute == 0 else f"{h12}:{dt.minute:02d}"
    return f"{part} {clock} baje"


def spoken_date(dt: datetime, ref: datetime | None = None) -> str:
    ref = ref or now()
    delta = (dt.date() - ref.date()).days
    rel = {0: "aaj", 1: "kal", 2: "parson"}.get(delta)
    base = f"{dt.strftime('%A')} {dt.day} {dt.strftime('%B')}"
    return f"{rel} ({base})" if rel else base


def spoken_when(dt: datetime, ref: datetime | None = None) -> str:
    return f"{spoken_date(dt, ref)} {spoken_time(dt)}"
