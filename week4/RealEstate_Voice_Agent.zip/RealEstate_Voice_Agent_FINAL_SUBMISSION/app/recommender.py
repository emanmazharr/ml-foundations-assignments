"""Property recommendation engine.

Hard constraints (never violated):  availability, purpose, city, budget ceiling,
                                    property type, minimum bedrooms.
Soft scoring (0-100, explainable):  budget fit, area match, bedroom match,
                                    amenity overlap, investment yield.
If nothing matches, constraints are relaxed in a transparent order and the agent
is told WHAT was relaxed so it can be honest with the caller ("exact match nahi
mila, lekin ...") instead of guessing.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from app import db
from app.db import pkr_words
from app.nlp.entities import Entities


@dataclass
class Profile:
    """Caller preferences accumulated over the conversation (LangGraph state in Step 2)."""
    budget_max: float | None = None
    budget_min: float | None = None
    city: str | None = None
    area: str | None = None
    bedrooms: int | None = None
    purpose: str = "sale"
    ptype: str | None = None
    category: str | None = None
    amenities: list[str] = field(default_factory=list)
    investment: bool = False
    cheaper_than: float | None = None   # "us se sasti koi option?"
    ref_city: str | None = None         # city of the last property we recommended (conversation memory)
    exclude_ids: list[int] = field(default_factory=list)

    def remember_choice(self, prop: dict) -> None:
        """Call after presenting a property so follow-ups ('us se sasti', 'us se bara') resolve correctly."""
        self.cheaper_than, self.ref_city = prop["price_pkr"], prop["city"]

    @classmethod
    def from_entities(cls, e: Entities, base: "Profile | None" = None) -> "Profile":
        p = Profile(**vars(base)) if base else Profile()
        for f in ("budget_max", "budget_min", "city", "area", "bedrooms", "ptype", "category"):
            v = getattr(e, f)
            if v is not None:
                setattr(p, f, v)
        if e.purpose:
            p.purpose = e.purpose
        if e.investment:
            p.investment = True
        return p


def _score(p: dict, prof: Profile) -> tuple[float, list[str]]:
    score, why = 40.0, []
    price = p["price_pkr"]
    if prof.budget_max:
        ratio = price / prof.budget_max
        fit = 25 if 0.7 <= ratio <= 1.0 else 15 if ratio < 0.7 else 5
        score += fit
        why.append(f"{pkr_words(price)} - " + ("within your budget" if ratio <= 1 else "slightly above your budget"))
    if prof.area and prof.area.lower() in p["area"].lower():
        score += 20; why.append(f"located in {p['area']}")
    if prof.bedrooms and p["bedrooms"]:
        if p["bedrooms"] == prof.bedrooms:
            score += 12; why.append(f"exactly {p['bedrooms']} bedrooms")
        elif p["bedrooms"] > prof.bedrooms:
            score += 6; why.append(f"{p['bedrooms']} bedrooms (extra room)")
    if prof.amenities:
        have = {a.lower() for a in p["amenities"]}
        hit = [a for a in prof.amenities if a.lower() in have]
        score += 3 * len(hit)
        if hit:
            why.append("has " + ", ".join(hit))
    if prof.investment and p.get("rental_yield_pct"):
        score += min(15, p["rental_yield_pct"] * 2)
        why.append(f"indicative rental yield {p['rental_yield_pct']}%")
    if prof.cheaper_than and price < prof.cheaper_than:
        score += 10; why.append(f"cheaper than the previous option ({pkr_words(prof.cheaper_than)})")
    return round(min(score, 100.0), 1), why


def _query(prof: Profile, *, use_area=True, budget_slack=1.0, use_beds=True, use_ref_city=False) -> list[dict]:
    max_price = prof.budget_max * budget_slack if prof.budget_max else None
    if prof.cheaper_than:
        max_price = min(max_price, prof.cheaper_than - 1) if max_price else prof.cheaper_than - 1
    rows = db.search_properties(
        city=prof.city or (prof.ref_city if use_ref_city else None), area=prof.area if use_area else None, purpose=prof.purpose,
        ptype=prof.ptype, category=prof.category, min_price=prof.budget_min, max_price=max_price,
        min_bedrooms=prof.bedrooms if use_beds and prof.ptype not in ("plot", "shop", "office") else None,
        only_available=True)
    return [r for r in rows if r["id"] not in prof.exclude_ids]


def recommend(prof: Profile, limit: int = 3) -> dict:
    ladder = [
        ("exact", dict()),
        ("same city, other areas", dict(use_area=False, use_ref_city=True)),
        ("budget stretched by 15%", dict(use_area=False, budget_slack=1.15, use_ref_city=True)),
        ("fewer bedrooms required", dict(use_area=False, budget_slack=1.15, use_beds=False, use_ref_city=True)),
    ]
    for label, kw in ladder:
        rows = _query(prof, **kw)
        if rows:
            ranked = []
            for r in rows:
                sc, why = _score(r, prof)
                ranked.append({"property": r, "score": sc, "reasons": why})
            ranked.sort(key=lambda x: (-x["score"], x["property"]["price_pkr"]))
            cities = sorted({r["city"] for r in rows})
            # An area name such as "DHA" exists in several cities -> never guess, ask the caller.
            ambiguous = cities if (label == "exact" and prof.area and not prof.city and not prof.ref_city and len(cities) > 1) else None
            return {"matches": ranked[:limit], "relaxed": None if label == "exact" else label,
                    "total_found": len(rows), "needs_clarification": "city" if ambiguous else None,
                    "candidate_cities": ambiguous}
    return {"matches": [], "relaxed": None, "total_found": 0, "needs_clarification": None,
            "message": "No available property matches. Ask the caller to adjust budget/city/type."}
