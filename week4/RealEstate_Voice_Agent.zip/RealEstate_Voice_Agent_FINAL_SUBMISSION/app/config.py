"""Central configuration – every setting comes from environment variables / .env."""
from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / ".env", extra="ignore")

    app_env: str = "development"
    database_url: str = f"sqlite:///{ROOT / 'data' / 'realestate.db'}"

    llm_provider: str = "mock"  # mock | gemini | openai | anthropic
    gemini_api_key: str = ""
    gemini_model: str = "gemini-flash-latest"   # change to any model listed by scripts/check_gemini.py
    llm_timeout_s: float = 12.0
    llm_polish: bool = True   # rewrite the deterministic draft in natural UrduLish via the LLM (falls back to the draft if unavailable/unsafe)
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-5"

    embedding_provider: str = "hashing"  # hashing | openai
    vector_backend: str = "chroma"  # chroma | numpy
    chroma_dir: str = str(ROOT / "data" / "chroma")
    rag_chunk_size: int = 350
    rag_chunk_overlap: int = 50
    rag_top_k: int = 4

    kb_dir: str = str(ROOT / "data" / "kb")

    # ---- business rules ----
    company_name: str = "RealEstate Hub"
    timezone: str = "Asia/Karachi"
    slot_minutes: int = 30
    booking_notice_hours: int = 3          # matches the FAQ promise
    booking_horizon_days: int = 30

    # ---- integrations (mock = fully offline, real = flip in .env) ----
    calendar_mode: str = "mock"            # mock | google
    google_credentials_file: str = str(ROOT / "secrets" / "google_credentials.json")
    google_token_file: str = str(ROOT / "secrets" / "google_token.json")
    google_calendar_id: str = "primary"
    email_mode: str = "mock"               # mock | resend | smtp
    email_from: str = "RealEstate Hub <onboarding@resend.dev>"
    resend_api_key: str = ""
    smtp_host: str = "smtp.gmail.com"
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""                # Gmail *App Password*
    outbox_dir: str = str(ROOT / "data" / "outbox")
    demo_agent_email: str = ""             # if set, ALL employee emails/invites go to this address (safe live demos)
    google_check_freebusy: bool = True


@lru_cache
def get_settings() -> Settings:
    return Settings()
