"""Structured logging (Day 6 Task 4 / Day 7 monitoring).

JSON logs to stdout in production (Docker/Railway/Render all capture stdout and ship it
to their log viewers / can forward to Datadog, CloudWatch, etc. for free); human-readable
logs in development. Call `configure_logging()` once at process start (done in app/main.py).
"""
from __future__ import annotations

import json
import logging
import sys
import time

from app.config import get_settings


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False)


def configure_logging() -> None:
    is_prod = get_settings().app_env != "development"
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JsonFormatter() if is_prod else logging.Formatter(
        "%(asctime)s %(levelname)-7s %(name)-14s %(message)s", "%H:%M:%S"))
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(logging.INFO)
    # keep noisy third-party libs quiet
    for noisy in ("httpx", "httpcore", "chromadb", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
