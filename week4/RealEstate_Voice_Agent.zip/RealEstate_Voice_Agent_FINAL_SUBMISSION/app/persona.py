"""UrduLish persona: Zain, a warm, professional Pakistani sales executive (Day 1 Task 3).

Design rules
  * Spoken, not written: short sentences, natural code-switching (Urdu grammar + English business words).
  * Never a literal translation - idioms a real Pakistani agent would use ("ji bilkul", "koi masla nahi", "ek second").
  * Empathy first, facts second, soft close third. Never pressure, never promise discounts/returns.
  * Male agent voice ("main check karta hoon") to match the recommended Fish Audio voice.
Phrase banks are picked round-robin by turn number => varied but reproducible (great for tests).
"""
from __future__ import annotations

AGENT_NAME = "Zain"

GREETING = ("Assalam-o-Alaikum {hon}! {company} se baat ho rahi hai. Main {agent} bol raha hoon. "
            "Main aap ki kis tarah madad kar sakta hoon?")
GREETING_RETURNING = ("Assalam-o-Alaikum {name} {hon}! {company} mein dobara call karne ka bohat shukriya. {memory}"
                      "Aaj main aap ki kya madad kar sakta hoon?")

ACK = ["Ji bilkul.", "Acha, samajh gaya.", "Ji {hon}, theek hai.", "Hmm, ji.", "Bilkul {hon}.", "Ji zaroor."]
THINK = ["Ek second {hon}, main check karta hoon...", "Hmm, zara system mein dekhta hoon...",
         "Acha, ek minute {hon}, main confirm kar leta hoon...", "Ji, ek lamha, dekhta hoon..."]
EMPATHY = ["Main aap ki baat bilkul samajhta hoon.", "Ji, yeh sawal bilkul jaiz hai.",
           "Acha kiya aap ne poochh liya.", "Aap ki fikar bilkul theek hai."]
SORRY_UNCLEAR = ["Maaf kijiye {hon}, awaaz thori clear nahi aayi. Kya aap dobara bata sakte hain?",
                 "Sorry {hon}, main theek se sun nahi paya. Ek baar phir bata dein?"]
CLOSE = ["Aap ka bohat shukriya {hon}. Allah Hafiz!", "Shukriya {hon}, aap ka din acha guzre. Allah Hafiz!"]
HANDOFF = ("Ji bilkul {hon}. Main aap ka naam aur number note kar leta hoon, hamara senior agent office hours "
           "mein, yaani Monday se Saturday, subah 10 se shaam 7 baje ke darmiyan aap ko call karega.")
OFFTOPIC = ("Maaf kijiye {hon}, main sirf property ke baare mein madad kar sakta hoon. "
            "Kya aap kisi ghar, plot ya shop ke baare mein maloomat chahte hain?")
INJECTION = ("Maaf kijiye {hon}, main yeh nahi kar sakta. Main sirf property inquiry aur visit booking mein madad kar sakta hoon. "
             "Batayen, kis area mein property dekh rahe hain?")
EXFIL = ("Maaf kijiye {hon}, company ka internal data ya doosre customers ki maloomat main share nahi kar sakta. "
         "Property ki details aur visit booking mein zaroor madad karunga.")
FAKE = ("Maaf kijiye {hon}, main sirf asal visits book kar sakta hoon, jin mein aap khud property dekhne aayen. "
        "Agar aap ko visit chahiye to din aur time bata dein.")
ABUSE1 = "{hon}, main aap ki madad karna chahta hoon. Baraye meherbani respectful andaz mein baat karein, phir main foran help karta hoon."
ABUSE2 = "Maaf kijiye {hon}, is andaz mein baat jaari nahi rakh sakta. Main aap ka number note kar leta hoon, humara senior agent call karega. Allah Hafiz."
SILENCE1 = "Hello? {hon}, kya aap meri awaaz sun pa rahe hain?"
SILENCE2 = "{hon}, lagta hai line mein masla hai. Main aap ko thori der baad dobara call karta hoon. Allah Hafiz!"
ERROR_FALLBACK = ("Maaf kijiye {hon}, thora technical masla aa gaya. Main aap ka number note kar leta hoon, "
                  "hamara agent aap ko foran call karega.")


def pick(bank: list[str], turn: int) -> str:
    return bank[turn % len(bank)]


def fmt(template: str, state: dict | None = None, **kw) -> str:
    from app.config import get_settings
    hon = (state or {}).get("honorific", "sir")
    base = {"hon": hon, "company": get_settings().company_name, "agent": AGENT_NAME}
    base.update(kw)  # caller-supplied values (e.g. the assigned sales agent's name) win over the default persona name
    return template.format(**base)


# ------------------------------- objection handling (Day 3 Task 4) ------------------------------- #
# Each objection follows the same proven sales pattern:
#   1. EMPATHISE  2. REFRAME with a VERIFIED fact  3. offer a low-commitment NEXT STEP.
# The {fact} slot is always filled from SQL/KB - never invented.
OBJECTIONS = {
    "price": dict(
        pattern=r"mehng|expensive|too much|zyada (price|qeemat|paisa|rate)|budget se (bahar|zyada|upar)|price (zyada|high)|"
                r"kam (karo|kar do|hoga)|discount|rate kam|afford|costly|paise nahi",
        open="Ji {hon}, main samajhta hoon, itni bari investment ke liye budget dekhna zaroori hai.",
        close="Agar aap chahen to main aap ke budget ke andar options bhi dikha sakta hoon, ya visit par agent se baat karwa deta hoon. Kya kehte hain?"),
    "trust": dict(
        pattern=r"bharosa|trust|fraud|scam|dhoka|dhoke|fake|jaali|asli|genuine|legal(ly)?|verified|safe hai|kaise maan|guarantee",
        open="Aap ki fikar bilkul jaiz hai {hon}, property mein bharosa sab se pehle aana chahiye.",
        close="Isi liye visit bilkul free hai aur koi obligation nahi. Kya main kal ya parson ka slot dekh loon?"),
    "location": dict(
        pattern=r"door (hai|lagta)|bohat door|far (from|away)|location (theek|acha|pasand) nahi|traffic|area (acha|theek|safe) nahi|"
                r"asaan nahi|access|commute|office se door",
        open="Location ka sochna bilkul theek hai {hon}, roz ka aana jaana bohat matter karta hai.",
        close="Behtar yeh hoga ke aap khud ek baar area dekh lein. Kya main visit ka time dekh loon?"),
    "investment": dict(
        pattern=r"risk|loss|nuksan|nuqsan|market (down|gir|girti|mandi)|mandi|return kya|profit (hoga|milega|guarantee)|"
                r"paisa doob|resale|kya faida|worth it|sahi investment",
        open="Investment mein sochna samajhdari hai {hon}, koi bhi investment guaranteed nahi hoti.",
        close="Main aap ko company ke indicative numbers bata sakta hoon, aur agent visit par poori tafseel samjha dega. Kya visit rakh dein?"),
    "builder": dict(
        pattern=r"builder|developer (kaisa|kaisi|kon|kaun|ka record)|company kaisi|delay|possession (late|kab)|time par|"
                r"wada|promise|track record|pehle ke project",
        open="Yeh bohat zaroori sawal hai {hon}, developer ka record dekh kar hi faisla karna chahiye.",
        close="Agent aap ko developer ke delivered projects ke documents bhi dikha dega. Kya visit ka time dekhen?"),
    "maintenance": dict(
        pattern=r"maintenance|monthly (kharcha|charges)|bills|service charges|hidden (charges|cost)|extra kharcha|society charges",
        open="Ji {hon}, maintenance ka pehle se pata hona chahiye taake baad mein koi surprise na ho.",
        close="Exact monthly amount building ke hisaab se hota hai, agent visit se pehle likhit mein bata dega. Kya visit book kar dein?"),
}
