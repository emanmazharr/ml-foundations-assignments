"""Input guardrails - run BEFORE the LLM sees anything (defence-in-depth, layer 1).

Layer 1  this file        : deterministic pattern screen (injection, exfiltration, abuse, off-topic)
Layer 2  system prompt    : scope + refusal rules (prompts/system_prompt.md)
Layer 3  tool validation  : booking/availability rules enforced in code (services/appointments.py)
Layer 4  output check     : LLM rewrite may not change any number/name/time (agent/respond)

Even if layers 1-2 were bypassed, layer 3 guarantees no unavailable slot/property can be booked.
"""
from __future__ import annotations

import re
import unicodedata

_INJECTION = [
    r"ignore (all |any |the |your |previous |prior |above )*(instructions?|rules?|prompts?|guidelines?)",
    r"disregard (all |any |the |your |previous |prior )*(instructions?|rules?|prompts?)",
    r"forget (all |your |everything |previous )*(instructions?|rules?|prompt)",
    r"(reveal|show|print|repeat|tell me|display|leak|share|dikhao|batao|bataen).{0,25}(system|hidden|initial|original|your)?\s*(prompt|instructions?|rules|configuration)",
    r"(system|developer)\s*(prompt|message|mode)",
    r"\b(apna|apni|apnay|your|tumhara|tumhari|aap ka|aap ki|aap ke)\s+(system\s+)?(prompt|instructions?|hidayat\w*)\b",
    r"\b(prompt|instructions?)\s+(dikhao|dikha do|batao|bata do|bataen|share|do|de do|print|leak)\b",
    r"\b(jailbreak|dan mode|developer mode|god mode|sudo|override)\b",
    r"you are (now|no longer)\b",
    r"(from now on|ab se (tum|aap)|is waqt se).{0,40}(you are|you will|tum ho|aap ho|act|behave|role)",
    r"\b(dan|stan|dude)\s+(mode|prompt)\b|you are dan\b",
    r"\bpretend (to be|you are|that you)\b",
    r"\bact as (a |an |if )?(?!a real estate|an agent)",
    r"new (instructions?|rules?|role)\s*:",
    r"(sab|saari|pichli|purani|apni)\s+(instructions?|hidayat\w*|rules?)\s+(bhool|ignore|nazar andaz|bhul)",
    r"instructions?\s+(bhool|ignore|nazar andaz|bhul)",
    r"(bhool jao|ignore kar do).{0,30}(instructions?|rules?)",
    r"</?(system|assistant|user|instructions?)>",
    r"\[(system|inst)\]",
    r"ignore (the |all )?(above|previous)\b",
    r"new instructions?\s+(follow|below)|you must comply",
    r"(bhool jao|bhul jao).{0,30}(mera|meri|har|sab)\s*(sawal|baat|hukm)\s*(maano|maan|suno)",
    r"\b(exact|word[- ]for[- ]word)\s+instructions?\b",
    r"print (the )?text (above|before)",
    r"\b(tools?|functions?|apis?)\b.{0,25}(do you have|are you using|have access|access to)",
    r"respond only as\b.{0,25}(no filters?|unrestricted|freebot)",
]
_EXFIL = [
    r"(internal|confidential|private|secret)\s+(company\s+)?(data|information|documents?|files?|records?)",
    r"(company|andruni|internal)\s+(ka\s+)?(data|database|records?)",
    r"\b(database|db)\s+(dump|password|credentials|schema|access)",
    r"(other|dusre|doosre|baqi)\s+(customers?|clients?|logon?)\s*(ka|ki|ke|ka data|data|details?|number|phone)",
    r"(customer|client)\s+(list|database|data|numbers?|details)\b",
    r"\b(api[ _-]?key|password|token|credentials|secret key|env file)\b",
    r"(agents?|employees?|staff)\s+(ki|ka|ke)?\s*(salary|tankhwah|personal|home address|ghar ka)",
    r"(phone number|number|contact)\s+of\s+(your\s+)?(other\s+)?customers?",
    r"(home address(es)?|salary|salaries)\s+of\s+(the\s+)?(agents?|employees?|staff)",
    r"(agents?|employees?|staff)\W{0,3}\s*(home address(es)?|salary|salaries)",
    r"\b(commission|margin|profit)\s+(structure|breakdown|internal)\b",
]
_FAKE_BOOKING = [
    r"(fake|jhoot?ay?|false|dummy|spam|test)\s+(appointments?|bookings?|visits?)",
    r"book\s+(all|every|sab|saare|50|100|multiple|hundred)\s+(the\s+)?(slots?|appointments?|times?)",
    r"(sab|saare|tamam)\s+slots?\s+book",
    r"block\s+(all\s+)?(the\s+)?(slots?|calendar)",
    r"book\s+(all\s+)?(the\s+)?available\s+slots?",
    r"block\s+the\s+(whole\s+)?calendar",
]
_AUTHORITY = [
    r"\bi am (the |your )?(admin|administrator|ceo|owner|developer|manager|engineer|anthropic|openai|google)\b",
    r"main\s+(admin|manager|ceo|owner|developer)\s+(hoon|hun)\b",
    r"(admin|manager|ceo|owner)\s+ka\s+(order|hukm|command)",
    r"maintenance mode|debug mode|test mode",
    r"\b(system|network)\s+administrator\b",
    r"\bceo of\b.{0,30}\b(order|instruct|command)",
    r"(this is a )?test from (anthropic|openai|google|the developers?)\b",
]
_ABUSE = [
    r"\b(fuck|shit|bitch|bastard|asshole|idiot|stupid|moron|useless|dumb)\b",
    r"\b(bewakoof|bewaqoof|ullu|kutta|kutte|harami|haramzada|badtameez|pagal|gadha|nikamma|chutiya|bakwas)\b",
]
_OFFTOPIC = [
    r"\b(cricket|match score|psl|world cup|football|ipl)\b",
    r"\b(weather|mausam|temperature)\b",
    r"\b(politics|election|imran khan|nawaz|prime minister|government policy|siasat)\b",
    r"\b(joke|latifa|poem|nazm|shayari|song|gaana|story|kahani)\b",
    r"\b(recipe|biryani|cooking|khana banana)\b",
    r"\b(bitcoin|crypto|stock market|forex|psx)\b",
    r"\b(write|likh).{0,15}(code|python|essay|program|script)\b",
    r"\b(translate|tarjuma)\b",
    r"\b(homework|assignment|exam|math problem)\b",
    r"\b(medical advice|diagnos|dawai|bimari|legal advice|court case|mukadma)\b",
]

_CATS = [("injection", _INJECTION), ("exfiltration", _EXFIL), ("fake_booking", _FAKE_BOOKING),
         ("authority_claim", _AUTHORITY), ("abuse", _ABUSE), ("offtopic", _OFFTOPIC)]
MAX_LEN = 600


def _clean(text: str) -> str:
    t = unicodedata.normalize("NFKC", text or "")
    t = re.sub(r"[\u200b-\u200f\u202a-\u202e\u2060\ufeff]", "", t)     # zero-width / bidi tricks
    return re.sub(r"\s+", " ", t).strip().lower()


def screen(text: str) -> dict:
    """-> {"category": None|str, "matched": str|None, "text": cleaned_input}"""
    t = _clean(text)
    if len(t) > MAX_LEN:
        return {"category": "injection", "matched": "input too long", "text": t[:MAX_LEN]}
    for cat, pats in _CATS:
        for p in pats:
            m = re.search(p, t)
            if m:
                return {"category": cat, "matched": m.group(0)[:60], "text": t}
    return {"category": None, "matched": None, "text": t}
