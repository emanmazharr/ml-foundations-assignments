"""Optional, turn-based audio adapters for browser, Deepgram STT, and Fish Audio TTS.

The default app remains offline. Deepgram receives caller audio only when its key is
configured and the uploaded clip is explicitly submitted to this endpoint. Fish Audio
receives response text only when Fish TTS is configured and requested by the UI.
"""
from __future__ import annotations

import logging
from pathlib import Path

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field

from app.config import get_settings
from app.security import require_demo_access

log = logging.getLogger("voice")
router = APIRouter(tags=["voice demo"])
MAX_AUDIO_BYTES = 20 * 1024 * 1024
ALLOWED_AUDIO_TYPES = {
    "audio/wav", "audio/x-wav", "audio/webm", "audio/ogg", "audio/mpeg",
    "audio/mp4", "audio/aac", "audio/flac", "application/octet-stream",
}


class SpeakRequest(BaseModel):
    text: str = Field(min_length=1, max_length=2000)


async def synthesize_fish_audio(text: str) -> bytes:
    """Return provider-generated MP3 bytes; raise a safe HTTPException on failure."""
    s = get_settings()
    if s.tts_provider != "fish" or not s.fish_audio_api_key:
        raise HTTPException(503, "Fish Audio TTS is not enabled. Set TTS_PROVIDER=fish and add FISH_AUDIO_API_KEY.")
    body: dict[str, str] = {"text": text, "format": "mp3"}
    if s.fish_audio_voice_id:
        body["reference_id"] = s.fish_audio_voice_id
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(45.0, connect=8.0)) as client:
            upstream = await client.post(
                "https://api.fish.audio/v1/tts",
                headers={"Authorization": f"Bearer {s.fish_audio_api_key}", "Content-Type": "application/json", "model": s.fish_audio_model},
                json=body,
            )
            upstream.raise_for_status()
        if not upstream.content:
            raise HTTPException(502, "Fish Audio returned an empty audio response.")
        return upstream.content
    except HTTPException:
        raise
    except httpx.HTTPStatusError as exc:
        log.warning("Fish Audio synthesis failed with status %s", exc.response.status_code)
        raise HTTPException(502, "Speech synthesis provider returned an error; check the key, voice ID, model, and quota.") from exc
    except httpx.HTTPError as exc:
        log.warning("Fish Audio synthesis request failed: %s", type(exc).__name__)
        raise HTTPException(502, "Could not reach the speech synthesis provider. Try again in a moment.") from exc


@router.get("/demo", response_class=FileResponse, include_in_schema=False)
def voice_demo_page():
    page = Path(__file__).parent / "static" / "voice_demo.html"
    return FileResponse(page, media_type="text/html; charset=utf-8")


@router.get("/voice/status")
def voice_status():
    """Report provider readiness without disclosing credentials."""
    s = get_settings()
    fish_ready = bool(s.fish_audio_api_key)
    deepgram_ready = bool(s.deepgram_api_key)
    return {
        "stt_provider": s.stt_provider,
        "stt_ready": deepgram_ready if s.stt_provider == "deepgram" else True,
        "deepgram_configured": deepgram_ready and s.stt_provider == "deepgram",
        "tts_provider": s.tts_provider,
        "tts_ready": fish_ready if s.tts_provider == "fish" else True,
        "fish_audio_configured": fish_ready and s.tts_provider == "fish",
        "browser_demo": True,
        "note": "Browser voice is available; provider audio and Twilio phone calls require credentials and public HTTPS setup.",
    }


@router.post("/voice/transcribe", dependencies=[Depends(require_demo_access)])
async def transcribe_audio(request: Request, language: str = "ur"):
    """Transcribe one browser-recorded clip through Deepgram Nova-3.

    Raw audio bytes are sent to Deepgram; use only with consent and an API key.
    For UrduLish, use `ur` for Urdu-dominant turns or `en` for English-dominant turns.
    """
    s = get_settings()
    if s.stt_provider != "deepgram" or not s.deepgram_api_key:
        raise HTTPException(503, "Deepgram STT is not enabled. Set STT_PROVIDER=deepgram and add DEEPGRAM_API_KEY.")
    if language not in {"ur", "en", "multi"}:
        raise HTTPException(422, "language must be one of: ur, en, multi")
    content_type = request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
    if content_type not in ALLOWED_AUDIO_TYPES:
        raise HTTPException(415, "Upload WAV, WebM, OGG, MP3, M4A, AAC, or FLAC audio.")

    chunks: list[bytes] = []
    size = 0
    async for chunk in request.stream():
        size += len(chunk)
        if size > MAX_AUDIO_BYTES:
            raise HTTPException(413, "Audio clips must be 20 MB or smaller.")
        chunks.append(chunk)
    audio = b"".join(chunks)
    if not audio:
        raise HTTPException(400, "Audio clip is empty.")

    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(40.0, connect=8.0)) as client:
            upstream = await client.post(
                "https://api.deepgram.com/v1/listen",
                params={"model": s.deepgram_model, "language": language, "smart_format": "true"},
                headers={"Authorization": f"Token {s.deepgram_api_key}", "Content-Type": content_type},
                content=audio,
            )
            upstream.raise_for_status()
        payload = upstream.json()
        alternatives = payload.get("results", {}).get("channels", [{}])[0].get("alternatives", [])
        best = alternatives[0] if alternatives else {}
        transcript = str(best.get("transcript", "")).strip()
        if not transcript:
            raise HTTPException(422, "No speech was recognized. Try a clearer or longer recording.")
        return {"text": transcript, "confidence": best.get("confidence"), "provider": "deepgram", "language": language}
    except HTTPException:
        raise
    except httpx.HTTPStatusError as exc:
        log.warning("Deepgram transcription failed with status %s", exc.response.status_code)
        raise HTTPException(502, "Speech recognition provider returned an error; check the key, audio format, and quota.") from exc
    except (httpx.HTTPError, ValueError, KeyError, IndexError) as exc:
        log.warning("Deepgram transcription request failed: %s", type(exc).__name__)
        raise HTTPException(502, "Could not complete speech recognition. Check the provider connection and try again.") from exc


@router.post("/voice/speak", dependencies=[Depends(require_demo_access)])
async def synthesize_speech(req: SpeakRequest):
    """Generate one MP3 response with Fish Audio; never returns made-up audio."""
    audio = await synthesize_fish_audio(req.text)
    return Response(content=audio, media_type="audio/mpeg", headers={"Cache-Control": "no-store", "X-Audio-Provider": "fish-audio"})
