"""Appointment management (Day 4 Task 3 + Day 5 validation rules).

Hard rules enforced HERE (not in the LLM), so no prompt can bypass them:
  * never book a slot that is in the past / too soon / too far ahead
  * never book Sundays or outside the assigned agent's working hours
  * never double-book an agent (own table + Google Calendar busy times)
  * never book a property that is not `available`
  * every change is written to: appointments table (audit history) -> calendar -> CRM -> email

Result dicts always carry `ok` and, on failure, a machine-readable `reason` so the
agent can explain the problem and offer alternatives instead of guessing.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta

from sqlalchemy import text

from app import db, timeutil
from app.config import get_settings
from app.services import crm, email_service
from app.services.calendar_service import get_calendar

log = logging.getLogger("appointments")
ACTIVE = ("booked", "rescheduled")


# --------------------------------------------------------------------------- #
# helpers
# --------------------------------------------------------------------------- #
def _row(r) -> dict:
    d = dict(r._mapping)
    d["history"] = json.loads(d.get("history") or "[]")
    return d


def get_appointment(appt_id: int) -> dict | None:
    with db.conn() as c:
        r = c.execute(text("SELECT * FROM appointments WHERE id=:i"), {"i": appt_id}).first()
    return _row(r) if r else None


def get_agent(agent_id: int) -> dict:
    with db.conn() as c:
        r = c.execute(text("SELECT * FROM agents WHERE id=:i"), {"i": agent_id}).first()
    return dict(r._mapping)


def upcoming_for_phone(phone: str) -> list[dict]:
    now = timeutil.iso(timeutil.now())
    with db.conn() as c:
        rows = c.execute(text("""SELECT * FROM appointments WHERE customer_phone=:p AND status IN ('booked','rescheduled')
                                 AND start_ts >= :n ORDER BY start_ts"""), {"p": phone, "n": now}).all()
    return [_row(r) for r in rows]


def history_for_phone(phone: str) -> list[dict]:
    with db.conn() as c:
        rows = c.execute(text("SELECT * FROM appointments WHERE customer_phone=:p ORDER BY start_ts DESC"), {"p": phone}).all()
    return [_row(r) for r in rows]


def _agent_busy(agent_id: int, start: datetime, end: datetime, exclude_id: int | None = None) -> bool:
    with db.conn() as c:
        rows = c.execute(text("""SELECT id,start_ts,end_ts FROM appointments WHERE agent_id=:a AND status IN ('booked','rescheduled')"""),
                         {"a": agent_id}).all()
    for r in rows:
        if exclude_id and r.id == exclude_id:
            continue
        if timeutil.from_iso(r.start_ts) < end and timeutil.from_iso(r.end_ts) > start:
            return True
    return False


def _hm(s: str) -> tuple[int, int]:
    h, m = s.split(":")
    return int(h), int(m)


# --------------------------------------------------------------------------- #
# validation
# --------------------------------------------------------------------------- #
def validate_slot(agent: dict, start: datetime, *, exclude_id: int | None = None) -> dict:
    """Returns {ok: True} or {ok: False, reason, message}. Pure policy - no side effects."""
    s = get_settings()
    now = timeutil.now()
    end = start + timedelta(minutes=s.slot_minutes)
    if start.tzinfo is None:
        start = start.replace(tzinfo=timeutil.tz()); end = start + timedelta(minutes=s.slot_minutes)

    def bad(reason, msg):
        return {"ok": False, "reason": reason, "message": msg}

    if start <= now:
        return bad("past", "That time has already passed.")
    if start < now + timedelta(hours=s.booking_notice_hours):
        return bad("too_soon", f"We need at least {s.booking_notice_hours} hours notice for a visit.")
    if start > now + timedelta(days=s.booking_horizon_days):
        return bad("too_far", f"We can only book up to {s.booking_horizon_days} days ahead.")
    if start.weekday() == 6:
        return bad("sunday", "Visits are not scheduled on Sundays.")
    ws, we = _hm(agent.get("work_start") or "10:00"), _hm(agent.get("work_end") or "19:00")
    day_open = start.replace(hour=ws[0], minute=ws[1], second=0, microsecond=0)
    day_close = start.replace(hour=we[0], minute=we[1], second=0, microsecond=0)
    if start < day_open or end > day_close:
        return bad("outside_hours", f"Visits run between {agent['work_start']} and {agent['work_end']}.")
    if start.minute % s.slot_minutes != 0:
        return bad("misaligned", f"Slots start on the hour or half hour.")
    if _agent_busy(agent["id"], start, end, exclude_id):
        return bad("conflict", f"{agent['name']} already has a visit at that time.")
    try:
        for a, b in get_calendar().external_busy(agent, start, end):
            if a < end and b > start:
                return bad("conflict", f"{agent['name']} is busy at that time.")
    except Exception as e:                      # never let a calendar outage block bookings silently
        log.warning("external busy lookup failed: %s", e)
    return {"ok": True}


def next_free_slots(agent: dict, after: datetime, n: int = 3, *, exclude_id: int | None = None,
                    same_day_first: bool = True) -> list[datetime]:
    """Next n valid slots starting at/after `after` (used to offer alternatives)."""
    s = get_settings()
    out: list[datetime] = []
    cur = after.replace(second=0, microsecond=0)
    if cur.minute % s.slot_minutes:
        cur += timedelta(minutes=s.slot_minutes - cur.minute % s.slot_minutes)
    limit = timeutil.now() + timedelta(days=s.booking_horizon_days)
    while len(out) < n and cur < limit:
        if validate_slot(agent, cur, exclude_id=exclude_id)["ok"]:
            out.append(cur)
        cur += timedelta(minutes=s.slot_minutes)
    return out


def suggest_alternatives(agent: dict, wanted: datetime, n: int = 3, exclude_id: int | None = None) -> list[datetime]:
    """Prefer slots on the same day (later), then following days at the same hour, then anything."""
    alts: list[datetime] = []
    for cand in next_free_slots(agent, wanted, 12, exclude_id=exclude_id):
        if cand.date() == wanted.date() and cand != wanted:
            alts.append(cand)
        if len(alts) >= n:
            return alts
    day = wanted
    for _ in range(10):
        day = (day + timedelta(days=1)).replace(hour=wanted.hour, minute=wanted.minute)
        if validate_slot(agent, day, exclude_id=exclude_id)["ok"] and day not in alts:
            alts.append(day)
        if len(alts) >= n:
            break
    return alts[:n]


# --------------------------------------------------------------------------- #
# booking
# --------------------------------------------------------------------------- #
def _with_retry(fn, tries: int = 3):
    import time
    last = None
    for i in range(tries):
        try:
            return fn()
        except Exception as e:
            last = e
            log.warning("calendar op failed (%s/%s): %s", i + 1, tries, e)
            time.sleep(0.3 * (2 ** i))
    raise last


def book(*, customer_name: str, customer_phone: str, property_id: int, start: datetime,
         notes: str = "", call_id: str | None = None, requirements: dict | None = None,
         notify: bool = True) -> dict:
    prop = db.get_property(property_id)
    if not prop:
        return {"ok": False, "reason": "property_not_found", "message": f"Property {property_id} does not exist."}
    if prop["status"] != "available":
        return {"ok": False, "reason": "property_unavailable",
                "message": f"Property {property_id} is {prop['status']} and cannot be booked."}
    if not prop.get("agent_id"):
        return {"ok": False, "reason": "no_agent", "message": "No agent assigned to this property."}
    agent = get_agent(prop["agent_id"])
    if start.tzinfo is None:
        start = start.replace(tzinfo=timeutil.tz())
    v = validate_slot(agent, start)
    if not v["ok"]:
        return {**v, "agent": agent["name"],
                "alternatives": [timeutil.iso(a) for a in suggest_alternatives(agent, start)]}

    end = start + timedelta(minutes=get_settings().slot_minutes)
    cust = crm.upsert_customer(customer_phone, customer_name)
    now_iso = timeutil.iso(timeutil.now())
    hist = [{"ts": now_iso, "event": "booked", "start": timeutil.iso(start)}]
    with db.conn() as c:   # re-check inside the write transaction to shrink the double-booking race window
        if _agent_busy(agent["id"], start, end):
            return {"ok": False, "reason": "conflict", "message": f"{agent['name']} is no longer free then.",
                    "alternatives": [timeutil.iso(a) for a in suggest_alternatives(agent, start)]}
        res = c.execute(text("""INSERT INTO appointments(customer_id,call_id,property_id,agent_id,customer_name,customer_phone,
                  start_ts,end_ts,status,sync_status,notes,history,created_at,updated_at)
                  VALUES(:cu,:call,:p,:a,:n,:ph,:s,:e,'booked','pending',:no,:h,:t,:t)"""),
                        {"cu": cust["id"], "call": call_id, "p": property_id, "a": agent["id"], "n": customer_name,
                         "ph": customer_phone, "s": timeutil.iso(start), "e": timeutil.iso(end), "no": notes,
                         "h": json.dumps(hist), "t": now_iso})
        appt_id = res.lastrowid
    appt = get_appointment(appt_id)

    # calendar (with retry). A calendar outage must not lose the booking: it stays sync_status=pending.
    try:
        ev = _with_retry(lambda: get_calendar().create_event(appt, agent, prop))
        _update(appt_id, calendar_event_id=ev, sync_status="ok")
    except Exception as e:
        log.error("calendar create failed for appt %s: %s", appt_id, e)
        crm.add_followup(customer_phone, now_iso, f"Calendar sync pending for appointment #{appt_id}")

    # CRM
    if requirements:
        crm.save_preferences(customer_phone, requirements)
    crm.bump_lead_score(customer_phone, 40)
    crm.add_followup(customer_phone, timeutil.iso(start + timedelta(days=1)),
                     f"Post-visit follow-up: property #{property_id} ({prop['title']})")

    appt = get_appointment(appt_id)
    out = {"ok": True, "appointment": appt, "agent": agent["name"], "property": prop["title"]}
    if notify:
        out["email"] = notify_appointment(appt_id, "booked", requirements)
    return out


def _update(appt_id: int, **fields) -> None:
    fields["updated_at"] = timeutil.iso(timeutil.now())
    sets = ", ".join(f"{k}=:{k}" for k in fields)
    with db.conn() as c:
        c.execute(text(f"UPDATE appointments SET {sets} WHERE id=:_id"), {**fields, "_id": appt_id})


def _push_history(appt_id: int, entry: dict) -> None:
    a = get_appointment(appt_id)
    _update(appt_id, history=json.dumps(a["history"] + [{"ts": timeutil.iso(timeutil.now()), **entry}]))


def notify_appointment(appt_id: int, kind: str, requirements: dict | None = None, old_start: str | None = None) -> dict:
    appt = get_appointment(appt_id)
    agent, prop = get_agent(appt["agent_id"]), db.get_property(appt["property_id"])
    if requirements is None:
        cust = crm.get_customer(appt["customer_phone"])
        requirements = (cust or {}).get("preferences", {})
    try:
        return email_service.notify_employee(kind, appt, agent, prop, requirements, old_start)
    except Exception as e:
        log.error("notify failed: %s", e)
        return {"status": "error", "error": str(e)}


# --------------------------------------------------------------------------- #
# reschedule / cancel
# --------------------------------------------------------------------------- #
def reschedule(appt_id: int, new_start: datetime, *, notify: bool = True) -> dict:
    appt = get_appointment(appt_id)
    if not appt or appt["status"] not in ACTIVE:
        return {"ok": False, "reason": "not_found", "message": "No active appointment with that id."}
    agent, prop = get_agent(appt["agent_id"]), db.get_property(appt["property_id"])
    if new_start.tzinfo is None:
        new_start = new_start.replace(tzinfo=timeutil.tz())
    if timeutil.from_iso(appt["start_ts"]) - timeutil.now() < timedelta(hours=get_settings().booking_notice_hours):
        return {"ok": False, "reason": "too_late_to_change",
                "message": f"Changes need {get_settings().booking_notice_hours} hours notice; please call the agent directly."}
    if prop["status"] not in ("available", "reserved"):
        return {"ok": False, "reason": "property_unavailable", "message": f"Property is now {prop['status']}."}
    v = validate_slot(agent, new_start, exclude_id=appt_id)
    if not v["ok"]:
        return {**v, "alternatives": [timeutil.iso(a) for a in suggest_alternatives(agent, new_start, exclude_id=appt_id)]}
    old = appt["start_ts"]
    end = new_start + timedelta(minutes=get_settings().slot_minutes)
    _push_history(appt_id, {"event": "rescheduled", "from": old, "to": timeutil.iso(new_start)})
    _update(appt_id, start_ts=timeutil.iso(new_start), end_ts=timeutil.iso(end), status="rescheduled")
    appt = get_appointment(appt_id)
    if appt["calendar_event_id"]:
        try:
            _with_retry(lambda: get_calendar().update_event(appt["calendar_event_id"], appt, agent, prop))
        except Exception as e:
            log.error("calendar update failed: %s", e)
            _update(appt_id, sync_status="pending")
    out = {"ok": True, "appointment": get_appointment(appt_id), "old_start": old}
    if notify:
        out["email"] = notify_appointment(appt_id, "rescheduled", old_start=old)
    return out


def cancel(appt_id: int, reason: str = "", *, notify: bool = True) -> dict:
    appt = get_appointment(appt_id)
    if not appt or appt["status"] not in ACTIVE:
        return {"ok": False, "reason": "not_found", "message": "No active appointment with that id."}
    agent, prop = get_agent(appt["agent_id"]), db.get_property(appt["property_id"])
    _push_history(appt_id, {"event": "cancelled", "reason": reason})
    _update(appt_id, status="cancelled", notes=(appt.get("notes") or "") + (f" | cancelled: {reason}" if reason else ""))
    if appt["calendar_event_id"]:
        try:
            _with_retry(lambda: get_calendar().delete_event(appt["calendar_event_id"]))
        except Exception as e:
            log.error("calendar delete failed: %s", e)
            _update(appt_id, sync_status="pending")
    crm.add_followup(appt["customer_phone"], timeutil.iso(timeutil.now() + timedelta(days=2)),
                     f"Re-engage after cancelled visit (property #{appt['property_id']})")
    out = {"ok": True, "appointment": get_appointment(appt_id)}
    if notify:
        out["email"] = notify_appointment(appt_id, "cancelled")
    return out


def retry_pending_calendar_syncs() -> dict:
    """Re-run calendar operations that failed earlier (called from /admin/retry-sync or cron)."""
    with db.conn() as c:
        rows = c.execute(text("SELECT id FROM appointments WHERE sync_status='pending'")).all()
    fixed = 0
    for (aid,) in rows:
        appt = get_appointment(aid)
        agent, prop = get_agent(appt["agent_id"]), db.get_property(appt["property_id"])
        try:
            if appt["status"] == "cancelled":
                if appt["calendar_event_id"]:
                    get_calendar().delete_event(appt["calendar_event_id"])
            elif appt["calendar_event_id"]:
                get_calendar().update_event(appt["calendar_event_id"], appt, agent, prop)
            else:
                _update(aid, calendar_event_id=get_calendar().create_event(appt, agent, prop))
            _update(aid, sync_status="ok"); fixed += 1
        except Exception as e:
            log.warning("sync retry failed for %s: %s", aid, e)
    return {"pending": len(rows), "fixed": fixed}
