"""CRM-ready logging: customers, preferences, calls/transcripts, follow-ups, node events.

Every table is plain SQL so a later sync to Salesforce / HubSpot is a straight export
(see docs: 'CRM integration path')."""
from __future__ import annotations

import json
import uuid

from sqlalchemy import text

from app import timeutil
from app.db import conn


def _ts() -> str:
    return timeutil.iso(timeutil.now())


def upsert_customer(phone: str | None, name: str | None = None, email: str | None = None,
                    gender_hint: str | None = None) -> dict | None:
    if not phone:
        return None
    with conn() as c:
        r = c.execute(text("SELECT * FROM customers WHERE phone=:p"), {"p": phone}).first()
        if r is None:
            c.execute(text("""INSERT INTO customers(phone,name,email,gender_hint,preferences,lead_score,created_at,last_contact)
                              VALUES(:p,:n,:e,:g,'{}',0,:t,:t)"""),
                      {"p": phone, "n": name, "e": email, "g": gender_hint, "t": _ts()})
        else:
            c.execute(text("""UPDATE customers SET name=COALESCE(:n,name), email=COALESCE(:e,email),
                              gender_hint=COALESCE(:g,gender_hint), last_contact=:t WHERE phone=:p"""),
                      {"p": phone, "n": name, "e": email, "g": gender_hint, "t": _ts()})
        r = c.execute(text("SELECT * FROM customers WHERE phone=:p"), {"p": phone}).first()
    return _cust(r)


def _cust(r) -> dict:
    d = dict(r._mapping)
    d["preferences"] = json.loads(d.get("preferences") or "{}")
    return d


def get_customer(phone: str) -> dict | None:
    with conn() as c:
        r = c.execute(text("SELECT * FROM customers WHERE phone=:p"), {"p": phone}).first()
    return _cust(r) if r else None


def save_preferences(phone: str, prefs: dict) -> None:
    clean = {k: v for k, v in prefs.items() if v not in (None, [], "", False)}
    if not phone or not clean:
        return
    cust = upsert_customer(phone)
    merged = {**cust["preferences"], **clean}
    with conn() as c:
        c.execute(text("UPDATE customers SET preferences=:p WHERE phone=:ph"),
                  {"p": json.dumps(merged, ensure_ascii=False), "ph": phone})


def bump_lead_score(phone: str, points: int) -> int:
    with conn() as c:
        c.execute(text("UPDATE customers SET lead_score=MIN(100, COALESCE(lead_score,0)+:x) WHERE phone=:p"),
                  {"x": points, "p": phone})
        r = c.execute(text("SELECT lead_score FROM customers WHERE phone=:p"), {"p": phone}).first()
    return r[0] if r else 0


# ------------------------------- calls & transcripts ------------------------------- #
def start_call(caller_phone: str | None) -> str:
    call_id = "call_" + uuid.uuid4().hex[:10]
    cust = upsert_customer(caller_phone) if caller_phone else None
    with conn() as c:
        c.execute(text("INSERT INTO calls(id,customer_id,caller_phone,started_at,turns) VALUES(:i,:c,:p,:t,0)"),
                  {"i": call_id, "c": cust["id"] if cust else None, "p": caller_phone, "t": _ts()})
    return call_id


def log_message(call_id: str, role: str, content: str) -> None:
    with conn() as c:
        c.execute(text("INSERT INTO messages(call_id,role,content,ts) VALUES(:i,:r,:c,:t)"),
                  {"i": call_id, "r": role, "c": content, "t": _ts()})
        if role == "user":
            c.execute(text("UPDATE calls SET turns=COALESCE(turns,0)+1 WHERE id=:i"), {"i": call_id})


def end_call(call_id: str, outcome: str, summary: str = "") -> None:
    with conn() as c:
        c.execute(text("UPDATE calls SET ended_at=:t, outcome=:o, summary=:s WHERE id=:i"),
                  {"t": _ts(), "o": outcome, "s": summary, "i": call_id})


def get_transcript(call_id: str) -> list[dict]:
    with conn() as c:
        rows = c.execute(text("SELECT role,content,ts FROM messages WHERE call_id=:i ORDER BY id"), {"i": call_id}).all()
    return [dict(r._mapping) for r in rows]


def get_call(call_id: str) -> dict | None:
    with conn() as c:
        r = c.execute(text("SELECT * FROM calls WHERE id=:i"), {"i": call_id}).first()
    return dict(r._mapping) if r else None


# ------------------------------- follow-ups ------------------------------- #
def add_followup(phone: str, due_at: str, reason: str) -> None:
    cust = upsert_customer(phone)
    if not cust:
        return
    with conn() as c:
        c.execute(text("INSERT INTO follow_ups(customer_id,due_at,reason,status) VALUES(:c,:d,:r,'open')"),
                  {"c": cust["id"], "d": due_at, "r": reason})


def open_followups(phone: str | None = None) -> list[dict]:
    sql = "SELECT f.*, cu.phone, cu.name FROM follow_ups f JOIN customers cu ON cu.id=f.customer_id WHERE f.status='open'"
    p = {}
    if phone:
        sql += " AND cu.phone=:p"; p["p"] = phone
    with conn() as c:
        rows = c.execute(text(sql + " ORDER BY f.due_at"), p).all()
    return [dict(r._mapping) for r in rows]


# ------------------------------- graph node events ------------------------------- #
def log_node_event(call_id: str, turn: int, node: str, duration_ms: float, detail: dict) -> None:
    with conn() as c:
        c.execute(text("INSERT INTO node_events(call_id,turn,node,ts,duration_ms,detail) VALUES(:i,:t,:n,:ts,:d,:x)"),
                  {"i": call_id, "t": turn, "n": node, "ts": _ts(), "d": round(duration_ms, 2),
                   "x": json.dumps(detail, ensure_ascii=False, default=str)})


def get_node_events(call_id: str) -> list[dict]:
    with conn() as c:
        rows = c.execute(text("SELECT * FROM node_events WHERE call_id=:i ORDER BY id"), {"i": call_id}).all()
    out = []
    for r in rows:
        d = dict(r._mapping); d["detail"] = json.loads(d["detail"] or "{}"); out.append(d)
    return out
