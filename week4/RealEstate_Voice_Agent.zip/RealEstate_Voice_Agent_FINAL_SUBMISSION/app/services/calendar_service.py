"""Calendar back-ends.

MockCalendar   - offline; the `appointments` table IS the calendar (perfect for tests/demo).
GoogleCalendar - real Google Calendar API (OAuth user token or service account).

Both expose the same 4 methods so the booking logic never knows which is active.
Availability is *always* enforced against our own appointments table first; Google
`events.list` is used as an additional busy-source so manual events also block slots
(events we created carry a private marker and are ignored to avoid self-blocking).
"""
from __future__ import annotations

import logging
import uuid
from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path

from app.config import get_settings

log = logging.getLogger("calendar")
MARK = {"rehub": "1"}


def event_body(appt: dict, agent: dict, prop: dict, tzname: str) -> dict:
    """Calendar event payload: client, phone, employee, property, date, time, notes (Day 4 Task 1)."""
    s = get_settings()
    desc = (
        f"Client: {appt['customer_name']}\nPhone: {appt['customer_phone']}\n"
        f"Assigned employee: {agent['name']} ({agent['email']})\n"
        f"Property #{prop['id']}: {prop['title']}\nArea: {prop['area']}, {prop['city']}\n"
        f"Meeting notes: {appt.get('notes') or '-'}\n\nBooked by the {s.company_name} AI voice assistant."
    )
    return {
        "summary": f"Property visit: {prop['title']} - {appt['customer_name']}",
        "location": f"{prop['area']}, {prop['city']}",
        "description": desc,
        "start": {"dateTime": appt["start_ts"], "timeZone": tzname},
        "end": {"dateTime": appt["end_ts"], "timeZone": tzname},
        "extendedProperties": {"private": {**MARK, "appointment_id": str(appt.get("id", ""))}},
        "reminders": {"useDefault": False, "overrides": [{"method": "popup", "minutes": 60}]},
    }


class CalendarBackend(ABC):
    name: str

    @abstractmethod
    def create_event(self, appt: dict, agent: dict, prop: dict) -> str: ...
    @abstractmethod
    def update_event(self, event_id: str, appt: dict, agent: dict, prop: dict) -> None: ...
    @abstractmethod
    def delete_event(self, event_id: str) -> None: ...

    def external_busy(self, agent: dict, start: datetime, end: datetime) -> list[tuple[datetime, datetime]]:
        return []


class MockCalendar(CalendarBackend):
    name = "mock"

    def create_event(self, appt, agent, prop):
        return "mock_evt_" + uuid.uuid4().hex[:10]

    def update_event(self, event_id, appt, agent, prop):
        return None

    def delete_event(self, event_id):
        return None


class GoogleCalendar(CalendarBackend):
    name = "google"
    SCOPES = ["https://www.googleapis.com/auth/calendar"]

    def __init__(self):
        self._svc = None

    def _service(self):
        if self._svc:
            return self._svc
        from googleapiclient.discovery import build
        s = get_settings()
        cred_path, token_path = Path(s.google_credentials_file), Path(s.google_token_file)
        creds = None
        if cred_path.exists() and '"service_account"' in cred_path.read_text():
            from google.oauth2 import service_account
            creds = service_account.Credentials.from_service_account_file(str(cred_path), scopes=self.SCOPES)
        elif token_path.exists():
            from google.oauth2.credentials import Credentials
            from google.auth.transport.requests import Request
            creds = Credentials.from_authorized_user_file(str(token_path), self.SCOPES)
            if creds.expired and creds.refresh_token:
                creds.refresh(Request())
                token_path.write_text(creds.to_json())
        if creds is None:
            raise RuntimeError("Google Calendar not authorised. Run: python scripts/google_auth.py")
        self._svc = build("calendar", "v3", credentials=creds, cache_discovery=False)
        return self._svc

    def _attendees(self, agent):
        s = get_settings()
        email = s.demo_agent_email or agent["email"]
        return [{"email": email, "displayName": agent["name"]}]

    def create_event(self, appt, agent, prop):
        s = get_settings()
        body = event_body(appt, agent, prop, s.timezone)
        body["attendees"] = self._attendees(agent)
        ev = self._service().events().insert(calendarId=s.google_calendar_id, body=body, sendUpdates="all").execute()
        return ev["id"]

    def update_event(self, event_id, appt, agent, prop):
        s = get_settings()
        body = event_body(appt, agent, prop, s.timezone)
        body["attendees"] = self._attendees(agent)
        self._service().events().update(calendarId=s.google_calendar_id, eventId=event_id, body=body, sendUpdates="all").execute()

    def delete_event(self, event_id):
        s = get_settings()
        self._service().events().delete(calendarId=s.google_calendar_id, eventId=event_id, sendUpdates="all").execute()

    def external_busy(self, agent, start, end):
        s = get_settings()
        if not s.google_check_freebusy:
            return []
        res = self._service().events().list(
            calendarId=s.google_calendar_id, timeMin=start.isoformat(), timeMax=end.isoformat(),
            singleEvents=True, orderBy="startTime").execute()
        out = []
        for ev in res.get("items", []):
            if ev.get("status") == "cancelled" or ev.get("extendedProperties", {}).get("private", {}).get("rehub"):
                continue
            a, b = ev["start"].get("dateTime"), ev["end"].get("dateTime")
            if a and b:
                out.append((datetime.fromisoformat(a), datetime.fromisoformat(b)))
        return out


_BACKEND: CalendarBackend | None = None


def get_calendar() -> CalendarBackend:
    global _BACKEND
    if _BACKEND is None:
        _BACKEND = GoogleCalendar() if get_settings().calendar_mode == "google" else MockCalendar()
    return _BACKEND


def set_calendar(b: CalendarBackend | None) -> None:
    global _BACKEND
    _BACKEND = b
