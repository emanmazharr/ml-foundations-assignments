"""Email automation: mock (files) | Resend API | Gmail SMTP - with retries and a persistent outbox.

Failure policy: try up to 3 times with backoff; if it still fails the message is stored in the
`outbox` table (status=pending) so a booking is NEVER lost because email was down.
`retry_outbox()` (called by n8n / cron / POST /admin/retry-outbox) re-sends pending mail."""
from __future__ import annotations

import html
import json
import logging
import smtplib
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

import httpx
from sqlalchemy import text

from app import timeutil
from app.config import get_settings
from app.db import conn, pkr_words

log = logging.getLogger("email")
MAX_ATTEMPTS = 5


# ------------------------------- transport ------------------------------- #
def _send_mock(to: str, subject: str, html_body: str, text_body: str) -> None:
    d = Path(get_settings().outbox_dir)
    d.mkdir(parents=True, exist_ok=True)
    stamp = timeutil.now().strftime("%Y%m%d-%H%M%S-%f")
    (d / f"{stamp}.json").write_text(json.dumps({"to": to, "subject": subject, "text": text_body}, indent=2, ensure_ascii=False))
    (d / f"{stamp}.html").write_text(html_body, encoding="utf-8")


def _send_resend(to, subject, html_body, text_body) -> None:
    s = get_settings()
    r = httpx.post("https://api.resend.com/emails", timeout=10,
                   headers={"Authorization": f"Bearer {s.resend_api_key}"},
                   json={"from": s.email_from, "to": [to], "subject": subject, "html": html_body, "text": text_body})
    r.raise_for_status()


def _send_smtp(to, subject, html_body, text_body) -> None:
    s = get_settings()
    msg = MIMEMultipart("alternative")
    msg["Subject"], msg["From"], msg["To"] = subject, s.email_from or s.smtp_user, to
    msg.attach(MIMEText(text_body, "plain", "utf-8"))
    msg.attach(MIMEText(html_body, "html", "utf-8"))
    with smtplib.SMTP(s.smtp_host, s.smtp_port, timeout=15) as srv:
        srv.starttls()
        srv.login(s.smtp_user, s.smtp_password)
        srv.sendmail(msg["From"], [to], msg.as_string())


def _transport():
    return {"mock": _send_mock, "resend": _send_resend, "smtp": _send_smtp}[get_settings().email_mode]


def _deliver(to: str, subject: str, html_body: str, text_body: str, retries: int = 3, backoff: float = 0.4) -> None:
    fn, last = _transport(), None
    for i in range(retries):
        try:
            fn(to, subject, html_body, text_body)
            return
        except Exception as e:                       # network / auth / provider error
            last = e
            log.warning("email attempt %s/%s failed: %s", i + 1, retries, e)
            time.sleep(backoff * (2 ** i))
    raise RuntimeError(f"email delivery failed: {last}")


def send_email(kind: str, to: str, subject: str, html_body: str, text_body: str) -> dict:
    """Send now; on failure persist to the outbox for later retry."""
    now = timeutil.iso(timeutil.now())
    try:
        _deliver(to, subject, html_body, text_body)
        status, err = "sent", None
    except Exception as e:
        status, err = "pending", str(e)[:300]
    with conn() as c:
        c.execute(text("""INSERT INTO outbox(kind,to_email,subject,html,text_body,status,attempts,last_error,created_at)
                          VALUES(:k,:t,:s,:h,:x,:st,:a,:e,:c)"""),
                  {"k": kind, "t": to, "s": subject, "h": html_body, "x": text_body, "st": status,
                   "a": 1, "e": err, "c": now})
    return {"status": "sent" if status == "sent" else "queued", "to": to, "error": err}


def retry_outbox() -> dict:
    sent = failed = 0
    with conn() as c:
        rows = c.execute(text("SELECT * FROM outbox WHERE status='pending' AND attempts < :m"), {"m": MAX_ATTEMPTS}).all()
    for r in rows:
        try:
            _deliver(r.to_email, r.subject, r.html, r.text_body, retries=1)
            st, err = "sent", None
        except Exception as e:
            st, err = ("failed" if r.attempts + 1 >= MAX_ATTEMPTS else "pending"), str(e)[:300]
        with conn() as c:
            c.execute(text("UPDATE outbox SET status=:s, attempts=attempts+1, last_error=:e WHERE id=:i"),
                      {"s": st, "e": err, "i": r.id})
        sent += st == "sent"; failed += st != "sent"
    return {"retried": len(rows), "sent": sent, "still_failing": failed}


def outbox_stats() -> dict:
    with conn() as c:
        rows = c.execute(text("SELECT status, COUNT(*) FROM outbox GROUP BY status")).all()
    return {r[0]: r[1] for r in rows}


# ------------------------------- templates (employee notifications) ------------------------------- #
_HEAD = {
    "booked": ("New property visit booked", "#0f766e"),
    "rescheduled": ("Property visit RESCHEDULED", "#b45309"),
    "cancelled": ("Property visit CANCELLED", "#b91c1c"),
}


def employee_email(kind: str, appt: dict, agent: dict, prop: dict, requirements: dict | None = None,
                   old_start: str | None = None) -> tuple[str, str, str]:
    """Return (subject, html, text) for the assigned employee. Includes meeting time, property,
    client details and requirements (Day 4 Task 2)."""
    s = get_settings()
    title, colour = _HEAD[kind]
    start = timeutil.from_iso(appt["start_ts"])
    when = start.strftime("%A, %d %B %Y at %I:%M %p") + f" ({s.timezone})"
    old = timeutil.from_iso(old_start).strftime("%A, %d %B %Y at %I:%M %p") if old_start else None
    price = f"PKR {int(prop['price_pkr']):,} ({pkr_words(prop['price_pkr'])})" + (" / month" if prop["purpose"] == "rent" else "")
    req = {k: v for k, v in (requirements or {}).items() if v not in (None, "", [], False)}
    req_lines = []
    label = {"budget_max": "Budget (max)", "city": "City", "area": "Area", "bedrooms": "Bedrooms",
             "purpose": "Purpose", "ptype": "Type", "investment": "Investment goal"}
    for k, v in req.items():
        if k == "budget_max":
            v = f"PKR {pkr_words(v)}"
        req_lines.append((label.get(k, k), str(v)))
    rows = [
        ("Meeting time", when + (f"  (was: {old})" if old else "")),
        ("Property", f"#{prop['id']} - {prop['title']}"),
        ("Price", price),
        ("Location", f"{prop['area']}, {prop['city']}"),
        ("Client name", appt["customer_name"]),
        ("Client phone", appt["customer_phone"]),
        ("Assigned to", f"{agent['name']}"),
        ("Notes", appt.get("notes") or "-"),
    ] + [(f"Requirement - {k}", v) for k, v in req_lines]
    subject = f"[{s.company_name}] {title}: {appt['customer_name']} - {start.strftime('%d %b %I:%M %p')}"
    body_rows = "".join(f"<tr><td style='padding:6px 12px;color:#555'><b>{html.escape(k)}</b></td>"
                        f"<td style='padding:6px 12px'>{html.escape(str(v))}</td></tr>" for k, v in rows)
    html_body = (f"<div style='font-family:Arial,sans-serif;max-width:560px'>"
                 f"<h2 style='color:{colour}'>{title}</h2><p>Hi {html.escape(agent['name'])},</p>"
                 f"<p>The AI voice assistant recorded the following. Please check your calendar.</p>"
                 f"<table style='border-collapse:collapse;background:#f8fafc;border-radius:8px'>{body_rows}</table>"
                 f"<p style='color:#888;font-size:12px'>Sent automatically by {s.company_name} AI Voice Agent.</p></div>")
    text_body = f"{title}\n\n" + "\n".join(f"{k}: {v}" for k, v in rows)
    return subject, html_body, text_body


def notify_employee(kind: str, appt: dict, agent: dict, prop: dict, requirements: dict | None = None,
                    old_start: str | None = None) -> dict:
    s = get_settings()
    to = s.demo_agent_email or agent["email"]
    subject, h, t = employee_email(kind, appt, agent, prop, requirements, old_start)
    return send_email(f"appointment_{kind}", to, subject, h, t)
