"""Structured data layer (SQL).

Why SQL for these facts?  Prices, availability, plot sizes and agent names are
*exact, frequently-changing, filterable* values.  Embedding them in a vector
index would make them stale and "approximately right" -- unacceptable for a
sales agent.  SQL gives us exact filters, ordering, transactions and freshness.

Works on SQLite (dev) and PostgreSQL (prod) through SQLAlchemy Core.
"""
from __future__ import annotations

import json
from contextlib import contextmanager
from functools import lru_cache
from typing import Any, Iterator

from sqlalchemy import (
    Column, Float, ForeignKey, Integer, MetaData, String, Table, Text, create_engine, text,
)
from sqlalchemy.engine import Engine

from app.config import get_settings

metadata = MetaData()

developers = Table(
    "developers", metadata,
    Column("id", Integer, primary_key=True),
    Column("name", String(120), nullable=False),
    Column("established", Integer),
    Column("headquarters", String(80)),
    Column("approvals", String(200)),
    Column("projects_delivered", Integer),
    Column("track_record", Text),
)

agents = Table(
    "agents", metadata,
    Column("id", Integer, primary_key=True),
    Column("name", String(80), nullable=False),
    Column("email", String(120), nullable=False),
    Column("phone", String(30)),
    Column("city", String(40), nullable=False),
    Column("languages", String(80)),
    Column("calendar_id", String(160)),
    Column("work_start", String(5), default="10:00"),
    Column("work_end", String(5), default="19:00"),
)

areas = Table(
    "areas", metadata,
    Column("id", Integer, primary_key=True),
    Column("name", String(80), nullable=False),
    Column("city", String(40), nullable=False),
    Column("summary", Text),
)

schools = Table(
    "schools", metadata,
    Column("id", Integer, primary_key=True),
    Column("area_id", Integer, ForeignKey("areas.id")),
    Column("name", String(120)),
    Column("level", String(40)),
    Column("distance_km", Float),
)

hospitals = Table(
    "hospitals", metadata,
    Column("id", Integer, primary_key=True),
    Column("area_id", Integer, ForeignKey("areas.id")),
    Column("name", String(120)),
    Column("speciality", String(80)),
    Column("distance_km", Float),
)

properties = Table(
    "properties", metadata,
    Column("id", Integer, primary_key=True),
    Column("title", String(160), nullable=False),
    Column("ptype", String(20), nullable=False),  # house|apartment|plot|shop|office
    Column("category", String(20), nullable=False),  # residential|commercial
    Column("purpose", String(10), nullable=False),  # sale|rent
    Column("area_id", Integer, ForeignKey("areas.id"), nullable=False),
    Column("bedrooms", Integer, default=0),
    Column("bathrooms", Integer, default=0),
    Column("size_value", Float, nullable=False),
    Column("size_unit", String(10), nullable=False),  # marla|kanal|sqft|sq_yd
    Column("price_pkr", Float, nullable=False),  # sale price OR monthly rent
    Column("status", String(12), nullable=False, default="available"),  # available|reserved|sold|rented
    Column("developer_id", Integer, ForeignKey("developers.id")),
    Column("agent_id", Integer, ForeignKey("agents.id")),
    Column("amenities", Text, default="[]"),  # JSON list
    Column("rental_yield_pct", Float),
    Column("possession", String(40)),
    Column("description", Text),
)

payment_plans = Table(
    "payment_plans", metadata,
    Column("id", Integer, primary_key=True),
    Column("property_id", Integer, ForeignKey("properties.id")),
    Column("plan_name", String(60)),
    Column("down_payment_pct", Float),
    Column("installments", Integer),  # number of monthly installments
    Column("monthly_installment_pkr", Float),
    Column("token_pkr", Float),
)


# ------------------------------- CRM / operations tables ------------------------------- #
customers = Table(
    "customers", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("phone", String(30), nullable=False, index=True),
    Column("name", String(80)),
    Column("email", String(120)),
    Column("gender_hint", String(10)),
    Column("preferences", Text, default="{}"),      # JSON: budget, city, area, bedrooms, purpose...
    Column("lead_score", Integer, default=0),
    Column("created_at", String(40)),
    Column("last_contact", String(40)),
)

calls = Table(
    "calls", metadata,
    Column("id", String(40), primary_key=True),
    Column("customer_id", Integer, ForeignKey("customers.id")),
    Column("caller_phone", String(30)),
    Column("started_at", String(40)),
    Column("ended_at", String(40)),
    Column("outcome", String(40)),                  # booked | info | no_interest | escalated | dropped
    Column("summary", Text),
    Column("turns", Integer, default=0),
)

messages = Table(
    "messages", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("call_id", String(40), index=True),
    Column("role", String(12)),
    Column("content", Text),
    Column("ts", String(40)),
)

appointments = Table(
    "appointments", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("customer_id", Integer, ForeignKey("customers.id")),
    Column("call_id", String(40)),
    Column("property_id", Integer, ForeignKey("properties.id"), nullable=False),
    Column("agent_id", Integer, ForeignKey("agents.id"), nullable=False),
    Column("customer_name", String(80)),
    Column("customer_phone", String(30)),
    Column("start_ts", String(40), nullable=False),  # ISO-8601 with offset
    Column("end_ts", String(40), nullable=False),
    Column("status", String(14), nullable=False),    # booked | rescheduled | cancelled | completed
    Column("calendar_event_id", String(120)),
    Column("sync_status", String(10), default="ok"), # ok | pending (calendar sync to retry)
    Column("notes", Text),
    Column("history", Text, default="[]"),           # JSON audit trail of changes
    Column("created_at", String(40)),
    Column("updated_at", String(40)),
)

follow_ups = Table(
    "follow_ups", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("customer_id", Integer, ForeignKey("customers.id")),
    Column("due_at", String(40)),
    Column("reason", Text),
    Column("status", String(10), default="open"),   # open | done
)

node_events = Table(
    "node_events", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("call_id", String(40), index=True),
    Column("turn", Integer),
    Column("node", String(40)),
    Column("ts", String(40)),
    Column("duration_ms", Float),
    Column("detail", Text),
)

outbox = Table(
    "outbox", metadata,
    Column("id", Integer, primary_key=True, autoincrement=True),
    Column("kind", String(30)),
    Column("to_email", String(120)),
    Column("subject", String(200)),
    Column("html", Text),
    Column("text_body", Text),
    Column("status", String(10), default="pending"),  # pending | sent | failed
    Column("attempts", Integer, default=0),
    Column("last_error", Text),
    Column("created_at", String(40)),
)


@lru_cache
def get_engine() -> Engine:
    url = get_settings().database_url
    kwargs: dict[str, Any] = {}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False}
    return create_engine(url, future=True, **kwargs)


@contextmanager
def conn() -> Iterator[Any]:
    with get_engine().begin() as c:
        yield c


def init_db(drop: bool = False) -> None:
    if drop:
        metadata.drop_all(get_engine())
    metadata.create_all(get_engine())


# --------------------------------------------------------------------------- #
# Query helpers (all return plain dicts – easy to serialise & feed to the LLM)
# --------------------------------------------------------------------------- #
_BASE = """
SELECT p.*, a.name AS area, a.city AS city, d.name AS developer,
       ag.name AS agent_name, ag.email AS agent_email
FROM properties p
JOIN areas a ON a.id = p.area_id
LEFT JOIN developers d ON d.id = p.developer_id
LEFT JOIN agents ag ON ag.id = p.agent_id
"""


def _row(r) -> dict:
    d = dict(r._mapping)
    d["amenities"] = json.loads(d.get("amenities") or "[]")
    return d


def get_property(property_id: int) -> dict | None:
    with conn() as c:
        r = c.execute(text(_BASE + " WHERE p.id = :id"), {"id": property_id}).first()
    return _row(r) if r else None


def check_availability(property_id: int) -> dict:
    """Tool used by the agent before recommending / booking."""
    p = get_property(property_id)
    if not p:
        return {"property_id": property_id, "exists": False, "available": False}
    return {
        "property_id": property_id, "exists": True,
        "available": p["status"] == "available", "status": p["status"],
        "title": p["title"],
    }


def search_properties(
    *, city: str | None = None, area: str | None = None, purpose: str | None = None,
    ptype: str | None = None, category: str | None = None,
    min_price: float | None = None, max_price: float | None = None,
    min_bedrooms: int | None = None, max_bedrooms: int | None = None,
    only_available: bool = True, limit: int = 50,
) -> list[dict]:
    sql = _BASE + " WHERE 1=1"
    params: dict[str, Any] = {}
    if only_available:
        sql += " AND p.status = 'available'"
    if city:
        sql += " AND LOWER(a.city) = LOWER(:city)"; params["city"] = city
    if area:
        sql += " AND LOWER(a.name) LIKE :area"; params["area"] = f"%{area.lower()}%"
    if purpose:
        sql += " AND p.purpose = :purpose"; params["purpose"] = purpose
    if ptype:
        sql += " AND p.ptype = :ptype"; params["ptype"] = ptype
    if category:
        sql += " AND p.category = :category"; params["category"] = category
    if min_price is not None:
        sql += " AND p.price_pkr >= :minp"; params["minp"] = min_price
    if max_price is not None:
        sql += " AND p.price_pkr <= :maxp"; params["maxp"] = max_price
    if min_bedrooms is not None:
        sql += " AND p.bedrooms >= :minb"; params["minb"] = min_bedrooms
    if max_bedrooms is not None:
        sql += " AND p.bedrooms <= :maxb"; params["maxb"] = max_bedrooms
    sql += " ORDER BY p.price_pkr ASC LIMIT :lim"
    params["lim"] = limit
    with conn() as c:
        rows = c.execute(text(sql), params).all()
    return [_row(r) for r in rows]


def get_payment_plans(property_id: int) -> list[dict]:
    with conn() as c:
        rows = c.execute(
            text("SELECT * FROM payment_plans WHERE property_id = :id"), {"id": property_id}
        ).all()
    return [dict(r._mapping) for r in rows]


def get_agent_for_city(city: str) -> dict | None:
    with conn() as c:
        r = c.execute(
            text("SELECT * FROM agents WHERE LOWER(city) = LOWER(:c) ORDER BY id LIMIT 1"),
            {"c": city},
        ).first()
    return dict(r._mapping) if r else None


def list_areas(city: str | None = None) -> list[dict]:
    sql = "SELECT * FROM areas" + (" WHERE LOWER(city)=LOWER(:c)" if city else "") + " ORDER BY city, name"
    with conn() as c:
        rows = c.execute(text(sql), {"c": city} if city else {}).all()
    return [dict(r._mapping) for r in rows]


def nearby_facilities(area_id: int) -> dict:
    with conn() as c:
        s = c.execute(text("SELECT name, level, distance_km FROM schools WHERE area_id=:a ORDER BY distance_km"), {"a": area_id}).all()
        h = c.execute(text("SELECT name, speciality, distance_km FROM hospitals WHERE area_id=:a ORDER BY distance_km"), {"a": area_id}).all()
    return {"schools": [dict(x._mapping) for x in s], "hospitals": [dict(x._mapping) for x in h]}


# --------------------------------------------------------------------------- #
# Money formatting – used by the voice agent so numbers are spoken naturally
# --------------------------------------------------------------------------- #
def pkr_words(amount: float) -> str:
    """3_40_00_000 -> '3.4 crore', 8_50_000 -> '8.5 lakh', 150000 -> '1.5 lakh'."""
    if amount >= 1e7:
        v = amount / 1e7
        return f"{v:g} crore" if abs(v - round(v)) > 1e-9 else f"{int(round(v))} crore"
    if amount >= 1e5:
        v = amount / 1e5
        return f"{v:g} lakh" if abs(v - round(v)) > 1e-9 else f"{int(round(v))} lakh"
    return f"{int(amount):,} rupees"
