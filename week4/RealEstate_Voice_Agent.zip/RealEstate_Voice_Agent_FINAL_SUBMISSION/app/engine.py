"""Knowledge engine: routes each question to the right retrieval path.

  SQL (structured)  -> prices, availability, sizes, agent names, payment plans, live search
  Vector (semantic) -> brochures, area guides, developer profiles, FAQs, policies

Why split?  A vector index answers "what is this like?" but is unreliable for
"what is the exact price / is it still available?" (stale, approximate, no
filtering). SQL is exact and always fresh. Semantic content, in contrast, is
free text that SQL cannot query. See docs/rag_design.md for the justification.
"""
from __future__ import annotations

import re

from app import db
from app.db import pkr_words
from app.nlp.entities import Entities, parse_utterance
from app.nlp.urdulish import normalise
from app.rag.generator import ABSTAIN, generate_answer
from app.rag.retriever import Retriever
from app.recommender import Profile, recommend

_PRICE = r"price|cost|qeemat|keemat|kimat|kitn[ai]|how much|rate|rent kya|kiraya kitna"
_AVAIL = r"available|availab|mojood|bik gaya|bik chuk|sold|still|status|khali"
_SIZE = r"\bsize\b|marla|kanal|sq ?ft|sq ?yd|square|plot size|area kitna|kitne marle"
_AGENT = r"agent|sales ?person|salesman|executive|kaun dekh|naam"
_PLAN = r"install?ment|qist|payment plan|down ?payment|token"
_FACILITY = r"school|hospital|aspatal|developer|builder|documents?|kagzat|process|policy|commission|tax|loan|overseas|amenit|pool|gym|park|mosque|masjid|guarantee|timing|visit|kanal ?kitne|marla ka|track record|maintenance"
_SEARCH_VERB = r"chahiye|chahie|options?|dikha|dikhao|show|looking|find|dhoond|mil sakta|mil jaye|available|tak|under|budget|koi|suggest|recommend"


def route(question: str, ent: Entities) -> str:
    q = normalise(question)
    if ent.property_id:
        if re.search(_PLAN, q) or re.search(_PRICE, q) or re.search(_AVAIL, q) or re.search(_SIZE, q) or re.search(_AGENT, q):
            # facility words alongside (e.g. "property 30 mein pool hai kya") -> semantic
            if re.search(_FACILITY, q) and not re.search(_PRICE + "|" + _PLAN, q):
                return "rag"
            return "sql"
        return "rag"
    has_filter = any([ent.budget_max, ent.budget_min, ent.bedrooms, ent.ptype, ent.category])
    has_place = any([ent.area, ent.city, ent.budget_max])
    if has_filter and has_place and not re.search(_FACILITY, q) and re.search(_SEARCH_VERB, q):
        return "sql_search"
    return "rag"


_RETRIEVER: Retriever | None = None


def get_retriever() -> Retriever:
    global _RETRIEVER
    if _RETRIEVER is None:
        _RETRIEVER = Retriever.build()
    return _RETRIEVER


def set_retriever(r: Retriever | None) -> None:
    """Swap the retriever (used by evaluation to test different chunk sizes / rebuild after KB refresh)."""
    global _RETRIEVER
    _RETRIEVER = r


def _fmt_property(p: dict) -> str:
    unit = {"marla": "marla", "kanal": "kanal", "sqft": "sq ft", "sq_yd": "sq yd"}[p["size_unit"]]
    size = f"{int(p['size_value']) if float(p['size_value']).is_integer() else p['size_value']} {unit}"
    price = (f"PKR {int(p['price_pkr']):,} ({pkr_words(p['price_pkr'])}) per month"
             if p["purpose"] == "rent" else f"PKR {int(p['price_pkr']):,} ({pkr_words(p['price_pkr'])})")
    beds = f", {p['bedrooms']} bedrooms" if p["bedrooms"] else ""
    return f"Property {p['id']}: {size} {p['ptype']} in {p['area']}, {p['city']}{beds}, {price}."


def _sql_property_answer(q: str, pid: int) -> dict:
    p = db.get_property(pid)
    if not p:
        return {"answer": f"Property {pid} hamare system mein maujood nahi hai.", "facts": [], "abstained": True}
    facts: list[str] = []
    ql = normalise(q)
    if re.search(_PLAN, ql):
        plans = db.get_payment_plans(pid)
        if not plans:
            facts.append(f"Property {pid} is a rental, so no instalment plan applies.")
        for pl in plans:
            facts.append(
                f"Property {pid} payment plan '{pl['plan_name']}': {pl['down_payment_pct']:g}% down payment, "
                f"{pl['installments']} monthly instalments of about PKR {int(pl['monthly_installment_pkr']):,} "
                f"({pkr_words(pl['monthly_installment_pkr'])}), token amount PKR {int(pl['token_pkr']):,} ({pkr_words(pl['token_pkr'])}).")
    elif re.search(_AVAIL, ql) and not re.search(_PRICE, ql):
        st = p["status"]
        facts.append(f"Property {pid} ({p['title']}) is currently {'available' if st == 'available' else st}.")
    elif re.search(_AGENT, ql):
        facts.append(f"Property {pid} is handled by sales agent {p['agent_name']}.")
    elif re.search(_SIZE, ql) and not re.search(_PRICE, ql):
        unit = {"marla": "marla", "kanal": "kanal", "sqft": "sq ft", "sq_yd": "sq yd"}[p["size_unit"]]
        v = int(p["size_value"]) if float(p["size_value"]).is_integer() else p["size_value"]
        facts.append(f"Property {pid} has a size of {v} {unit}.")
    else:
        facts.append(_fmt_property(p))
        facts.append(f"Its status is {p['status']}.")
    return {"answer": " ".join(facts), "facts": facts, "abstained": False}


def _sql_search_answer(ent: Entities, profile: Profile | None) -> dict:
    prof = Profile.from_entities(ent, profile)
    res = recommend(prof, limit=3)
    if not res["matches"]:
        return {"answer": "Filhal in requirements par koi available property nahi hai.", "facts": [],
                "abstained": True, "recommendation": res}
    facts = [_fmt_property(m["property"]) for m in res["matches"]]
    note = f" (Note: exact match nahi mila - {res['relaxed']}.)" if res["relaxed"] else ""
    return {"answer": " ".join(facts) + note, "facts": facts, "abstained": False, "recommendation": res}


def ask(question: str, profile: Profile | None = None, k: int | None = None) -> dict:
    ent = parse_utterance(question)
    r = route(question, ent)
    if r == "sql" and ent.property_id:
        out = _sql_property_answer(question, ent.property_id)
        out.update(route="sql", sources=["sql:properties"], context=out["facts"])
        return out
    if r == "sql_search":
        out = _sql_search_answer(ent, profile)
        out.update(route="sql_search", sources=["sql:properties"], context=out["facts"])
        return out
    hits = get_retriever().retrieve(question, k=k)
    ctx = [h.chunk.text for h in hits]
    gen = generate_answer(question, ctx, idf=get_retriever().idf)
    return {"route": "rag", "answer": gen["answer"], "abstained": gen["abstained"], "facts": [],
            "sources": [h.source for h in hits], "context": ctx,
            "scores": [round(h.score, 3) for h in hits]}
