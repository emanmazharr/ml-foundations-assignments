"""Vector stores: ChromaDB (persistent, default) and a NumPy fallback (zero dependencies)."""
from __future__ import annotations

import numpy as np

from app.rag.chunker import Chunk


class NumpyStore:
    name = "numpy"

    def __init__(self):
        self.chunks: list[Chunk] = []
        self.mat: np.ndarray | None = None

    def reset(self):
        self.chunks, self.mat = [], None

    def add(self, chunks: list[Chunk], vectors: np.ndarray):
        self.chunks = list(chunks)
        self.mat = vectors

    def query(self, vec: np.ndarray, k: int, where: dict | None = None):
        sims = self.mat @ vec
        order = np.argsort(-sims)
        out = []
        for i in order:
            c = self.chunks[i]
            if where and any(c.metadata.get(a) != b for a, b in where.items()):
                continue
            out.append((c, float(sims[i])))
            if len(out) >= k:
                break
        return out


class ChromaStore:
    name = "chroma"

    def __init__(self, path: str | None = None, collection: str = "realestate_kb"):
        import chromadb
        self.client = chromadb.PersistentClient(path=path) if path else chromadb.EphemeralClient()
        self.collection_name = collection
        self.col = None
        self._by_id: dict[str, Chunk] = {}

    def reset(self):
        try:
            self.client.delete_collection(self.collection_name)
        except Exception:
            pass
        self.col = self.client.create_collection(self.collection_name, metadata={"hnsw:space": "cosine"})
        self._by_id = {}

    def add(self, chunks: list[Chunk], vectors: np.ndarray):
        for i in range(0, len(chunks), 256):
            part = chunks[i:i + 256]
            self.col.add(
                ids=[c.chunk_id for c in part],
                embeddings=vectors[i:i + 256].tolist(),
                documents=[c.text for c in part],
                metadatas=[{k: v for k, v in c.metadata.items() if v is not None} for c in part])
        self._by_id = {c.chunk_id: c for c in chunks}

    def query(self, vec: np.ndarray, k: int, where: dict | None = None):
        kwargs = {}
        if where:
            kwargs["where"] = ({"$and": [{a: b} for a, b in where.items()]} if len(where) > 1 else where)
        r = self.col.query(query_embeddings=[vec.tolist()], n_results=k, **kwargs)
        out = []
        for cid, dist in zip(r["ids"][0], r["distances"][0]):
            out.append((self._by_id[cid], 1.0 - float(dist)))  # cosine distance -> similarity
        return out


def make_store(backend: str, chroma_dir: str | None):
    if backend == "chroma":
        try:
            return ChromaStore(chroma_dir)
        except Exception as e:  # chromadb missing / broken -> graceful fallback
            print(f"[store] Chroma unavailable ({e}); falling back to NumPy store")
    return NumpyStore()
