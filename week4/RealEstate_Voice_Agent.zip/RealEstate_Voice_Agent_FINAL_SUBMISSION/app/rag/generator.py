"""Grounded answer generation.

Contract (anti-hallucination):
  1. The model may ONLY use the supplied context.
  2. If the context does not contain the answer it must say so (ABSTAIN).
  3. Every answer returns its sources so the agent (and our eval) can audit it.

Back-ends: extractive (offline, deterministic) | OpenAI | Anthropic.
"""
from __future__ import annotations

import re

from app.nlp.urdulish import expand_query, tokens
from app.rag.embeddings import _EN_STOP, _stem

ABSTAIN = ("Is baare mein mere paas verified information maujood nahi hai. "
           "Main aap ko hamare agent se confirm karwa deta hoon.")

GROUNDING_PROMPT = """You are the knowledge module of a Pakistani real-estate voice assistant.
Answer the caller's question using ONLY the CONTEXT below.
Rules: never invent prices, sizes, names, distances or amenities. If the context does not
contain the answer, reply exactly: NOT_IN_KB. Keep the answer to 1-3 short sentences,
factual, in English (a separate step converts it into spoken UrduLish).

CONTEXT:
{context}

QUESTION: {question}"""


_GEO = {"lahore", "karachi", "islamabad", "rawalpindi", "pindi", "dha", "bahria", "town", "phase", "gulberg",
        "johar", "clifton", "gulshan", "iqbal", "enclave", "f-11", "e-11", "f11", "e11", "pakistan", "sector"}
_FILLER = {"kahan", "where", "much", "tell", "give", "please", "kitna", "kitni", "batao", "bataen", "hai", "hain",
           "near", "nearby", "close", "around", "any", "available", "about", "there", "kaun", "kaunsa", "konsa",
           "property", "iske", "iska", "iski", "uske", "uska", "uski", "unka", "unki", "unke", "isme", "usme"}


def _content_tokens(text: str, drop_geo: bool = False) -> set[str]:
    out = set()
    for t in tokens(text):
        if t in _EN_STOP or len(t) < 2:
            continue
        if drop_geo and (t in _GEO or t in _FILLER):
            continue
        out.add(_stem(t))
    return out


def _sentence_units(text: str) -> list[tuple[str, set[str], str]]:
    """Split a chunk into (sentence, context_tokens). context = document title + section heading,
    so 'Delivered 18 projects.' under 'Track record' of 'Crescent Developers' is findable."""
    m = re.match(r"^\[([^\]]*)\]\s*", text)
    title = m.group(1) if m else ""
    body = text[m.end():] if m else text
    heading, units = "", []
    for line in body.splitlines():
        line = line.strip().lstrip("-").strip()
        if not line:
            continue
        if len(line.split()) <= 3 and not line.endswith("."):
            heading = line
            continue
        ctx = _content_tokens(title) | _content_tokens(heading)
        for sent in re.split(r"(?<=[.!?])\s+(?=[A-Z0-9'])", line):
            if sent.strip():
                units.append((sent.strip(), ctx, title))
    return units


def extractive_answer(question: str, contexts: list[str], min_overlap: float = 0.4,
                      idf: dict[str, float] | None = None) -> str | None:
    """Pick the context sentences that best cover the *topic* words of the question.
    Location words are ignored for scoring (every chunk repeats them) and rare words
    are weighted higher (IDF) so 'swimming pool' outweighs 'property'."""
    q = _content_tokens(expand_query(question), drop_geo=True)
    if not q:
        return None
    default = max(idf.values()) if idf else 1.0
    w = (lambda t: idf.get(t, default)) if idf else (lambda t: 1.0)
    total = sum(w(t) for t in q)
    scored = []
    for ci, ctx in enumerate(contexts):
        for s, ctok, title in _sentence_units(ctx):
            st = _content_tokens(s) | ctok
            if not st:
                continue
            ov = sum(w(t) for t in q & st) / total
            scored.append((ov - 0.02 * ci, title, s))
    scored.sort(key=lambda x: -x[0])
    if not scored or scored[0][0] < min_overlap:
        return None
    best, best_title = scored[0][0], scored[0][1]
    picked = []
    for ov, title, s in scored[:6]:
        # supporting sentences must come from the SAME document as the best one
        if title == best_title and ov >= max(min_overlap, best * 0.75) and s not in picked:
            picked.append(s)
    return " ".join(picked[:2])


def _llm_answer(question: str, contexts: list[str]) -> str | None:
    """Returns answer text, None for NOT_IN_KB, or '__extractive__' when no LLM is available/usable."""
    from app import llm
    if not llm.is_enabled():
        return "__extractive__"
    out = llm.generate("", GROUNDING_PROMPT.format(context="\n---\n".join(contexts), question=question),
                       temperature=0, max_tokens=250)
    if out is None:      # provider failure -> deterministic fallback
        return "__extractive__"
    return None if "NOT_IN_KB" in out else out


def generate_answer(question: str, contexts: list[str], idf: dict[str, float] | None = None) -> dict:
    """Returns {answer, abstained}."""
    out = _llm_answer(question, contexts)
    if out == "__extractive__":
        out = extractive_answer(question, contexts, idf=idf)
    if not out:
        return {"answer": ABSTAIN, "abstained": True}
    return {"answer": out, "abstained": False}
