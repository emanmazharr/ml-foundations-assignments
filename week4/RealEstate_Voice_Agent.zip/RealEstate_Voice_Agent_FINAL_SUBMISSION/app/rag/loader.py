"""Document loader: Markdown brochures / guides / policies + FAQ JSON -> Document objects."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Document:
    doc_id: str
    title: str
    text: str
    metadata: dict = field(default_factory=dict)


_PROP_RE = re.compile(r"Property ID (\d+) is a (\w+) for (\w+) in (.+?), (Lahore|Karachi|Islamabad)\.")


def load_documents(kb_dir: str | Path) -> list[Document]:
    kb = Path(kb_dir)
    docs: list[Document] = []
    for path in sorted(kb.rglob("*.md")):
        text = path.read_text(encoding="utf-8")
        title = (re.search(r"^#\s+(.+)$", text, re.M) or [None, path.stem])[1]
        doc_type = path.parent.name  # brochures | areas | developers | policies
        # Keep source identifiers portable so eval fixtures and persisted IDs match
        # on Windows as well as POSIX systems.
        meta: dict = {"doc_type": doc_type, "source": path.relative_to(kb).as_posix(), "title": title}
        m = _PROP_RE.search(text)
        if m:
            meta.update(property_id=int(m.group(1)), ptype=m.group(2), purpose=m.group(3),
                        area=m.group(4), city=m.group(5))
        elif doc_type == "areas":
            a = re.search(r"Area Guide: (.+?), (Lahore|Karachi|Islamabad)", text)
            if a:
                meta.update(area=a.group(1), city=a.group(2))
        docs.append(Document(doc_id=meta["source"], title=title, text=text, metadata=meta))

    faq_path = kb / "faqs" / "faqs.json"
    if faq_path.exists():
        for i, item in enumerate(json.loads(faq_path.read_text(encoding="utf-8"))):
            docs.append(Document(
                doc_id=f"faqs/faq_{i:02d}", title=item["question"],
                text=f"# FAQ: {item['question']}\n\n{item['answer']}",
                metadata={"doc_type": "faqs", "source": f"faqs/faq_{i:02d}", "title": item["question"]}))
    return docs
