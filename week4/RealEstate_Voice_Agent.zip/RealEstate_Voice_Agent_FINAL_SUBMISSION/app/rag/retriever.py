"""Semantic retriever: vector search + metadata-aware re-ranking."""
from __future__ import annotations

import re
from dataclasses import dataclass

from app.config import get_settings
from app.nlp.entities import parse_utterance
from app.rag.chunker import Chunk, chunk_documents
from app.rag.embeddings import Embedder, get_embedder
from app.rag.loader import load_documents
from app.rag.store import make_store


def _build_idf(chunks) -> dict[str, float]:
    import math
    from app.rag.generator import _content_tokens
    df: dict[str, int] = {}
    for c in chunks:
        for t in _content_tokens(c.text):
            df[t] = df.get(t, 0) + 1
    n = len(chunks)
    return {t: math.log((1 + n) / (1 + d)) + 1.0 for t, d in df.items()}


@dataclass
class Hit:
    chunk: Chunk
    score: float

    @property
    def source(self) -> str:
        return self.chunk.metadata.get("source", "")


class Retriever:
    def __init__(self, embedder: Embedder, store, top_k: int = 4):
        self.embedder, self.store, self.top_k = embedder, store, top_k
        self.idf: dict[str, float] = {}

    @classmethod
    def build(cls, kb_dir: str | None = None, chunk_size: int | None = None, overlap: int | None = None,
              backend: str | None = None, persist: bool = True) -> "Retriever":
        s = get_settings()
        docs = load_documents(kb_dir or s.kb_dir)
        chunks = chunk_documents(docs, chunk_size or s.rag_chunk_size, overlap if overlap is not None else s.rag_chunk_overlap)
        embedder = get_embedder().fit([c.text for c in chunks])
        store = make_store(backend or s.vector_backend, s.chroma_dir if persist else None)
        store.reset()
        store.add(chunks, embedder.embed_documents([c.text for c in chunks]))
        r = cls(embedder, store, s.rag_top_k)
        r.n_chunks, r.n_docs = len(chunks), len(docs)
        r.idf = _build_idf(chunks)
        return r

    def retrieve(self, query: str, k: int | None = None, where: dict | None = None) -> list[Hit]:
        k = k or self.top_k
        qv = self.embedder.embed_query(query)
        cands = self.store.query(qv, max(k * 4, 12), where)
        ent = parse_utterance(query)
        ql = query.lower()
        prior = {}                                   # doc-type priors from query intent
        if re.search(r"school|hospital|aspatal|taleem|doctor|area|locality|neighbou?rhood|kaisa area", ql):
            prior["areas"] = 0.12
        if re.search(r"developer|builder|track record|company kaisi|delivered", ql):
            prior["developers"] = 0.12
        if re.search(r"policy|process|document|commission|tax|loan|overseas|timing|deposit|kanal|marla|guarantee|refund|charge", ql):
            prior["faqs"] = 0.10
        rescored = []
        for chunk, sc in cands:
            md = chunk.metadata
            boost = prior.get(md.get("doc_type"), 0.0)
            if ent.property_id and md.get("property_id") == ent.property_id:
                boost += 0.5                       # explicit "property 10"
            if ent.city and md.get("city") == ent.city:
                boost += 0.05
            if ent.area and ent.area.lower() in str(md.get("area", "")).lower():
                boost += 0.08
            rescored.append(Hit(chunk, sc + boost))
        rescored.sort(key=lambda h: -h.score)
        return rescored[:k]
