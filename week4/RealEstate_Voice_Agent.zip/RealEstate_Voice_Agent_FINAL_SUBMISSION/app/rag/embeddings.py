"""Embedding back-ends.

* HashingEmbedder  - offline, deterministic, zero-cost (hashed uni+bi-gram TF-IDF).
                     Runs anywhere (CI, laptop, no API key). Query side is passed
                     through the UrduLish expander so Roman-Urdu queries still match.
* OpenAIEmbedder   - production option (text-embedding-3-small, multilingual).
Both return L2-normalised float32 matrices so cosine == dot product.
"""
from __future__ import annotations

import math
import re
from abc import ABC, abstractmethod

import numpy as np
from sklearn.feature_extraction.text import HashingVectorizer

from app.config import get_settings
from app.nlp.urdulish import _STOP, expand_query, normalise

_EN_STOP = _STOP | {"what", "which", "how", "does", "do", "have", "has", "there", "about", "tell", "me"}


def _stem(w: str) -> str:
    for suf in ("ings", "ing", "ies", "ers", "er", "ed", "es", "s"):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            return w[: -len(suf)] + ("y" if suf == "ies" else "")
    return w


def _analyzer(text: str) -> list[str]:
    toks = [_stem(t) for t in re.findall(r"[\w\u0600-\u06FF]+(?:[-.]\w+)*", normalise(text)) if t not in _EN_STOP]
    return toks + [f"{a}_{b}" for a, b in zip(toks, toks[1:])]


class Embedder(ABC):
    name: str

    def fit(self, texts: list[str]) -> "Embedder":
        return self

    @abstractmethod
    def embed_documents(self, texts: list[str]) -> np.ndarray: ...

    def embed_query(self, text: str) -> np.ndarray:
        return self.embed_documents([text])[0]


class HashingEmbedder(Embedder):
    name = "hashing-tfidf"

    def __init__(self, n_features: int = 2 ** 13):
        self.vec = HashingVectorizer(n_features=n_features, analyzer=_analyzer,
                                     alternate_sign=False, norm=None)
        self.idf: np.ndarray | None = None
        self.n_features = n_features

    def fit(self, texts):
        X = self.vec.transform(texts)
        df = np.asarray((X > 0).sum(axis=0)).ravel()
        self.idf = np.log((1 + len(texts)) / (1 + df)) + 1.0
        return self

    def _encode(self, texts):
        X = self.vec.transform(texts).toarray().astype(np.float32)
        X = np.log1p(X)  # sublinear tf
        if self.idf is not None:
            X *= self.idf.astype(np.float32)
        n = np.linalg.norm(X, axis=1, keepdims=True)
        n[n == 0] = 1
        return X / n

    def embed_documents(self, texts):
        return self._encode(texts)

    def embed_query(self, text):
        return self._encode([expand_query(text)])[0]


class OpenAIEmbedder(Embedder):
    name = "openai-text-embedding-3-small"

    def __init__(self, model: str = "text-embedding-3-small"):
        from openai import OpenAI  # lazy import
        self.client = OpenAI(api_key=get_settings().openai_api_key)
        self.model = model

    def embed_documents(self, texts):
        out = []
        for i in range(0, len(texts), 96):
            r = self.client.embeddings.create(model=self.model, input=texts[i:i + 96])
            out += [d.embedding for d in r.data]
        a = np.array(out, dtype=np.float32)
        return a / np.linalg.norm(a, axis=1, keepdims=True)


def get_embedder() -> Embedder:
    if get_settings().embedding_provider == "openai" and get_settings().openai_api_key:
        return OpenAIEmbedder()
    return HashingEmbedder()
