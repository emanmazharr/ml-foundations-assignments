"""Header-aware chunking with overlap.

Every chunk is prefixed with its document title so that a chunk such as
"Amenities: gym, pool" still carries WHICH property it belongs to -- the single
biggest retrieval-quality win for brochure-style data (see eval/chunk_eval.py).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from app.rag.loader import Document


@dataclass
class Chunk:
    chunk_id: str
    text: str
    metadata: dict = field(default_factory=dict)


def _pack(parts: list[str], size: int, sep: str) -> list[str]:
    out, cur = [], ""
    for p in parts:
        if cur and len(cur) + len(sep) + len(p) > size:
            out.append(cur); cur = p
        else:
            cur = f"{cur}{sep}{p}" if cur else p
    if cur:
        out.append(cur)
    return out


def _split_long(line: str, size: int) -> list[str]:
    """Sentence split -> comma split -> word split (guarantees every piece <= size)."""
    if len(line) <= size:
        return [line]
    pieces: list[str] = []
    for chunk in _pack(re.split(r"(?<=[.!?;])\s+", line), size, " "):
        if len(chunk) <= size:
            pieces.append(chunk); continue
        for sub in _pack(re.split(r"(?<=,)\s+", chunk), size, " "):
            if len(sub) <= size:
                pieces.append(sub)
            else:
                pieces += _pack(sub.split(), size, " ")
    return pieces


def chunk_document(doc: Document, chunk_size: int = 600, overlap: int = 100) -> list[Chunk]:
    prefix = f"[{doc.title}] "
    budget = max(80, chunk_size - len(prefix))
    lines: list[str] = []
    for raw in doc.text.splitlines():
        raw = raw.strip()
        if not raw or raw.startswith("# "):
            continue
        for piece in _split_long(raw.lstrip("# ").strip() if raw.startswith("##") else raw, budget):
            lines.append(piece)

    chunks: list[list[str]] = []
    cur: list[str] = []
    cur_len = 0
    for ln in lines:
        if cur and cur_len + len(ln) + 1 > budget:
            chunks.append(cur)
            # carry over trailing lines as overlap
            carry, tot = [], 0
            for prev in reversed(cur):
                if tot + len(prev) > overlap:
                    break
                carry.insert(0, prev); tot += len(prev)
            cur, cur_len = carry, tot
        cur.append(ln); cur_len += len(ln) + 1
    if cur:
        chunks.append(cur)

    out = []
    for i, c in enumerate(chunks):
        out.append(Chunk(chunk_id=f"{doc.doc_id}#{i}", text=prefix + "\n".join(c),
                         metadata={**doc.metadata, "chunk_index": i}))
    return out


def chunk_documents(docs: list[Document], chunk_size: int = 600, overlap: int = 100) -> list[Chunk]:
    return [c for d in docs for c in chunk_document(d, chunk_size, overlap)]
