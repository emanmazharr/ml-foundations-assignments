"""Small fail-closed key guards for classroom and provider-backed API routes."""
from __future__ import annotations

import secrets

from fastapi import Header, HTTPException

from app.config import get_settings


def require_demo_access(x_demo_key: str | None = Header(default=None)) -> None:
    """Keep local teaching use simple; require a separate key outside development."""
    settings = get_settings()
    if not settings.demo_api_key:
        if settings.app_env == "development":
            return
        raise HTTPException(503, "Demo API is disabled until DEMO_API_KEY is configured.")
    if not x_demo_key or not secrets.compare_digest(x_demo_key, settings.demo_api_key):
        raise HTTPException(401, "Valid X-Demo-Key header required.")


def require_admin(x_admin_key: str | None = Header(default=None)) -> None:
    """Fail closed for admin operations in non-development environments."""
    settings = get_settings()
    if not settings.admin_api_key:
        if settings.app_env == "development":
            return
        raise HTTPException(503, "Admin actions are disabled until ADMIN_API_KEY is configured.")
    if not x_admin_key or not secrets.compare_digest(x_admin_key, settings.admin_api_key):
        raise HTTPException(401, "Valid X-Admin-Key header required.")
