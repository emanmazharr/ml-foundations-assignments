"""Graph nodes (Day 5 Task 2/3/4/5).

Every node:  reads AgentState  ->  returns a partial-state dict  (and a `_detail` dict for the trace).
`traced()` wraps each node to (1) time it, (2) log the transition to the DB + state trace,
(3) catch crashes and fall back to a safe hand-off, so a bug can never kill a live call.
"""
from __future__ import annotations

import dataclasses
import functools
import logging
import re
import time
from datetime import datetime

from app import db, engine, llm, persona, timeutil
from app.agent.state import AgentState
from app.db import pkr_words
from app.guardrails import screen
from app.nlp.datetime_parse import parse_when
from app.nlp.entities import parse_utterance
from app.nlp.slots import extract_name, extract_phone, is_affirmative, is_negative, looks_like_bare_name
from app.persona import fmt, pick
from app.recommender import Profile, recommend
from app.services import appointments as ap
from app.services import crm

log = logging.getLogger("agent")
START_MARKER = "__call_started__"
SILENCE_MARKER = "__silence__"


# --------------------------------------------------------------------------- #
# tracing decorator
# --------------------------------------------------------------------------- #
def traced(name: str):
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(state: AgentState) -> dict:
            t0 = time.perf_counter()
            try:
                out = fn(state) or {}
            except Exception as e:                                  # never crash the call
                log.exception("node %s failed", name)
                out = {"response": fmt(persona.ERROR_FALLBACK, state), "escalated": True,
                       "flow": None, "pending": None, "notify": None,
                       "_detail": {"error": f"{type(e).__name__}: {e}"}}
                if state.get("caller_phone"):
                    crm.add_followup(state["caller_phone"], timeutil.iso(timeutil.now()),
                                     f"URGENT call-back: agent error in node '{name}'")
            ms = (time.perf_counter() - t0) * 1000
            detail = out.pop("_detail", {})
            entry = {"node": name, "turn": state.get("turn", 0), "ms": round(ms, 2), "detail": detail}
            if state.get("call_id"):
                try:
                    crm.log_node_event(state["call_id"], state.get("turn", 0), name, ms, detail)
                except Exception:
                    log.warning("could not persist node event")
            out["trace"] = [entry]
            return out
        return wrapper
    return deco


# --------------------------------------------------------------------------- #
# small helpers
# --------------------------------------------------------------------------- #
def _prof(state) -> Profile:
    return Profile(**(state.get("profile") or {}))


def _pd(p: Profile) -> dict:
    return dataclasses.asdict(p)


def _hon(state) -> str:
    return state.get("honorific", "sir")


def F(template: str, state, **kw) -> str:
    return fmt(template, state, **kw)


TYPE_WORD = {"house": "ghar", "apartment": "apartment", "plot": "plot", "shop": "shop", "office": "office"}


def speak_price(p: dict) -> str:
    return f"{pkr_words(p['price_pkr'])} rupay" + (" mahana" if p["purpose"] == "rent" else "")


def speak_size(p: dict) -> str:
    v = int(p["size_value"]) if float(p["size_value"]).is_integer() else p["size_value"]
    return {"marla": f"{v} marla", "kanal": f"{v} kanal", "sqft": f"{v} sq ft", "sq_yd": f"{v} gaz"}[p["size_unit"]]


def describe(p: dict) -> str:
    beds = f", {p['bedrooms']} kamray" if p["bedrooms"] else ""
    return f"Property {p['id']}: {p['area']} {p['city']} mein {speak_size(p)} ka {TYPE_WORD[p['ptype']]}{beds}, {speak_price(p)}"


def _flow_when(flow: dict) -> datetime | None:
    if flow.get("date") and flow.get("time"):
        d, t = flow["date"], flow["time"]
        return datetime.fromisoformat(f"{d}T{t}").replace(tzinfo=timeutil.tz())
    return None


def _spoken_alts(alts: list[str]) -> str:
    return ", ".join(timeutil.spoken_when(timeutil.from_iso(a)) for a in alts)


REASON_TEXT = {
    "past": "Woh waqt to guzar chuka hai.",
    "too_soon": "Visit ke liye kam az kam 3 ghante pehle batana hota hai.",
    "too_far": "Hum ziyada se ziyada 30 din aage tak booking kar sakte hain.",
    "sunday": "Itwar ko visits nahi hoti.",
    "outside_hours": "Visits subah 10 se shaam 7 baje tak hoti hain, aakhri slot 6:30 ka hota hai.",
    "misaligned": "Slot hamesha ghante ya aadhe ghante par shuru hota hai, jaise 5:00 ya 5:30.",
    "conflict": "Us waqt hamare agent ki doosri visit pehle se hai.",
}
ORD = {"pehli": 0, "pehla": 0, "first": 0, "1st": 0, "ek number": 0, "dusri": 1, "doosri": 1, "dusra": 1, "second": 1, "2nd": 1,
       "teesri": 2, "teesra": 2, "third": 2, "3rd": 2}


def _ordinal(text: str) -> int | None:
    for k, v in ORD.items():
        if re.search(rf"\b{k}\b", text):
            return v
    return None


# --------------------------------------------------------------------------- #
# 1. load_context  (entry)
# --------------------------------------------------------------------------- #
@traced("load_context")
def load_context(state: AgentState) -> dict:
    turn = state.get("turn", 0) + 1
    raw = (state.get("user_input") or "").strip()
    out: dict = {"turn": turn, "cleaned_input": raw, "intent": None, "entities": {}, "guard": {}, "objection": None,
                 "notify": None, "response": "", "draft": ""}
    if turn == 1:
        cust = crm.get_customer(state["caller_phone"]) if state.get("caller_phone") else None
        out["customer"] = cust
        out["honorific"] = "madam" if cust and cust.get("gender_hint") == "female" else "sir"
        prefs = (cust or {}).get("preferences", {})
        base = {k: v for k, v in prefs.items() if k in Profile.__dataclass_fields__}
        out["profile"] = _pd(Profile(**base)) if base else state.get("profile") or _pd(Profile())
        out.update(last_recommended=[], focus_property_id=None, flow=None, pending=None, offered_visit=False,
                   abuse_count=0, silence_count=0, unknown_count=0, escalated=False, ended=False, appointment=None)
    if raw and raw not in (START_MARKER, SILENCE_MARKER):
        out["messages"] = [{"role": "user", "content": raw}]
        crm.log_message(state["call_id"], "user", raw)
        if re.search(r"\b(rahi hoon|rahi hun|chahti hoon|chahti hun|karna chahti|madam|mam|ma'am)\b", raw.lower()):
            out["honorific"] = "madam"
            if state.get("caller_phone"):
                crm.upsert_customer(state["caller_phone"], gender_hint="female")
    out["_detail"] = {"input": raw[:80], "returning_customer": bool(out.get("customer") or state.get("customer"))}
    return out


# --------------------------------------------------------------------------- #
# 2. guard
# --------------------------------------------------------------------------- #
@traced("guard")
def guard(state: AgentState) -> dict:
    raw = state.get("cleaned_input", "")
    if raw in (START_MARKER, SILENCE_MARKER) or not raw:
        return {"guard": {"category": None}, "_detail": {"category": None}}
    g = screen(raw)
    return {"guard": g, "cleaned_input": g["text"] if g["category"] else raw,
            "_detail": {"category": g["category"], "matched": g["matched"]}}


def route_after_guard(state: AgentState) -> str:
    return "guardrail" if (state.get("guard") or {}).get("category") else "intent_detection"


@traced("guardrail")
def guardrail_node(state: AgentState) -> dict:
    cat = state["guard"]["category"]
    out: dict = {"intent": f"blocked:{cat}"}
    if cat in ("injection", "authority_claim"):
        out["response"] = F(persona.INJECTION, state)
    elif cat == "exfiltration":
        out["response"] = F(persona.EXFIL, state)
    elif cat == "fake_booking":
        out["response"] = F(persona.FAKE, state)
    elif cat == "offtopic":
        out["response"] = F(persona.OFFTOPIC, state)
    elif cat == "abuse":
        n = state.get("abuse_count", 0) + 1
        out["abuse_count"] = n
        if n >= 2:
            out.update(response=F(persona.ABUSE2, state), escalated=True, ended=True, outcome="escalated")
            if state.get("caller_phone"):
                crm.add_followup(state["caller_phone"], timeutil.iso(timeutil.now()), "Callback: caller was abusive; senior agent to handle")
        else:
            out["response"] = F(persona.ABUSE1, state)
    out["_detail"] = {"category": cat, "action": "refused" if cat != "offtopic" else "redirected"}
    return out


# --------------------------------------------------------------------------- #
# 3. intent detection
# --------------------------------------------------------------------------- #
_VISIT = r"\b(visit|dekhna|dekhne|dikha\w*|appointment|meeting|mulaqat|slot|viewing|site)\b"
_BOOK_ACT = r"(rakh|book|schedule|arrange|lagwa|karna|karni|karwa|dekhna|dekhne|dikha|chahta|chahti|chahiye|want|would like|like to|set up|fix|le lo|lena|aa sak|aana|aaun|aa jaun|milna)"
_VISIT_FAQ = r"(timing|charges?|free|fee|kitne|kitna|policy|hours|kab tak|kab se|hota hai|kaise hota|process|notice|kya visit)"
_GOODBYE = r"(allah hafiz|khuda hafiz|bye|goodbye|shukriya bas|bas itna hi|bas yehi|that'?s all|thats all|phir baat|baad mein call|rakhta hoon|rakhti hoon|thank you bye|chalta hoon)"
_THANKS = r"^(ok|okay|acha|achha|theek hai|thik hai)?\s*(shukriya|thanks|thank you|thankyou|meherbani|jazak)"
_ABORT = r"(rehne do|reh ne do|chor do|chhor do|never ?mind|forget it|nahi chahiye|mat karo|koi baat nahi|cancel it|ruk jao|abhi nahi)"
_HUMAN = r"(human|insaan|real person|agent se baat|kisi se baat|manager|senior|supervisor|call back|callback|representative)"
_SELLER = r"(bechna|bechni|becho|bech (do|dein|dena)|apni property|meri property|sell my|want to sell|list (my|kar)|rent out|kiraye par (dena|dene))"
_GREET = r"^(assalam|salam|hello|hi|hey|aoa|good (morning|evening|afternoon))\b"
_PRONOUN = r"\b(is|iski|iska|iske|isme|is mein|us|uski|uska|uske|usme|us mein|yeh|ye|woh|wo|this|that|it|its)\b"
_PROP_FACT = r"(price|qeemat|keemat|kitn[ai]|size|marla|agent|available|plan|qist|install|amenit|pool|gym|kamre|kamray|developer|school|hospital|nearby|park|parking|status|token|down ?payment|rent|kiraya)"


def detect_intent(state: AgentState, text: str, ent) -> tuple[str, str | None]:
    t = text.lower()
    flow, pending = state.get("flow"), state.get("pending")
    when = parse_when(t, timeutil.now())
    has_dt = bool(when.date or when.time)

    if text == START_MARKER:
        return "greeting", None
    if text == SILENCE_MARKER or not text:
        return "silence", None
    # ---- awaiting a yes/no ----
    if pending:
        if re.search(_ABORT, t):
            return "flow_abort", None
        if is_affirmative(t) and not has_dt:
            return "confirm_yes", None
        if is_negative(t) and not has_dt:
            return "confirm_no", None
        if has_dt or extract_name(text) or extract_phone(text):
            return "flow_continue", None          # caller amended the details
    if flow and re.search(_ABORT, t):
        return "flow_abort", None
    if re.search(_GOODBYE, t):
        return "goodbye", None
    if re.search(_HUMAN, t):
        return "human", None
    # ---- explicit workflow intents ----
    if "reschedule" in ent.flags:
        return "reschedule", None
    if "cancel" in ent.flags:
        return "cancel", None
    if re.search(_VISIT, t) and (re.search(_BOOK_ACT, t) or has_dt) and not re.search(_VISIT_FAQ, t):
        return "book_visit", None
    # ---- active multi-turn flow: slots being supplied ----
    if flow:
        if has_dt or extract_name(text) or extract_phone(text) or _ordinal(t) is not None or ent.property_id \
                or (len(t.split()) <= 4 and not re.search(_PROP_FACT, t)):
            return "flow_continue", None
    # ---- objections ----
    for name, cfg in persona.OBJECTIONS.items():
        if re.search(cfg["pattern"], t):
            return "objection", name
    # ---- bare "haan" after the agent offered a visit ----
    if state.get("offered_visit") and is_affirmative(t) and len(t.split()) <= 5:
        return "book_visit", None
    if state.get("offered_visit") and has_dt and re.search(r"(aa sak|aaun|aa jaun|theek|chalega|rakh|ok)", t):
        return "book_visit", None
    if re.search(_SELLER, t):
        return "seller", None
    # ---- ordinal pick from recommended list ----
    if _ordinal(t) is not None and state.get("last_recommended") and not ent.property_id:
        return "select_property", None
    # ---- knowledge & search ----
    r = engine.route(text, ent)
    if r == "sql_search":
        return "property_search", None
    has_filter = any([ent.budget_max, ent.budget_min, ent.bedrooms, ent.ptype, ent.category, ent.investment,
                      ent.wants_cheaper, ent.wants_costlier])
    facility = re.search(engine._FACILITY, t)
    if (ent.wants_cheaper or ent.wants_costlier) and state.get("focus_property_id"):
        return "property_search", None
    if has_filter and (ent.area or ent.city or ent.budget_max or ent.ptype or ent.investment) and not facility \
            and not ent.property_id and not re.search(_PROP_FACT, t):
        return "property_search", None
    # ---- bare "options in <area>?" search, relying on budget/etc already remembered from earlier turns ----
    if (ent.area or ent.city) and not facility and not ent.property_id \
            and re.search(engine._SEARCH_VERB, t) and not re.search(_PROP_FACT, t):
        return "property_search", None
    if ent.property_id or facility or re.search(_PROP_FACT, t) or re.search(r"\?|kya|kaun|kitn|kaise|kab|how|what|which|does|is there", t):
        return "property_question", None
    if re.search(_GREET, t):
        return "smalltalk", None
    if re.search(_THANKS, t):
        return "thanks", None
    if has_filter or ent.area or ent.city or ent.purpose:
        return "property_search", None
    return "unknown", None


@traced("intent_detection")
def intent_detection(state: AgentState) -> dict:
    text = state.get("cleaned_input", "")
    ent = parse_utterance(text) if text not in (START_MARKER, SILENCE_MARKER) else parse_utterance("")
    intent, objection = detect_intent(state, text, ent)
    method = "rules"
    if intent == "unknown" and llm.is_enabled():           # LLM fallback for genuinely ambiguous input
        j = llm.generate(
            "Classify the caller utterance of a real-estate phone call. Reply with ONE label only from: "
            "property_search, property_question, book_visit, reschedule, cancel, objection, human, goodbye, offtopic, unknown.",
            text, temperature=0, max_tokens=8)
        if j and j.strip().lower().split()[0].strip(".,'\"") in {"property_search", "property_question", "book_visit",
                                                              "reschedule", "cancel", "objection", "human", "goodbye"}:
            intent, method = j.strip().lower().split()[0].strip(".,'\""), "llm"
            if intent == "objection":
                for name, cfg in persona.OBJECTIONS.items():
                    if re.search(cfg["pattern"], text.lower()):
                        objection = name
                objection = objection or "price"
    ed = ent.to_dict()
    out = {"intent": intent, "entities": ed, "objection": objection,
           "_detail": {"intent": intent, "method": method, "entities": ed, "objection": objection,
                       "pending": state.get("pending"), "flow": (state.get("flow") or {}).get("type")}}
    if state.get("offered_visit") and intent not in ("book_visit", "flow_continue", "confirm_yes"):
        out["offered_visit"] = False
    return out


def route_after_intent(state: AgentState) -> str:
    it = state["intent"]
    flow_type = (state.get("flow") or {}).get("type")
    if it in ("confirm_yes", "confirm_no", "flow_continue"):
        return {"book": "booking", "reschedule": "rescheduling", "cancel": "cancellation"}.get(flow_type, "clarify")
    return {
        "greeting": "greeting", "smalltalk": "greeting", "property_search": "recommendation",
        "property_question": "rag", "select_property": "rag", "book_visit": "booking",
        "reschedule": "rescheduling", "cancel": "cancellation", "objection": "objection",
        "human": "escalate", "seller": "escalate", "goodbye": "goodbye", "thanks": "thanks",
        "silence": "silence", "flow_abort": "abort", "unknown": "clarify",
    }.get(it, "clarify")


# --------------------------------------------------------------------------- #
# 4. simple conversational nodes
# --------------------------------------------------------------------------- #
@traced("greeting")
def greeting_node(state: AgentState) -> dict:
    cust = state.get("customer")
    if state.get("turn", 1) > 1:
        return {"response": F(pick(persona.ACK, state["turn"]), state) + F(" Boliye {hon}, main aap ki kya madad kar sakta hoon?", state),
                "_detail": {"kind": "smalltalk"}}
    if cust and cust.get("name"):
        prefs, mem = cust.get("preferences", {}), ""
        bits = [prefs.get("area") or prefs.get("city"), TYPE_WORD.get(prefs.get("ptype") or "", "")]
        if prefs.get("area") or prefs.get("city"):
            mem = f"Pichli baar aap {' '.join(b for b in bits if b)} dekh rahe the. "
        up = ap.upcoming_for_phone(state["caller_phone"])
        if up:
            mem += f"Aap ki {timeutil.spoken_when(timeutil.from_iso(up[0]['start_ts']))} ki visit bhi scheduled hai. "
        return {"response": F(persona.GREETING_RETURNING, state, name=cust["name"], memory=mem),
                "_detail": {"kind": "returning", "known_prefs": list(prefs)}}
    return {"response": F(persona.GREETING, state), "_detail": {"kind": "new"}}


@traced("thanks")
def thanks_node(state: AgentState) -> dict:
    return {"response": F("Aap ka bohat shukriya {hon}! Kya main aur kisi cheez mein madad kar sakta hoon?", state)}


@traced("silence")
def silence_node(state: AgentState) -> dict:
    n = state.get("silence_count", 0) + 1
    if n >= 2:
        return {"silence_count": n, "response": F(persona.SILENCE2, state), "ended": True, "outcome": "dropped",
                "_detail": {"silence_count": n, "action": "end_call"}}
    return {"silence_count": n, "response": F(persona.SILENCE1, state), "_detail": {"silence_count": n}}


@traced("clarify")
def clarify_node(state: AgentState) -> dict:
    n = state.get("unknown_count", 0) + 1
    if n >= 3:
        return {"unknown_count": 0, "intent": "human", "response": F(persona.HANDOFF, state), "escalated": True,
                "outcome": "escalated", "_detail": {"escalated_after_unclear": n}}
    q = ("Kya aap property kharidna chahte hain, kiraye par lena chahte hain, ya investment ke liye dekh rahe hain?"
         if n == 1 else pick(persona.SORRY_UNCLEAR, state.get("turn", 0)))
    return {"unknown_count": n, "response": F(q, state), "_detail": {"unknown_count": n}}


@traced("goodbye")
def goodbye_node(state: AgentState) -> dict:
    booked = bool(state.get("appointment") and state["appointment"].get("status") in ("booked", "rescheduled"))
    extra = ""
    if booked:
        extra = f"Aap ki visit {timeutil.spoken_when(timeutil.from_iso(state['appointment']['start_ts']))} ki confirm hai. "
    return {"response": extra + F(pick(persona.CLOSE, state.get("turn", 0)), state), "ended": True,
            "outcome": state.get("outcome") or ("booked" if booked else "info"), "_detail": {"booked": booked}}


@traced("abort")
def abort_node(state: AgentState) -> dict:
    return {"flow": None, "pending": None,
            "response": F("Koi baat nahi {hon}, main ne yeh cancel kar diya. Aur koi madad chahiye to bataiye.", state),
            "_detail": {"cleared_flow": (state.get("flow") or {}).get("type")}}


@traced("escalate")
def escalate_node(state: AgentState) -> dict:
    phone = state.get("caller_phone")
    reason = "Seller lead - wants to list a property: " + state.get("cleaned_input", "")[:150] if state["intent"] == "seller" \
        else "Caller asked for a human agent"
    if phone:
        crm.add_followup(phone, timeutil.iso(timeutil.now()), reason)
        crm.bump_lead_score(phone, 15)
    resp = F(persona.HANDOFF, state)
    if state["intent"] == "seller":
        resp = F("Zaroor {hon}, aap ki property list karne mein khushi hogi. ", state) + persona.HANDOFF.split(". ", 1)[-1].replace("Ji bilkul {hon}. ", "")
        resp = F("Zaroor {hon}, aap ki property list karne mein hamein khushi hogi! Main aap ka number note kar leta hoon, "
                 "hamara senior agent Monday se Saturday, subah 10 se shaam 7 baje ke darmiyan aap ko call karega.", state)
    return {"response": resp, "escalated": True, "outcome": "escalated", "_detail": {"reason": reason[:60], "crm_followup": bool(phone)}}


# --------------------------------------------------------------------------- #
# 5. knowledge (RAG / SQL)
# --------------------------------------------------------------------------- #
def _followup_offer(state) -> str:
    return F(" Kya main iski visit ka time dekh loon?", state)


@traced("rag")
def rag_node(state: AgentState) -> dict:
    text, ent = state["cleaned_input"], state.get("entities", {})
    focus = ent.get("property_id") or state.get("focus_property_id")
    # "select the second one" from the last recommendation list
    if state["intent"] == "select_property":
        idx = _ordinal(text.lower())
        recs = state.get("last_recommended") or []
        if idx is None or idx >= len(recs):
            return {"response": F("Maaf kijiye {hon}, kaunsi property? Property number bata dein.", state), "_detail": {"error": "bad_ordinal"}}
        p = db.get_property(recs[idx])
        av = db.check_availability(p["id"])
        if not av["available"]:
            return {"response": F("Maaf kijiye {hon}, woh property ab available nahi rahi.", state), "_detail": {"availability": av}}
        amen = ", ".join(p["amenities"][:4])
        return {"focus_property_id": p["id"], "offered_visit": True, "tool_outputs": [{"tool": "get_property", "id": p["id"]}],
                "response": f"Ji {_hon(state)}, {describe(p)}. Isme {amen} jaisi sahulatein hain, developer {p['developer']} hai." + _followup_offer(state),
                "_detail": {"property_id": p["id"]}}
    q = text
    if not ent.get("property_id") and state.get("focus_property_id") and re.search(_PRONOUN, text.lower()) and re.search(_PROP_FACT, text.lower()):
        q = f"{text} property {state['focus_property_id']}"       # resolve "iski price" -> focused property
    res = engine.ask(q, _prof(state))
    out: dict = {"tool_outputs": [{"tool": "knowledge", "route": res["route"], "sources": res["sources"][:3], "abstained": res["abstained"]}],
                 "_detail": {"route": res["route"], "sources": res["sources"][:3], "abstained": res["abstained"], "resolved_query": q}}
    if ent.get("property_id") and db.get_property(ent["property_id"]):
        out["focus_property_id"] = ent["property_id"]
    if res["abstained"]:
        out["response"] = res["answer"]
        out["offered_visit"] = False
        return out
    ans = res["answer"]
    if res["route"] == "sql_search":                       # a search question routed through the knowledge engine
        recs = (res.get("recommendation") or {}).get("matches", [])
        out["last_recommended"] = [m["property"]["id"] for m in recs]
        if recs:
            out["focus_property_id"] = recs[0]["property"]["id"]
    out["response"] = f"{pick(persona.ACK, state.get('turn', 0)).format(hon=_hon(state))} {ans}"
    if out.get("focus_property_id") or state.get("focus_property_id"):
        out["response"] += _followup_offer(state)
        out["offered_visit"] = True
    return out


# --------------------------------------------------------------------------- #
# 6. recommendation
# --------------------------------------------------------------------------- #
@traced("recommendation")
def recommend_node(state: AgentState) -> dict:
    ent_d = state.get("entities", {})
    from app.nlp.entities import Entities
    ent = Entities(**{k: v for k, v in ent_d.items() if k in Entities.__dataclass_fields__})
    prof = Profile.from_entities(ent, _prof(state))
    focus = db.get_property(state["focus_property_id"]) if state.get("focus_property_id") else None
    if ent.wants_cheaper and focus:
        prof.cheaper_than = focus["price_pkr"]; prof.ref_city = focus["city"]
    elif ent.wants_costlier and focus:
        prof.budget_min, prof.budget_max, prof.ref_city = focus["price_pkr"] * 1.01, None, focus["city"]
        prof.cheaper_than = None
    prof.exclude_ids = list(state.get("last_recommended") or []) if (ent.wants_cheaper or ent.wants_costlier) else []
    out: dict = {"profile": _pd(prof)}
    phone = state.get("caller_phone")
    if phone:
        crm.save_preferences(phone, {k: v for k, v in _pd(prof).items() if k in ("budget_max", "city", "area", "bedrooms", "purpose", "ptype", "investment")})

    if not any([prof.budget_max, prof.city, prof.area, prof.ptype, prof.category]):       # nothing to search with: ASK, don't guess
        out.update(response=F("Zaroor {hon}! Aap kis shehar aur area mein, aur kitne budget mein property dekh rahe hain?", state),
                   _detail={"action": "ask_requirements"})
        return out
    res = recommend(prof, limit=2)
    # Day-5 validation: never present an unavailable property, even if a bug upstream returned one
    matches = [m for m in res["matches"] if db.check_availability(m["property"]["id"])["available"]]
    out["tool_outputs"] = [{"tool": "recommend", "profile": _pd(prof), "n": len(matches), "relaxed": res.get("relaxed")}]
    d = {"profile": {k: v for k, v in _pd(prof).items() if v not in (None, [], False)}, "n_matches": len(matches),
         "relaxed": res.get("relaxed"), "needs_clarification": res.get("needs_clarification")}
    if res.get("needs_clarification") == "city" and matches:
        cities = " ya ".join(res["candidate_cities"])
        out.update(response=F("Ji {hon}, {area} kai shehron mein hai. Aap ka shehar kaunsa hai, {c}?", state, area=prof.area, c=cities),
                   _detail={**d, "action": "ask_city"})
        return out
    if not matches:
        what = "sasti" if prof.cheaper_than else "in requirements ke mutabiq"
        out.update(response=F("Maaf kijiye {hon}, filhal {w} koi available property nahi hai. Agar aap budget ya area thora flexible rakhen to main aur options dekh sakta hoon. Kya kehte hain?", state, w=what),
                   _detail={**d, "action": "no_match"})
        return out
    top = matches[0]["property"]
    prof.remember_choice(top)
    out.update(profile=_pd(prof), last_recommended=[m["property"]["id"] for m in matches], focus_property_id=top["id"], offered_visit=True)
    top_reasons = matches[0]["reasons"]
    reason_text = f" {top_reasons[0].split(' - ', 1)[-1].capitalize()}." if top_reasons else ""
    parts = [f"Ji {_hon(state)}, " + describe(top) + reason_text]
    if len(matches) > 1:
        parts.append(f"Doosra option: {describe(matches[1]['property'])}.")
    note = ""
    if res.get("relaxed"):
        note = {"same city, other areas": "Aap ke area mein exact match nahi mila, is liye aas paas ke areas dekhe hain. ",
                "budget stretched by 15%": "Exact budget mein nahi mila, is liye budget se thora upar dekha hai. ",
                "fewer bedrooms required": "Itne kamron ka exact option nahi mila, is liye kam kamron wale bhi dekhe hain. "}.get(res["relaxed"], "")
    out["response"] = note + " ".join(parts) + F(" Kis ki tafseel chahenge, ya main visit ka time dekh loon?", state)
    out["_detail"] = {**d, "top": top["id"], "ids": out["last_recommended"], "score": matches[0]["score"]}
    return out


# --------------------------------------------------------------------------- #
# 7. objection handling
# --------------------------------------------------------------------------- #
@traced("objection")
def objection_node(state: AgentState) -> dict:
    kind = state.get("objection") or "price"
    cfg = persona.OBJECTIONS[kind]
    focus = db.get_property(state["focus_property_id"]) if state.get("focus_property_id") else None
    fact, src = "", "faq"
    if kind == "price":
        if focus and focus["purpose"] == "sale":
            plans = db.get_payment_plans(focus["id"])
            if plans:
                pl = plans[0]
                fact = (f"Property {focus['id']} par {pl['down_payment_pct']:g} percent down payment ke baad {pl['installments']} mahine ki qist "
                        f"hai, taqreeban {pkr_words(pl['monthly_installment_pkr'])} rupay mahana. Qeemat par baat-cheet agent visit par owner ya developer se karta hai, "
                        f"main koi discount promise nahi kar sakta.")
                src = "sql:payment_plans"
        if not fact:
            fact = "Hamare paas mukhtalif budgets mein options hain, aur zyada tar properties par qist ka plan bhi hai."
    elif kind == "location" and focus:
        fac = db.nearby_facilities(focus["area_id"])
        bits = []
        if fac["schools"]:
            s = fac["schools"][0]; bits.append(f"{s['name']} sirf {s['distance_km']} km par")
        if fac["hospitals"]:
            h = fac["hospitals"][0]; bits.append(f"{h['name']} {h['distance_km']} km par")
        fact = f"{focus['area']} mein " + " aur ".join(bits) + " hai." if bits else ""
        src = "sql:schools+hospitals"
    elif kind == "builder" and focus:
        with db.conn() as c:
            from sqlalchemy import text as T
            d = c.execute(T("SELECT * FROM developers WHERE id=:i"), {"i": focus["developer_id"]}).first()
        if d:
            fact = (f"Is property ke developer {d.name} ne {d.established} se ab tak {d.projects_delivered} projects deliver kiye hain, "
                    f"aur unka status {d.approvals} hai.")
            src = "sql:developers"
    elif kind == "investment" and focus and focus.get("rental_yield_pct"):
        fact = (f"Company ke indicative estimate ke mutabiq is property ka rental yield taqreeban {focus['rental_yield_pct']} percent saalana hai, "
                f"lekin yeh sirf research estimate hai, guarantee nahi.")
        src = "sql:properties"
    if not fact:                                             # ground the answer in the KB instead of improvising
        q = {"trust": "Is the legal title verified before listing?", "investment": "Is real estate investment guaranteed profit?",
             "maintenance": "What maintenance charges apply to apartments?", "builder": "What happens if construction is delayed?",
             "location": "Which cities do you cover?", "price": "Do you offer installment plans?"}[kind]
        r = engine.ask(q)
        fact = r["answer"] if not r["abstained"] else ""
        src = ",".join(r["sources"][:1]) or "faq"
    resp = f"{F(cfg['open'], state)} {fact} {F(cfg['close'], state)}".replace("  ", " ")
    return {"response": resp, "offered_visit": True, "tool_outputs": [{"tool": "objection", "type": kind, "source": src}],
            "_detail": {"objection": kind, "source": src, "focus": focus["id"] if focus else None}}


# --------------------------------------------------------------------------- #
# 8. booking / rescheduling / cancellation  (multi-turn slot filling)
# --------------------------------------------------------------------------- #
def _merge_slots(flow: dict, text: str, state) -> dict:
    w = parse_when(text.lower(), timeutil.now())
    if w.date:
        flow["date"] = w.date.isoformat()
    if w.time:
        flow["time"] = w.time.strftime("%H:%M")
    nm = extract_name(text)
    if nm:
        flow["name"] = nm
    ph = extract_phone(text)
    if ph:
        flow["phone"] = ph
    if not flow.get("name") and not nm and flow.get("date") and flow.get("time"):
        bare = looks_like_bare_name(text)
        if bare:
            flow["name"] = bare
    return flow


def _alternatives_msg(state, reason: str, alts: list[str], agent_note: str = "") -> str:
    base = REASON_TEXT.get(reason, "Yeh slot available nahi hai.")
    if alts:
        return F(f"Maaf kijiye {{hon}}, {base} In mein se koi theek rahega: {_spoken_alts(alts)}?", state)
    return F(f"Maaf kijiye {{hon}}, {base} Kisi aur din ka time bata dein?", state)


@traced("booking")
def booking_node(state: AgentState) -> dict:
    text, ent = state["cleaned_input"], state.get("entities", {})
    intent = state["intent"]
    flow = dict(state.get("flow") or {})
    if flow.get("type") != "book":
        flow = {"type": "book"}
    d: dict = {"intent": intent}

    # ------- final confirmation -------
    if state.get("pending") == "confirm_booking":
        if intent == "confirm_no":
            flow.pop("date", None); flow.pop("time", None)
            return {"flow": flow, "pending": None, "response": F("Koi baat nahi {hon}. Kaunsa din aur time aap ke liye theek rahega?", state),
                    "_detail": {**d, "action": "declined_confirmation"}}
        if intent == "confirm_yes":
            start = _flow_when(flow)
            phone = flow.get("phone") or state.get("caller_phone")
            res = ap.book(customer_name=flow["name"], customer_phone=phone, property_id=flow["property_id"], start=start,
                          call_id=state["call_id"], requirements=_pd(_prof(state)), notes="Booked by AI voice agent", notify=False)
            d["result"] = {k: res.get(k) for k in ("ok", "reason")}
            if res["ok"]:
                a = res["appointment"]
                return {"appointment": a, "flow": None, "pending": None, "offered_visit": False, "outcome": "booked",
                        "notify": {"kind": "booked", "appt_id": a["id"]},
                        "tool_outputs": [{"tool": "book_appointment", "ok": True, "appointment_id": a["id"], "sync": a["sync_status"]}],
                        "response": F("Mubarak ho {hon}! Aap ki visit {when} ke liye book ho gayi hai, hamare agent {agent} aap ko milenge. [[EMAIL_NOTE]] Koi aur madad chahiye?", state,
                                      when=timeutil.spoken_when(timeutil.from_iso(a["start_ts"])), agent=res["agent"]),
                        "_detail": {**d, "appointment_id": a["id"], "calendar": a["sync_status"]}}
            # failed at the last moment (race / policy) -> explain + alternatives, never pretend success
            flow.pop("date", None); flow.pop("time", None)
            if res["reason"] in ("property_unavailable", "property_not_found"):
                return {"flow": None, "pending": None, "response": F("Maaf kijiye {hon}, yeh property ab available nahi hai. Main isi tarah ki doosri property dikha sakta hoon, kya aap dekhna chahenge?", state),
                        "tool_outputs": [{"tool": "book_appointment", "ok": False, "reason": res["reason"]}], "_detail": d}
            return {"flow": flow, "pending": None, "response": _alternatives_msg(state, res["reason"], res.get("alternatives", [])),
                    "tool_outputs": [{"tool": "book_appointment", "ok": False, "reason": res["reason"]}], "_detail": d}

    # ------- slot collection -------
    flow = _merge_slots(flow, text, state)
    recs = state.get("last_recommended") or []
    pid = ent.get("property_id") or flow.get("property_id") or state.get("focus_property_id")
    if _ordinal(text.lower()) is not None and recs and not ent.get("property_id") and _ordinal(text.lower()) < len(recs):
        pid = recs[_ordinal(text.lower())]
    if not pid and len(recs) == 1:
        pid = recs[0]
    if not pid:
        if recs:
            names = " ya ".join(f"Property {i}" for i in recs)
            return {"flow": flow, "response": F("Ji {hon}, kaunsi property dekhna chahenge, {n}?", state, n=names), "_detail": {**d, "action": "ask_property"}}
        return {"flow": None, "response": F("Zaroor {hon}! Pehle yeh bata dein ke aap kis area aur budget mein property dekh rahe hain, main best option dhoond ke visit rakh deta hoon.", state),
                "_detail": {**d, "action": "no_property_context"}}
    av = db.check_availability(pid)
    d["availability"] = av
    if not av["available"]:
        return {"flow": None, "pending": None, "offered_visit": False,
                "response": F("Maaf kijiye {hon}, Property {p} ab available nahi hai. Main isi tarah ki doosri property dikhata hoon, kya aap dekhna chahenge?", state, p=pid),
                "tool_outputs": [{"tool": "check_availability", **av}], "_detail": {**d, "action": "property_unavailable"}}
    flow["property_id"] = pid
    prop = db.get_property(pid)
    agent = ap.get_agent(prop["agent_id"])

    if not flow.get("name") and state.get("customer") and state["customer"].get("name"):
        flow["name"] = state["customer"]["name"]
    phone = flow.get("phone") or state.get("caller_phone")

    have_date, have_time = bool(flow.get("date")), bool(flow.get("time"))
    if have_date and have_time:
        start = _flow_when(flow)
        v = ap.validate_slot(agent, start)
        d["slot_validation"] = v
        if not v["ok"]:
            alts = [timeutil.iso(a) for a in ap.suggest_alternatives(agent, start)]
            flow.pop("date", None); flow.pop("time", None)
            return {"flow": flow, "pending": None, "response": _alternatives_msg(state, v["reason"], alts),
                    "tool_outputs": [{"tool": "validate_slot", "ok": False, "reason": v["reason"], "alternatives": len(alts)}],
                    "_detail": {**d, "action": "slot_rejected", "alternatives": alts}}
    if not have_date:
        return {"flow": flow, "response": F("Ji {hon}, {p} ki visit ke liye kaunsa din theek rahega? Hum Monday se Saturday, subah 10 se shaam 7 baje tak available hain.", state, p=f"Property {pid}"),
                "_detail": {**d, "action": "ask_date"}}
    if not have_time:
        return {"flow": flow, "response": F("Theek hai {hon}, {day} ko kis waqt aana pasand karenge? Subah 10 se shaam 7 baje ke darmiyan.", state,
                                            day=timeutil.spoken_date(datetime.fromisoformat(flow["date"]).replace(tzinfo=timeutil.tz()))),
                "_detail": {**d, "action": "ask_time"}}
    if not flow.get("name"):
        return {"flow": flow, "response": F("Ji {hon}, {when} theek hai. Booking ke liye aap ka naam bata dein?", state, when=timeutil.spoken_when(start)),
                "_detail": {**d, "action": "ask_name"}}
    if not phone:
        return {"flow": flow, "response": F("Shukriya {name} {hon}. Aap ka contact number bata dein taake agent aap se rabta kar sake?", state, name=flow["name"]),
                "_detail": {**d, "action": "ask_phone"}}
    flow["phone"] = phone
    return {"flow": flow, "pending": "confirm_booking", "offered_visit": False,
            "response": F("Theek hai, main confirm kar loon {hon}: {name}, {title}, {when}, hamare agent {agent} ke saath. Sab theek hai?", state,
                          name=flow["name"], title=f"Property {pid} ({prop['area']})", when=timeutil.spoken_when(start), agent=agent["name"]),
            "tool_outputs": [{"tool": "validate_slot", "ok": True}], "_detail": {**d, "action": "await_confirmation", "slots": {k: flow[k] for k in ("property_id", "date", "time", "name")}}}


def _pick_appointment(state, text: str, appts: list[dict]) -> dict | None:
    idx = _ordinal(text.lower())
    if idx is not None and idx < len(appts):
        return appts[idx]
    w = parse_when(text.lower(), timeutil.now())
    if w.date:
        m = [a for a in appts if timeutil.from_iso(a["start_ts"]).date() == w.date]
        if len(m) == 1:
            return m[0]
    return None


def _find_target(state, flow: dict, text: str) -> tuple[dict | None, dict | None, str | None]:
    """-> (appointment, response_dict_if_need_more_info, phone)"""
    phone = flow.get("phone") or state.get("caller_phone")
    if not phone:
        return None, {"flow": flow, "response": F("Ji {hon}, pehle aap ka booking wala number bata dein taake main visit dhoond sakun?", state),
                      "_detail": {"action": "ask_phone"}}, None
    appts = ap.upcoming_for_phone(phone)
    if not appts:
        return None, {"flow": None, "pending": None, "response": F("Maaf kijiye {hon}, is number par koi upcoming visit nahi mili. Kya main nayi visit book kar dun?", state),
                      "offered_visit": True, "_detail": {"action": "no_appointment"}}, phone
    if flow.get("appt_id"):
        t = next((a for a in appts if a["id"] == flow["appt_id"]), None)
        if t:
            return t, None, phone
    if len(appts) == 1:
        return appts[0], None, phone
    chosen = _pick_appointment(state, text, appts)
    if chosen:
        return chosen, None, phone
    lst = "; ".join(f"{i+1}: {timeutil.spoken_when(timeutil.from_iso(a['start_ts']))}" for i, a in enumerate(appts[:3]))
    return None, {"flow": flow, "response": F("Ji {hon}, aap ki kai visits hain: {l}. Kaunsi wali?", state, l=lst),
                  "_detail": {"action": "ask_which", "n": len(appts)}}, phone


@traced("rescheduling")
def reschedule_node(state: AgentState) -> dict:
    text, intent = state["cleaned_input"], state["intent"]
    flow = dict(state.get("flow") or {})
    if flow.get("type") != "reschedule":
        flow = {"type": "reschedule"}
    flow = _merge_slots(flow, text, state)
    if state.get("pending") == "confirm_reschedule":
        if intent == "confirm_no":
            flow.pop("date", None); flow.pop("time", None)
            return {"flow": flow, "pending": None, "response": F("Theek hai {hon}, koi aur din ya time bata dein?", state)}
        if intent == "confirm_yes":
            res = ap.reschedule(flow["appt_id"], _flow_when(flow), notify=False)
            if res["ok"]:
                a = res["appointment"]
                return {"flow": None, "pending": None, "appointment": a, "outcome": "booked",
                        "notify": {"kind": "rescheduled", "appt_id": a["id"], "old_start": res["old_start"]},
                        "tool_outputs": [{"tool": "reschedule_appointment", "ok": True, "appointment_id": a["id"]}],
                        "response": F("Ho gaya {hon}! Aap ki visit ab {when} par hai. [[EMAIL_NOTE]] Aur kuch?", state, when=timeutil.spoken_when(timeutil.from_iso(a["start_ts"]))),
                        "_detail": {"appointment_id": a["id"], "old": res["old_start"]}}
            flow.pop("date", None); flow.pop("time", None)
            return {"flow": flow, "pending": None, "response": _alternatives_msg(state, res["reason"], res.get("alternatives", [])) if res.get("reason") not in ("too_late_to_change", "not_found")
                    else F("Maaf kijiye {hon}, " + res["message"] + " Baraye meherbani agent se seedha rabta karein.", state),
                    "tool_outputs": [{"tool": "reschedule_appointment", "ok": False, "reason": res["reason"]}], "_detail": {"result": res["reason"]}}
    target, need, phone = _find_target(state, flow, text)
    if need:
        return need
    flow["appt_id"], flow["phone"] = target["id"], phone
    agent, start_old = ap.get_agent(target["agent_id"]), timeutil.from_iso(target["start_ts"])
    if not flow.get("date") or not flow.get("time"):
        if flow.get("date") and not flow.get("time"):
            return {"flow": flow, "response": F("Ji {hon}, us din kis waqt aana chahenge?", state), "_detail": {"action": "ask_time"}}
        return {"flow": flow, "response": F("Ji {hon}, aap ki mojooda visit {when} par hai. Nayi visit kis din aur kis waqt rakhein?", state, when=timeutil.spoken_when(start_old)),
                "_detail": {"action": "ask_new_slot", "appointment_id": target["id"]}}
    start = _flow_when(flow)
    v = ap.validate_slot(agent, start, exclude_id=target["id"])
    if not v["ok"]:
        alts = [timeutil.iso(a) for a in ap.suggest_alternatives(agent, start, exclude_id=target["id"])]
        flow.pop("date", None); flow.pop("time", None)
        return {"flow": flow, "response": _alternatives_msg(state, v["reason"], alts), "_detail": {"action": "slot_rejected", "reason": v["reason"]}}
    return {"flow": flow, "pending": "confirm_reschedule",
            "response": F("Theek hai {hon}, main visit {old} se hata kar {new} par kar doon? Confirm kar dein?", state,
                          old=timeutil.spoken_when(start_old), new=timeutil.spoken_when(start)),
            "_detail": {"action": "await_confirmation", "appointment_id": target["id"]}}


@traced("cancellation")
def cancel_node(state: AgentState) -> dict:
    text, intent = state["cleaned_input"], state["intent"]
    flow = dict(state.get("flow") or {})
    if flow.get("type") != "cancel":
        flow = {"type": "cancel"}
    flow = _merge_slots(flow, text, state)
    if state.get("pending") == "confirm_cancel":
        if intent == "confirm_no":
            return {"flow": None, "pending": None, "response": F("Theek hai {hon}, aap ki visit bilkul pehle ki tarah barqarar hai.", state)}
        if intent == "confirm_yes":
            res = ap.cancel(flow["appt_id"], "cancelled by caller via voice agent", notify=False)
            if res["ok"]:
                a = res["appointment"]
                return {"flow": None, "pending": None, "appointment": a, "outcome": "cancelled",
                        "notify": {"kind": "cancelled", "appt_id": a["id"]},
                        "tool_outputs": [{"tool": "cancel_appointment", "ok": True, "appointment_id": a["id"]}],
                        "response": F("Theek hai {hon}, aap ki visit cancel kar di gayi hai. [[EMAIL_NOTE]] Jab bhi dobara zaroorat ho, bejhijak call kijiye ga.", state),
                        "_detail": {"appointment_id": a["id"]}}
            return {"flow": None, "pending": None, "response": F("Maaf kijiye {hon}, " + res.get("message", "cancel nahi ho saki") + " Agent se rabta kar lein.", state)}
    target, need, phone = _find_target(state, flow, text)
    if need:
        return need
    flow["appt_id"], flow["phone"] = target["id"], phone
    return {"flow": flow, "pending": "confirm_cancel",
            "response": F("Ji {hon}, aap ki {when} wali visit cancel kar doon? Agar sirf time ka masla hai to main reschedule bhi kar sakta hoon. Cancel kar dun?", state,
                          when=timeutil.spoken_when(timeutil.from_iso(target["start_ts"]))),
            "_detail": {"action": "await_confirmation", "appointment_id": target["id"]}}


# --------------------------------------------------------------------------- #
# 9. email notification node
# --------------------------------------------------------------------------- #
@traced("email")
def email_node(state: AgentState) -> dict:
    n = state.get("notify")
    if not n:
        return {"_detail": {"skipped": True}}
    res = ap.notify_appointment(n["appt_id"], n["kind"], requirements=_prof(state).__dict__ | {}, old_start=n.get("old_start"))
    status = res.get("status")
    note = {"sent": "Hamare agent ko email ke zariye bhi inform kar diya gaya hai.",
            "queued": "Agent ko email thori der mein pahunch jayegi."}.get(status, "")
    return {"response": state["response"].replace("[[EMAIL_NOTE]]", note),
            "tool_outputs": [{"tool": "email", "kind": n["kind"], "status": status}],
            "_detail": {"kind": n["kind"], "status": status, "to": res.get("to")}}


# --------------------------------------------------------------------------- #
# 10. respond (optional LLM polish, validated)
# --------------------------------------------------------------------------- #
_NUM = re.compile(r"\d+(?:[.:]\d+)?")
_SYS_PROMPT_CACHE: str | None = None


def _system_prompt() -> str:
    global _SYS_PROMPT_CACHE
    if _SYS_PROMPT_CACHE is None:
        from pathlib import Path
        p = Path(__file__).resolve().parent.parent.parent / "prompts" / "system_prompt.md"
        _SYS_PROMPT_CACHE = p.read_text(encoding="utf-8") if p.exists() else "You are Zain, a Pakistani real estate agent."
    return _SYS_PROMPT_CACHE


def facts_preserved(draft: str, polished: str) -> bool:
    """LLM may re-phrase but must keep every number/time/id exactly."""
    return set(_NUM.findall(draft)) <= set(_NUM.findall(polished))


NO_POLISH = {"blocked:injection", "blocked:authority_claim", "blocked:exfiltration", "blocked:fake_booking", "silence"}


@traced("respond")
def respond_node(state: AgentState) -> dict:
    draft = (state.get("response") or "").replace("[[EMAIL_NOTE]]", "").replace("  ", " ").strip()
    final, method = draft, "template"
    from app.config import get_settings
    if llm.is_enabled() and get_settings().llm_polish and state.get("intent") not in NO_POLISH and draft:
        hist = "\n".join(f"{m['role']}: {m['content']}" for m in (state.get("messages") or [])[-4:])
        out = llm.generate(
            _system_prompt(),
            f"Conversation so far:\n{hist}\n\nDRAFT REPLY (facts are verified):\n{draft}\n\n"
            "Rewrite the draft as Zain would say it on the phone, natural UrduLish, max 3 short sentences. "
            "Keep EVERY number, name, date, time and property id exactly as in the draft. Do not add any new fact, "
            "promise or offer. Output only the spoken reply.",
            temperature=0.5, max_tokens=220)
        if out and facts_preserved(draft, out) and len(out) <= max(160, len(draft) * 2.2) and "language model" not in out.lower():
            final, method = out.strip().strip('"'), "llm"
        else:
            method = "template (llm rejected)" if out else "template (llm unavailable)"
    crm.log_message(state["call_id"], "assistant", final)
    return {"response": final, "messages": [{"role": "assistant", "content": final}],
            "_detail": {"method": method, "chars": len(final)}}
