"""LangGraph state (Day 5 Task 1).

Persistent across the whole call (checkpointed by thread_id = call_id):
  messages, profile, customer, last_recommended, focus_property_id, flow, pending, appointment, trace ...
Reset every turn:  intent, entities, guard, response, notify, objection.
List fields use an `operator.add` reducer so nodes only return *new* items.
"""
from __future__ import annotations

import operator
from typing import Annotated, Any, TypedDict


class AgentState(TypedDict, total=False):
    # ---- identity / call ----
    call_id: str
    caller_phone: str | None
    turn: int
    honorific: str                      # sir | madam
    customer: dict | None               # CRM record (returning customer)
    # ---- conversation ----
    user_input: str
    cleaned_input: str
    messages: Annotated[list[dict], operator.add]
    # ---- understanding ----
    intent: str
    entities: dict
    guard: dict
    objection: str | None
    # ---- caller requirements & memory ----
    profile: dict                       # Profile fields: budget, city, area, bedrooms, purpose, ...
    last_recommended: list[int]
    focus_property_id: int | None
    offered_visit: bool                 # agent just offered a visit -> a bare "haan" means "book it"
    # ---- multi-turn workflows ----
    flow: dict | None                   # {"type": "book"|"reschedule"|"cancel", ...collected slots}
    pending: str | None                 # confirm_booking | confirm_reschedule | confirm_cancel
    appointment: dict | None
    notify: dict | None                 # consumed by the email node
    # ---- tool audit ----
    tool_outputs: Annotated[list[dict], operator.add]
    # ---- output ----
    draft: str
    response: str
    trace: Annotated[list[dict], operator.add]
    # ---- counters / flags ----
    abuse_count: int
    silence_count: int
    unknown_count: int
    escalated: bool
    ended: bool
    outcome: str
