"""Call runtime: turns the LangGraph agent into a simple `start_call` / `say` API,
the shape a telephony layer (or a test) actually wants to call.
"""
from __future__ import annotations

from app import timeutil
from app.agent.graph import get_graph
from app.agent.nodes import SILENCE_MARKER, START_MARKER
from app.services import crm


class CallSession:
    def __init__(self, caller_phone: str | None = None, call_id: str | None = None):
        self.call_id = call_id or crm.start_call(caller_phone)
        self.caller_phone = caller_phone
        self.config = {"configurable": {"thread_id": self.call_id}}
        self.graph = get_graph()
        self.ended = False
        self.turns: list[dict] = []

    def _invoke(self, user_input: str) -> dict:
        result = self.graph.invoke(
            {"call_id": self.call_id, "caller_phone": self.caller_phone, "user_input": user_input}, self.config)
        self.ended = bool(result.get("ended"))
        if self.ended:
            crm.end_call(self.call_id, result.get("outcome", "info"), result.get("response", "")[:200])
        self.turns.append({"turn": result.get("turn"), "user": user_input, "agent": result.get("response")})
        return result

    def greet(self) -> str:
        return self._invoke(START_MARKER)["response"]

    def say(self, text: str) -> str:
        if self.ended:
            return "[call already ended]"
        return self._invoke(text)["response"]

    def silence(self) -> str:
        return self._invoke(SILENCE_MARKER)["response"]

    def state(self) -> dict:
        return self.graph.get_state(self.config).values

    def trace(self) -> list[dict]:
        return crm.get_node_events(self.call_id)

    def transcript(self) -> list[dict]:
        return crm.get_transcript(self.call_id)


def run_scripted_call(turns: list[str], caller_phone: str | None = None, greet: bool = True) -> CallSession:
    """Helper for tests/demos: run a whole conversation and return the finished session."""
    s = CallSession(caller_phone)
    if greet:
        s.greet()
    for t in turns:
        s.say(t)
    return s
