r"""Graph wiring (Day 5 Task 2).

    load_context -> guard -[category?]-> guardrail ------------------------\
                          \-> intent_detection -[intent]-> {greeting, rag,   |
                                recommendation, objection, booking,          |
                                rescheduling, cancellation, escalate,        |
                                goodbye, thanks, silence, abort, clarify}    |
                                                |                            |
                                                v                            v
                                            email (only if `notify` set) -> respond -> END

`email` runs after any node that sets `state["notify"]` (booking/reschedule/cancel confirmations);
every other branch skips straight to `respond`. `respond` optionally polishes the deterministic
draft with the LLM, always preserving every number/name/time, then logs the turn and returns.

Checkpointing: an in-memory `MemorySaver` keyed by `thread_id = call_id` gives the graph
turn-to-turn memory for free; conversation content itself is durably logged to SQL via `crm`.
"""
from __future__ import annotations

from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph

from app.agent import nodes as N
from app.agent.state import AgentState

_BRANCH_TARGETS = {
    "greeting": "greeting", "rag": "rag", "recommendation": "recommendation", "objection": "objection",
    "booking": "booking", "rescheduling": "rescheduling", "cancellation": "cancellation",
    "escalate": "escalate", "goodbye": "goodbye", "thanks": "thanks", "silence": "silence",
    "abort": "abort", "clarify": "clarify",
}


def route_to_email(state: AgentState) -> str:
    return "email" if state.get("notify") else "respond"


def build_graph():
    g = StateGraph(AgentState)
    g.add_node("load_context", N.load_context)
    g.add_node("guard", N.guard)
    g.add_node("guardrail", N.guardrail_node)
    g.add_node("intent_detection", N.intent_detection)
    g.add_node("greeting", N.greeting_node)
    g.add_node("rag", N.rag_node)
    g.add_node("recommendation", N.recommend_node)
    g.add_node("objection", N.objection_node)
    g.add_node("booking", N.booking_node)
    g.add_node("rescheduling", N.reschedule_node)
    g.add_node("cancellation", N.cancel_node)
    g.add_node("escalate", N.escalate_node)
    g.add_node("goodbye", N.goodbye_node)
    g.add_node("thanks", N.thanks_node)
    g.add_node("silence", N.silence_node)
    g.add_node("abort", N.abort_node)
    g.add_node("clarify", N.clarify_node)
    g.add_node("email", N.email_node)
    g.add_node("respond", N.respond_node)

    g.add_edge(START, "load_context")
    g.add_edge("load_context", "guard")
    g.add_conditional_edges("guard", N.route_after_guard, {"guardrail": "guardrail", "intent_detection": "intent_detection"})
    g.add_edge("guardrail", "respond")
    g.add_conditional_edges("intent_detection", N.route_after_intent, _BRANCH_TARGETS)
    for branch in _BRANCH_TARGETS:
        g.add_conditional_edges(branch, route_to_email, {"email": "email", "respond": "respond"})
    g.add_edge("email", "respond")
    g.add_edge("respond", END)
    return g.compile(checkpointer=MemorySaver())


_GRAPH = None


def get_graph():
    global _GRAPH
    if _GRAPH is None:
        _GRAPH = build_graph()
    return _GRAPH
