"""FastAPI backend (Step 1 endpoints; agent/voice/booking endpoints are added in later steps)."""
from __future__ import annotations

import time
from fastapi import Depends, FastAPI, HTTPException
from pydantic import BaseModel, Field

from app import db, engine, llm, timeutil
from app.security import require_admin, require_demo_access
from app.logging_setup import configure_logging

configure_logging()
from app.agent.session import CallSession
from app.nlp.entities import parse_utterance
from app.recommender import Profile, recommend
from app.services import appointments as ap
from app.services import crm, email_service
from app.voice import router as voice_router
from app.telephony import router as telephony_router

app = FastAPI(title="RealEstate Hub AI Voice Agent API", version="0.1.0",
              description="Knowledge, retrieval and recommendation services for the AI voice agent.")
app.include_router(voice_router)
app.include_router(telephony_router)


class AskRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=500, examples=["Property 1 ki price kya hai?"])


class RecommendRequest(BaseModel):
    utterance: str | None = Field(None, description="Free-text UrduLish, e.g. 'DHA mein 3 crore tak ghar chahiye'")
    budget_max: float | None = None
    city: str | None = None
    area: str | None = None
    bedrooms: int | None = None
    purpose: str = "sale"
    ptype: str | None = None
    investment: bool = False
    exclude_ids: list[int] = []
    cheaper_than: float | None = None
    limit: int = Field(3, ge=1, le=10)


@app.get("/health")
def health():
    """Liveness + dependency check (used by Docker/Railway health checks)."""
    try:
        n = len(db.search_properties(only_available=False))
        ok_db = n > 0
    except Exception:
        ok_db, n = False, 0
    r = engine.get_retriever()
    return {"status": "ok" if ok_db else "degraded", "properties": n, "kb_chunks": r.n_chunks,
            "vector_store": r.store.name, "embedder": r.embedder.name}


@app.post("/knowledge/ask")
def ask(req: AskRequest):
    t = time.perf_counter()
    out = engine.ask(req.question)
    out.pop("context", None)
    out["latency_ms"] = round((time.perf_counter() - t) * 1000, 1)
    return out


@app.post("/recommend")
def recommend_endpoint(req: RecommendRequest):
    prof = Profile(budget_max=req.budget_max, city=req.city, area=req.area, bedrooms=req.bedrooms,
                   purpose=req.purpose, ptype=req.ptype, investment=req.investment,
                   exclude_ids=req.exclude_ids, cheaper_than=req.cheaper_than)
    if req.utterance:
        prof = Profile.from_entities(parse_utterance(req.utterance), prof)
    return recommend(prof, limit=req.limit)


@app.get("/properties/{property_id}")
def get_property(property_id: int):
    p = db.get_property(property_id)
    if not p:
        raise HTTPException(404, f"Property {property_id} not found")
    p["payment_plans"] = db.get_payment_plans(property_id)
    return p


# --------------------------------------------------------------------------- #
# Voice-agent call endpoints (Day 5/6/7).
# In-process session registry; a real telephony layer (Twilio/Deepgram) would
# instead keep the CallSession alive per active phone call in the same way.
# --------------------------------------------------------------------------- #
_SESSIONS: dict[str, CallSession] = {}


class StartCallRequest(BaseModel):
    caller_phone: str | None = None


class TurnRequest(BaseModel):
    call_id: str
    text: str = Field(..., min_length=1, max_length=500)


@app.post("/call/start", dependencies=[Depends(require_demo_access)])
def call_start(req: StartCallRequest):
    s = CallSession(caller_phone=req.caller_phone)
    _SESSIONS[s.call_id] = s
    return {"call_id": s.call_id, "response": s.greet()}


@app.post("/call/turn", dependencies=[Depends(require_demo_access)])
def call_turn(req: TurnRequest):
    s = _SESSIONS.get(req.call_id)
    if not s:
        raise HTTPException(404, "Unknown or expired call_id")
    t0 = time.perf_counter()
    resp = s.say(req.text)
    return {"call_id": req.call_id, "response": resp, "ended": s.ended,
            "latency_ms": round((time.perf_counter() - t0) * 1000, 1)}


@app.get("/call/{call_id}/transcript", dependencies=[Depends(require_demo_access)])
def call_transcript(call_id: str):
    return {"transcript": crm.get_transcript(call_id), "trace": crm.get_node_events(call_id)}


@app.post("/admin/retry-outbox", dependencies=[Depends(require_admin)])
def retry_outbox():
    return email_service.retry_outbox()


@app.post("/admin/retry-calendar-sync", dependencies=[Depends(require_admin)])
def retry_calendar_sync():
    return ap.retry_pending_calendar_syncs()


@app.get("/admin/stats", dependencies=[Depends(require_admin)])
def admin_stats():
    with db.conn() as c:
        from sqlalchemy import text
        n_calls = c.execute(text("SELECT COUNT(*) FROM calls")).scalar()
        n_appts = c.execute(text("SELECT COUNT(*) FROM appointments WHERE status IN ('booked','rescheduled')")).scalar()
        by_outcome = dict(c.execute(text("SELECT outcome, COUNT(*) FROM calls WHERE outcome IS NOT NULL GROUP BY outcome")).all())
    return {"calls": n_calls, "active_appointments": n_appts, "by_outcome": by_outcome,
            "email_outbox": email_service.outbox_stats(), "llm": llm.stats()}
