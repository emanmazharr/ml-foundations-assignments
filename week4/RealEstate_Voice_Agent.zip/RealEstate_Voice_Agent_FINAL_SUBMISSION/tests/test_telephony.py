import base64
import hashlib
import hmac
from types import SimpleNamespace
from urllib.parse import urlencode
from xml.etree import ElementTree as ET

import pytest
from fastapi.testclient import TestClient

from app import telephony
from app.main import app


def settings(**overrides):
    values = {
        "twilio_auth_token": "test-auth-token",
        "twilio_public_base_url": "https://voice.example.test",
        "twilio_stt_model": "deepgram_nova-3",
        "twilio_stt_language": "multi",
    }
    values.update(overrides)
    return SimpleNamespace(**values)


def signature(path, fields, token="test-auth-token"):
    signed = "https://voice.example.test" + path
    signed += "".join(key + "".join(sorted(values if isinstance(values, list) else [values])) for key, values in sorted(fields.items()))
    return base64.b64encode(hmac.new(token.encode(), signed.encode(), hashlib.sha1).digest()).decode()


class FakeSession:
    def __init__(self, caller_phone=None):
        self.caller_phone = caller_phone
        self.ended = False

    def greet(self):
        return "Assalam-o-Alaikum, main property assistant hoon."

    def say(self, text):
        return "DHA Lahore mein options available hain."

    def silence(self):
        return "Aapki awaaz nahi aayi, please dobara boliye."


@pytest.fixture(autouse=True)
def clear_state(monkeypatch):
    with telephony._LOCK:
        telephony._CALLS.clear()
        telephony._MEDIA.clear()
    monkeypatch.setattr(telephony, "get_settings", lambda: settings())
    monkeypatch.setattr(telephony, "CallSession", FakeSession)


@pytest.fixture
def client():
    with TestClient(app) as test_client:
        yield test_client


def post_signed(client, path, fields, *, valid=True):
    sig = signature(path, fields) if valid else "invalid"
    return client.post(path, content=urlencode(fields, doseq=True), headers={
        "content-type": "application/x-www-form-urlencoded", "X-Twilio-Signature": sig,
    })


def test_inbound_call_returns_safe_twiml_and_short_lived_audio(client, monkeypatch):
    async def fake_speak(text):
        assert "property assistant" in text
        return b"fake-mp3"

    monkeypatch.setattr(telephony, "synthesize_fish_audio", fake_speak)
    response = post_signed(client, "/twilio/voice", {"CallSid": "CA123", "From": "+923001234567"})
    assert response.status_code == 200
    xml = ET.fromstring(response.content)
    assert xml.findtext("Play").startswith("https://voice.example.test/twilio/media/")
    gather = xml.find("Gather")
    assert gather is not None and gather.attrib["language"] == "multi"
    audio = client.get(xml.findtext("Play").removeprefix("https://voice.example.test"))
    assert audio.status_code == 200 and audio.content == b"fake-mp3"
    assert audio.headers["content-type"] == "audio/mpeg"


def test_invalid_signature_is_rejected_before_session(monkeypatch):
    with TestClient(app) as client:
        response = post_signed(client, "/twilio/voice", {"CallSid": "CA123"}, valid=False)
    assert response.status_code == 403
    assert not telephony._CALLS


def test_phone_webhook_fails_closed_without_secret_or_public_https(client, monkeypatch):
    monkeypatch.setattr(telephony, "get_settings", lambda: settings(twilio_auth_token=""))
    response = client.post("/twilio/voice", data={"CallSid": "CA123"})
    assert response.status_code == 503
    monkeypatch.setattr(telephony, "get_settings", lambda: settings(twilio_public_base_url="http://localhost"))
    response = client.post("/twilio/voice", data={"CallSid": "CA123"})
    assert response.status_code == 503


def test_signed_transcript_reaches_agent_and_repeats_gather(client, monkeypatch):
    async def fake_speak(text):
        assert "DHA Lahore" in text
        return b"reply-mp3"

    monkeypatch.setattr(telephony, "synthesize_fish_audio", fake_speak)
    telephony._CALLS["CA456"] = FakeSession()
    response = post_signed(client, "/twilio/turn", {"CallSid": "CA456", "SpeechResult": "DHA Lahore mein ghar chahiye"})
    assert response.status_code == 200
    xml = ET.fromstring(response.content)
    assert xml.find("Play") is not None and xml.find("Gather") is not None


def test_expired_media_is_not_served(client, monkeypatch):
    telephony._MEDIA["expired-token"] = (0, b"old")
    assert client.get("/twilio/media/expired-token.mp3").status_code == 404
