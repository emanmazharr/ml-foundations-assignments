import pytest

from app import db, engine
from app.db import pkr_words
from app.nlp.entities import parse_amount, parse_utterance
from app.nlp.urdulish import expand_query
from app.rag.chunker import chunk_document
from app.rag.loader import Document, load_documents
from app.recommender import Profile, recommend


# ---------- money / UrduLish parsing ----------
@pytest.mark.parametrize("text,expected", [
    ("Budget 3 crore hai", 3e7), ("dhai crore tak", 2.5e7), ("sarhe teen crore", 3.5e7),
    ("80 lakh ka budget", 8e6), ("derh crore", 1.5e7), ("1.5 lac", 1.5e5), ("50,000,000", 5e7),
])
def test_parse_amount(text, expected):
    assert parse_amount(text) == expected


def test_pkr_words():
    assert pkr_words(3.4e7) == "3.4 crore" and pkr_words(1e7) == "1 crore" and pkr_words(8.5e6) == "85 lakh"


def test_entities_urdulish():
    e = parse_utterance("DHA mein 3 kamron wala ghar chahiye Lahore mein, budget 4 crore")
    assert (e.area, e.city, e.bedrooms, e.ptype, e.budget_max) == ("DHA", "Lahore", 3, "house", 4e7)
    assert parse_utterance("F11 mein flat rent pe").purpose == "rent"
    assert parse_utterance("Us se sasti koi option?").wants_cheaper
    assert "reschedule" in parse_utterance("meri visit reschedule kar dein").flags
    assert parse_utterance("dhai crore tak flat Karachi Clifton").area == "Clifton"  # 'dhai' != 'dha'


def test_query_expansion():
    assert "school" in expand_query("schools kahan hain") and "house" in expand_query("ghar")


# ---------- database ----------
def test_db_counts_and_availability():
    assert len(db.search_properties(only_available=False)) == 42
    assert db.check_availability(14) == {"property_id": 14, "exists": True, "available": False, "status": "sold", "title": db.get_property(14)["title"]}
    assert db.check_availability(999)["exists"] is False
    assert all(p["status"] == "available" for p in db.search_properties())


def test_agents_exist_for_every_city():
    for city in ("Lahore", "Karachi", "Islamabad"):
        assert db.get_agent_for_city(city)["email"].endswith("@realestatehub.example")


# ---------- chunking ----------
def test_chunks_carry_title_and_respect_size():
    doc = Document("x", "Property 1: Demo", "# Property 1: Demo\n\n## Amenities\n" + "Amenities: " + ", ".join(["gym"] * 60) + ".", {})
    chunks = chunk_document(doc, 200, 30)
    assert len(chunks) > 1 and all(c.text.startswith("[Property 1: Demo]") for c in chunks)
    assert all(len(c.text) < 260 for c in chunks)


def test_loader_extracts_metadata():
    docs = load_documents(engine.get_settings().kb_dir if hasattr(engine, "get_settings") else __import__("app.config", fromlist=["x"]).get_settings().kb_dir)
    p10 = next(d for d in docs if d.doc_id.endswith("property_10.md"))
    assert p10.metadata["property_id"] == 10 and p10.metadata["city"] == "Lahore"
    assert any(d.metadata["doc_type"] == "faqs" for d in docs)


# ---------- routing & answers ----------
def test_routing():
    R = lambda q: engine.route(q, parse_utterance(q))
    assert R("Property 1 ki price kya hai?") == "sql"
    assert R("Bahria Town Lahore mein 2 crore tak ghar chahiye") == "sql_search"
    assert R("Bahria Town Lahore mein schools kahan hain?") == "rag"
    assert R("Property 30 mein swimming pool hai kya?") == "rag"


def test_sql_answers_are_exact():
    assert "3.4 crore" in engine.ask("Property 1 ki price kya hai?")["answer"]
    assert "sold" in engine.ask("Is property 14 available?")["answer"]
    assert engine.ask("Property 99 ki price kya hai?")["abstained"]


def test_rag_abstains_when_kb_has_no_answer():
    assert engine.ask("Kya Bahria Town Lahore mein helipad hai?")["abstained"]


# ---------- recommender ----------
def test_recommender_never_returns_unavailable_or_over_budget():
    res = recommend(Profile(budget_max=5e7, city="Lahore", area="Johar Town", ptype="house", bedrooms=4))
    ids = [m["property"]["id"] for m in res["matches"]]
    assert 14 not in ids                     # property 14 is SOLD
    for m in res["matches"]:
        assert m["property"]["status"] == "available"


def test_context_memory_scenario():
    """'Budget 3 crore' -> 'DHA mein kya options?' -> 'Us se sasti koi option?'"""
    prof = Profile.from_entities(parse_utterance("Budget 3.5 crore hai"))
    prof = Profile.from_entities(parse_utterance("DHA mein kya options hain? ghar chahiye"), prof)
    first = recommend(prof)
    assert first["matches"] and all(m["property"]["price_pkr"] <= 3.5e7 for m in first["matches"])
    top = first["matches"][0]["property"]
    prof.remember_choice(top)
    prof = Profile.from_entities(parse_utterance("Us se sasti koi option?"), prof)
    second = recommend(prof)
    assert second["matches"]
    assert all(m["property"]["price_pkr"] < top["price_pkr"] for m in second["matches"])
    assert all(m["property"]["city"] == top["city"] for m in second["matches"])   # stays in the caller's city


def test_ambiguous_area_triggers_clarification_not_a_guess():
    res = recommend(Profile(area="DHA", ptype="house", budget_max=9e7))   # DHA exists in 3 cities
    assert res["needs_clarification"] == "city" and len(res["candidate_cities"]) > 1


def test_relaxation_is_reported():
    res = recommend(Profile(budget_max=1.0e7, city="Lahore", area="DHA", ptype="house"))
    assert res["relaxed"] is not None or res["matches"] == []
