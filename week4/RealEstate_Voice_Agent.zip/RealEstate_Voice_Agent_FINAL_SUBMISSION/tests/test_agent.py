"""Day 5 agent tests: state, routing, tool validation, multi-turn flows, traces."""
from datetime import datetime
from zoneinfo import ZoneInfo

import pytest

from app import timeutil
from app.agent.session import CallSession, run_scripted_call
from app.services import appointments as ap, crm, email_service

TZ = ZoneInfo("Asia/Karachi")


@pytest.fixture(autouse=True)
def _clock():
    timeutil.freeze(datetime(2026, 9, 24, 11, 0, tzinfo=TZ))  # Thursday 11:00
    yield
    timeutil.freeze(None)


def test_greeting_new_vs_returning_customer():
    s1 = run_scripted_call([], greet=True)
    assert "Assalam-o-Alaikum" in s1.turns[0]["agent"] and "Zain" in s1.turns[0]["agent"]
    crm.upsert_customer("+923001112222", "Ali Raza")
    crm.save_preferences("+923001112222", {"area": "DHA", "city": "Lahore", "ptype": "house"})
    s2 = run_scripted_call([], caller_phone="+923001112222", greet=True)
    assert "Ali Raza" in s2.turns[0]["agent"] and "Pichli baar" in s2.turns[0]["agent"]


def test_full_booking_flow_end_to_end():
    s = run_scripted_call(
        ["DHA mein 3.5 crore tak ghar chahiye Lahore mein", "kal shaam 5 baje visit rakh dein",
         "mera naam Ali Raza hai", "haan bilkul"], caller_phone="+923001112222")
    st = s.state()
    assert st["outcome"] == "booked" and st["appointment"]["status"] == "booked"
    assert st["appointment"]["calendar_event_id"] and email_service.outbox_stats().get("sent", 0) >= 1
    assert crm.get_customer("+923001112222")["preferences"]["area"] == "DHA"


def test_bare_name_recognised_after_date_and_time_known():
    s = run_scripted_call(["Karachi mein 2 crore tak apartment chahiye", "visit rakh dein",
                           "parson dopahar 2 baje", "Sara Khan", "ji haan"], caller_phone="+923211234567")
    assert s.state()["outcome"] == "booked" and s.state()["appointment"]["customer_name"] == "Sara Khan"


def test_never_books_an_unavailable_slot_offers_alternatives_then_succeeds():
    s = run_scripted_call(["Property 1 ki visit book karni hai", "aaj 11 baje"])  # too soon (frozen at 11:00)
    last = s.turns[-1]["agent"]
    assert "3 ghante" in last or "guzar" in last
    assert s.state()["flow"] is not None and s.state()["pending"] is None       # not silently booked


def test_recommendation_never_returns_unavailable_property():
    s = run_scripted_call(["Johar Town Lahore mein 5 crore tak ghar chahiye"])
    ids = s.state().get("last_recommended") or []
    assert 14 not in ids  # property 14 is SOLD (see build_kb.py)


def test_context_memory_across_three_turns():
    s = run_scripted_call(["Budget 3.5 crore hai", "DHA mein kya options hain? Ghar chahiye", "Us se sasti koi option?"])
    st = s.state()
    assert st["profile"]["budget_max"] == 3.5e7
    assert st["last_recommended"] and st["focus_property_id"] in st["last_recommended"]


def test_reschedule_flow():
    s = run_scripted_call(["DHA mein ghar chahiye 3.5 crore tak", "kal shaam 5 baje visit rakh dein",
                           "Ali Raza", "haan"], caller_phone="+923001113333")
    appt_id = s.state()["appointment"]["id"]
    s.say("meri visit reschedule kar dein")
    s.say("parson subah 11 baje")
    s.say("ji haan confirm")
    a = ap.get_appointment(appt_id)
    assert a["status"] == "rescheduled" and a["start_ts"].startswith("2026-09-26T11:00")
    assert email_service.outbox_stats()["sent"] >= 2


def test_cancel_flow():
    s = run_scripted_call(["Clifton mein apartment chahiye rent pe", "visit rakh dein", "parson 11 baje",
                           "Zara Ahmed", "haan"], caller_phone="+923001114444")
    appt_id = s.state()["appointment"]["id"]
    s.say("meri visit cancel kar dein")
    s.say("ji haan")
    assert ap.get_appointment(appt_id)["status"] == "cancelled"


def test_abort_mid_flow_does_not_book():
    s = run_scripted_call(["DHA mein ghar chahiye", "visit rakh dein", "kal shaam 5 baje", "rehne do, mat karo"])
    assert s.state()["flow"] is None and s.state()["pending"] is None


def test_objection_handling_uses_verified_facts_and_offers_visit():
    s = run_scripted_call(["Karachi mein 2 crore tak apartment chahiye", "yeh to bohat mehnga hai"])
    reply = s.turns[-1]["agent"]
    assert "percent down payment" in reply and "guarantee" not in reply.lower().replace("discount promise", "")
    assert s.state()["offered_visit"] is True


def test_all_six_objection_types_get_a_grounded_reply():
    triggers = {"price": "yeh mehnga hai", "trust": "yeh fraud to nahi?", "location": "bohat door hai yeh area",
               "investment": "market gir gayi to nuksan hoga?", "builder": "builder ka record kaisa hai?",
               "maintenance": "maintenance charges kitne hain?"}
    for kind, msg in triggers.items():
        s = run_scripted_call(["DHA Lahore mein ghar chahiye 3.5 crore tak", msg])
        assert s.state()["objection"] == kind, f"{kind} not detected from: {msg}"
        assert len(s.turns[-1]["agent"]) > 20


def test_ambiguous_area_asks_city_instead_of_guessing():
    s = run_scripted_call(["DHA mein ghar chahiye"])
    reply = s.turns[-1]["agent"]
    assert "?" in reply and ("shehar" in reply.lower() or "lahore" in reply.lower() or "karachi" in reply.lower())


def test_unclear_input_asks_then_escalates():
    s = run_scripted_call(["asdkj qwery zzxxcc", "blah blah nonsense", "foo bar baz qux"])
    assert s.state()["escalated"] is True and s.state()["intent"] == "human"


def test_human_handoff():
    s = run_scripted_call(["mujhe kisi insaan se baat karni hai"], caller_phone="+923001115555")
    assert s.state()["escalated"] is True
    assert any("call-back" in f["reason"].lower() or "human agent" in f["reason"].lower() for f in crm.open_followups("+923001115555"))


def test_seller_lead_is_captured():
    s = run_scripted_call(["main apna ghar bechna chahta hoon"], caller_phone="+923001116666")
    assert any("sell" in f["reason"].lower() for f in crm.open_followups("+923001116666"))


def test_goodbye_ends_call():
    s = run_scripted_call(["Allah Hafiz, shukriya"])
    assert s.ended and s.state()["outcome"] in ("info", "booked")


def test_silence_then_second_silence_ends_call():
    s = CallSession(); s.greet(); s.silence()
    assert not s.ended
    s.silence()
    assert s.ended and s.state()["outcome"] == "dropped"


def test_state_logging_and_traces_are_recorded():
    s = run_scripted_call(["DHA Lahore mein 3.5 crore tak ghar chahiye"])
    nodes = [e["node"] for e in s.trace()]
    assert "load_context" in nodes and "guard" in nodes and "respond" in nodes
    assert all(e["duration_ms"] >= 0 for e in s.trace())
    assert len(s.transcript()) >= 2  # user + assistant


def test_property_question_pronoun_resolves_to_focused_property():
    s = run_scripted_call(["Property 1 ki price kya hai?", "iske amenities kya hain?"])
    assert s.state()["focus_property_id"] == 1
    assert "gated" in s.turns[-1]["agent"].lower() or "security" in s.turns[-1]["agent"].lower() or "park" in s.turns[-1]["agent"].lower()
