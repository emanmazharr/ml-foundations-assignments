import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture(scope="session", autouse=True)
def _kb():
    """Build a fresh demo DB + KB once per test session."""
    from scripts.build_kb import main
    main()


@pytest.fixture(autouse=True)
def _clean_ops(monkeypatch, tmp_path):
    """Fresh operational tables + frozen clock (Thu 24 Sep 2026, 11:00 Karachi) + mock integrations per test."""
    from datetime import datetime
    from zoneinfo import ZoneInfo
    from sqlalchemy import text
    from app import db, timeutil
    from app.config import get_settings
    from app.services import calendar_service, email_service
    db.init_db()
    with db.conn() as c:
        for t in ("appointments", "follow_ups", "messages", "calls", "node_events", "outbox", "customers"):
            c.execute(text(f"DELETE FROM {t}"))
    timeutil.freeze(datetime(2026, 9, 24, 11, 0, tzinfo=ZoneInfo("Asia/Karachi")))
    s = get_settings()
    monkeypatch.setattr(s, "calendar_mode", "mock")
    monkeypatch.setattr(s, "email_mode", "mock")
    monkeypatch.setattr(s, "outbox_dir", str(tmp_path / "outbox"))
    monkeypatch.setattr(s, "demo_agent_email", "")
    monkeypatch.setattr(email_service.time, "sleep", lambda *_: None)
    calendar_service.set_calendar(None)
    yield
    timeutil.freeze(None)
    calendar_service.set_calendar(None)
