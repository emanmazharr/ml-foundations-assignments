from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import pytest

from app import db, timeutil
from app.services import appointments as ap, crm, email_service
from app.services.calendar_service import CalendarBackend, MockCalendar, set_calendar

TZ = ZoneInfo("Asia/Karachi")
FRI_5PM = datetime(2026, 9, 25, 17, 0, tzinfo=TZ)     # tomorrow 17:00 (clock frozen Thu 11:00)


def book(start=FRI_5PM, pid=1, name="Ali Raza", phone="+923001234567", **kw):
    return ap.book(customer_name=name, customer_phone=phone, property_id=pid, start=start, **kw)


def test_successful_booking_updates_calendar_crm_email():
    r = book(requirements={"budget_max": 3.5e7, "area": "DHA"})
    assert r["ok"] and r["appointment"]["status"] == "booked"
    assert r["appointment"]["calendar_event_id"].startswith("mock_evt_") and r["appointment"]["sync_status"] == "ok"
    assert r["email"]["status"] == "sent"
    assert email_service.outbox_stats() == {"sent": 1}
    cust = crm.get_customer("+923001234567")
    assert cust["name"] == "Ali Raza" and cust["preferences"]["area"] == "DHA" and cust["lead_score"] == 40
    assert len(crm.open_followups("+923001234567")) == 1              # post-visit follow-up reminder


def test_employee_email_contains_required_fields():
    book(requirements={"budget_max": 3.5e7, "bedrooms": 3})
    import json
    from pathlib import Path
    from app.config import get_settings
    body = json.loads(next(Path(get_settings().outbox_dir).glob("*.json")).read_text())["text"]
    for needle in ("Meeting time", "Property", "Client name", "Ali Raza", "Client phone", "Requirement - Bedrooms"):
        assert needle in body


@pytest.mark.parametrize("when,reason", [
    (datetime(2026, 9, 24, 10, 0, tzinfo=TZ), "past"),
    (datetime(2026, 9, 24, 12, 0, tzinfo=TZ), "too_soon"),          # only 1h notice
    (datetime(2026, 9, 27, 15, 0, tzinfo=TZ), "sunday"),
    (datetime(2026, 9, 25, 20, 0, tzinfo=TZ), "outside_hours"),
    (datetime(2026, 9, 25, 9, 30, tzinfo=TZ), "outside_hours"),
    (datetime(2026, 9, 25, 18, 30, tzinfo=TZ), None),               # last valid slot
    (datetime(2026, 9, 25, 19, 0, tzinfo=TZ), "outside_hours"),
    (datetime(2026, 9, 25, 17, 15, tzinfo=TZ), "misaligned"),
    (datetime(2026, 12, 25, 17, 0, tzinfo=TZ), "too_far"),
])
def test_slot_policy(when, reason):
    r = book(start=when)
    assert r["ok"] is (reason is None)
    if reason:
        assert r["reason"] == reason


def test_never_double_books_and_offers_alternatives():
    assert book()["ok"]
    r = book(name="Sara", phone="+923211112222", pid=2)             # property 2 -> same agent (Ahmed)
    assert not r["ok"] and r["reason"] == "conflict" and len(r["alternatives"]) >= 1
    for alt in r["alternatives"]:                                   # every suggestion must itself be bookable
        assert ap.validate_slot(ap.get_agent(1), timeutil.from_iso(alt))["ok"]


def test_different_agents_can_share_a_time():
    assert book(pid=1)["ok"]                                        # Ahmed (Lahore)
    assert book(pid=16, name="Bilal C", phone="+923211112223")["ok"]  # Bilal (Karachi)


@pytest.mark.parametrize("pid,reason", [(14, "property_unavailable"), (3, "property_unavailable"), (999, "property_not_found")])
def test_never_books_unavailable_property(pid, reason):
    r = book(pid=pid)
    assert not r["ok"] and r["reason"] == reason


def test_reschedule_frees_old_slot_and_emails():
    a = book()["appointment"]
    new = datetime(2026, 9, 26, 11, 0, tzinfo=TZ)
    r = ap.reschedule(a["id"], new)
    assert r["ok"] and r["appointment"]["status"] == "rescheduled" and r["appointment"]["start_ts"].startswith("2026-09-26T11:00")
    assert r["email"]["status"] == "sent" and email_service.outbox_stats()["sent"] == 2
    assert book(name="Sara", phone="+923211112222", pid=2)["ok"]    # the old 17:00 slot is free again
    assert [h["event"] for h in ap.get_appointment(a["id"])["history"]] == ["booked", "rescheduled"]


def test_reschedule_into_taken_slot_is_rejected():
    a = book()["appointment"]
    book(start=datetime(2026, 9, 26, 11, 0, tzinfo=TZ), name="Sara", phone="+923211112222", pid=2)
    r = ap.reschedule(a["id"], datetime(2026, 9, 26, 11, 0, tzinfo=TZ))
    assert not r["ok"] and r["reason"] == "conflict"
    assert ap.get_appointment(a["id"])["status"] == "booked"        # unchanged


def test_cancel_frees_slot_and_creates_reengagement_followup():
    a = book()["appointment"]
    r = ap.cancel(a["id"], "plans changed")
    assert r["ok"] and r["appointment"]["status"] == "cancelled" and r["email"]["status"] == "sent"
    assert book(name="Sara", phone="+923211112222", pid=2)["ok"]
    assert any("Re-engage" in f["reason"] for f in crm.open_followups("+923001234567"))
    assert not ap.cancel(a["id"])["ok"]                             # cancelling twice fails cleanly


def test_cannot_change_appointment_inside_notice_window():
    a = book(start=datetime(2026, 9, 24, 15, 0, tzinfo=TZ))["appointment"]   # 4h ahead: allowed
    timeutil.freeze(datetime(2026, 9, 24, 13, 0, tzinfo=TZ))                 # now only 2h before
    assert ap.cancel(a["id"])["ok"] is True                                   # cancelling is always allowed
    a2 = book(start=datetime(2026, 9, 25, 10, 0, tzinfo=TZ), phone="+923001112222", name="Zed")["appointment"]
    timeutil.freeze(datetime(2026, 9, 25, 9, 0, tzinfo=TZ))
    assert ap.reschedule(a2["id"], datetime(2026, 9, 25, 16, 0, tzinfo=TZ))["reason"] == "too_late_to_change"


# ---------------- failure handling ----------------
class DownCalendar(MockCalendar):
    ok = False
    def create_event(self, *a):
        if not self.ok: raise ConnectionError("calendar API down")
        return super().create_event(*a)
    def update_event(self, *a):
        if not self.ok: raise ConnectionError("calendar API down")
    def delete_event(self, *a):
        if not self.ok: raise ConnectionError("calendar API down")


def test_calendar_outage_does_not_lose_booking_and_syncs_later(monkeypatch):
    monkeypatch.setattr(ap.time if hasattr(ap, "time") else __import__("time"), "sleep", lambda *_: None)
    cal = DownCalendar(); set_calendar(cal)
    r = book()
    assert r["ok"] and r["appointment"]["sync_status"] == "pending" and r["appointment"]["calendar_event_id"] is None
    cal.ok = True
    fixed = ap.retry_pending_calendar_syncs()
    assert fixed == {"pending": 1, "fixed": 1}
    assert ap.get_appointment(r["appointment"]["id"])["sync_status"] == "ok"


def test_email_outage_queues_then_retry_delivers(monkeypatch):
    monkeypatch.setattr(email_service, "_transport", lambda: (_ for _ in ()).throw(ConnectionError("smtp down")))
    r = book()
    assert r["ok"] and r["email"]["status"] == "queued"
    assert email_service.outbox_stats() == {"pending": 1}
    monkeypatch.setattr(email_service, "_transport", lambda: email_service._send_mock)
    assert email_service.retry_outbox()["sent"] == 1
    assert email_service.outbox_stats() == {"sent": 1}


def test_free_slot_suggestions_are_valid_and_sorted():
    ag = ap.get_agent(1)
    slots = ap.next_free_slots(ag, datetime(2026, 9, 24, 11, 0, tzinfo=TZ), 4)
    assert len(slots) == 4 and slots == sorted(slots)
    assert all(s >= timeutil.now() + timedelta(hours=3) for s in slots)
