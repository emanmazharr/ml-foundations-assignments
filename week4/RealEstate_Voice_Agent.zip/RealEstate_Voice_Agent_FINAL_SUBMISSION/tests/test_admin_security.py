from types import SimpleNamespace

from fastapi.testclient import TestClient

from app import security
from app.main import app


def test_production_admin_routes_fail_closed_without_key(monkeypatch):
    monkeypatch.setattr(security, "get_settings", lambda: SimpleNamespace(app_env="production", admin_api_key=""))
    with TestClient(app) as client:
        response = client.get("/admin/stats")
    assert response.status_code == 503
    assert "ADMIN_API_KEY" in response.json()["detail"]


def test_admin_key_required_and_valid_key_works_in_local_test(monkeypatch):
    monkeypatch.setattr(security, "get_settings", lambda: SimpleNamespace(app_env="production", admin_api_key="test-key"))
    with TestClient(app) as client:
        denied = client.get("/admin/stats")
        accepted = client.get("/admin/stats", headers={"X-Admin-Key": "test-key"})
    assert denied.status_code == 401
    assert accepted.status_code == 200
    assert "calls" in accepted.json()


def test_non_development_demo_routes_require_separate_demo_key(monkeypatch):
    monkeypatch.setattr(security, "get_settings", lambda: SimpleNamespace(
        app_env="production", admin_api_key="admin-key", demo_api_key="demo-key"))
    with TestClient(app) as client:
        denied = client.post("/call/start", json={})
        accepted = client.post("/call/start", json={}, headers={"X-Demo-Key": "demo-key"})
    assert denied.status_code == 401
    assert accepted.status_code == 200
    assert accepted.json()["call_id"]
