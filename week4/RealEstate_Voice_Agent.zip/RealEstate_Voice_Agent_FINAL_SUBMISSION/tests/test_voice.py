from types import SimpleNamespace

import httpx
import pytest
from fastapi.testclient import TestClient

from app import voice
from app.main import app


@pytest.fixture
def client():
    with TestClient(app) as test_client:
        yield test_client


def config(**overrides):
    values = {
        "stt_provider": "browser", "deepgram_api_key": "", "deepgram_model": "nova-3",
        "tts_provider": "browser", "fish_audio_api_key": "", "fish_audio_model": "s2.1-pro-free",
        "fish_audio_voice_id": "",
    }
    values.update(overrides)
    return SimpleNamespace(**values)


def test_demo_page_and_offline_voice_status(client, monkeypatch):
    monkeypatch.setattr(voice, "get_settings", lambda: config())
    page = client.get("/demo")
    assert page.status_code == 200
    assert "UrduLish Property Voice Demo" in page.text
    status = client.get("/voice/status").json()
    assert status["browser_demo"] is True
    assert status["deepgram_configured"] is False
    assert status["fish_audio_configured"] is False


def test_provider_routes_fail_explicitly_without_secrets(client, monkeypatch):
    monkeypatch.setattr(voice, "get_settings", lambda: config())
    transcript = client.post("/voice/transcribe", content=b"audio", headers={"content-type": "audio/wav"})
    assert transcript.status_code == 503
    assert "STT_PROVIDER=deepgram" in transcript.json()["detail"]
    speech = client.post("/voice/speak", json={"text": "Assalam-o-Alaikum"})
    assert speech.status_code == 503
    assert "TTS_PROVIDER=fish" in speech.json()["detail"]


def test_transcribe_validates_language_and_type_before_network(client, monkeypatch):
    monkeypatch.setattr(voice, "get_settings", lambda: config(stt_provider="deepgram", deepgram_api_key="fake-test-key"))
    bad_language = client.post("/voice/transcribe?language=xx", content=b"audio", headers={"content-type": "audio/wav"})
    assert bad_language.status_code == 422
    bad_type = client.post("/voice/transcribe", content=b"audio", headers={"content-type": "text/plain"})
    assert bad_type.status_code == 415


def test_transcribe_rejects_oversized_audio(client, monkeypatch):
    monkeypatch.setattr(voice, "get_settings", lambda: config(stt_provider="deepgram", deepgram_api_key="fake-test-key"))
    monkeypatch.setattr(voice, "MAX_AUDIO_BYTES", 4)
    response = client.post("/voice/transcribe", content=b"12345", headers={"content-type": "audio/wav"})
    assert response.status_code == 413


def test_fish_speech_route_returns_audio_without_exposing_key(client, monkeypatch):
    monkeypatch.setattr(voice, "get_settings", lambda: config(tts_provider="fish", fish_audio_api_key="secret-test-key", fish_audio_voice_id="demo-voice"))

    class FakeAsyncClient:
        def __init__(self, **kwargs):
            self.kwargs = kwargs
        async def __aenter__(self):
            return self
        async def __aexit__(self, *args):
            return None
        async def post(self, url, **kwargs):
            assert url == "https://api.fish.audio/v1/tts"
            assert kwargs["headers"]["Authorization"] == "Bearer secret-test-key"
            assert kwargs["json"]["reference_id"] == "demo-voice"
            request = httpx.Request("POST", url)
            return httpx.Response(200, request=request, content=b"fake-mp3", headers={"content-type": "audio/mpeg"})

    monkeypatch.setattr(voice.httpx, "AsyncClient", FakeAsyncClient)
    response = client.post("/voice/speak", json={"text": "Ji bilkul"})
    assert response.status_code == 200
    assert response.content == b"fake-mp3"
    assert response.headers["content-type"] == "audio/mpeg"
    assert "secret-test-key" not in response.text


def test_deepgram_transcribe_route_uses_uploaded_bytes(client, monkeypatch):
    monkeypatch.setattr(voice, "get_settings", lambda: config(stt_provider="deepgram", deepgram_api_key="secret-test-key"))

    class FakeAsyncClient:
        def __init__(self, **kwargs):
            pass
        async def __aenter__(self):
            return self
        async def __aexit__(self, *args):
            return None
        async def post(self, url, **kwargs):
            assert url == "https://api.deepgram.com/v1/listen"
            assert kwargs["content"] == b"sample-audio"
            assert kwargs["params"]["language"] == "ur"
            request = httpx.Request("POST", url)
            return httpx.Response(200, request=request, json={"results":{"channels":[{"alternatives":[{"transcript":"DHA Lahore mein ghar chahiye","confidence":0.91}]}]}})

    monkeypatch.setattr(voice.httpx, "AsyncClient", FakeAsyncClient)
    response = client.post("/voice/transcribe?language=ur", content=b"sample-audio", headers={"content-type":"audio/webm"})
    assert response.status_code == 200
    assert response.json() == {"text":"DHA Lahore mein ghar chahiye", "confidence":0.91, "provider":"deepgram", "language":"ur"}
