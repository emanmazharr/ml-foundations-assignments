# RealEstate Hub - Company Overview

## Who we are
RealEstate Hub is a Pakistani real estate advisory firm serving buyers, renters and investors in Lahore, Karachi and Islamabad. The firm lists residential and commercial properties, arranges free property visits and supports customers through the whole purchase or rental journey.

## Services
Buying, selling, renting, investment advisory, payment-plan guidance and property visit scheduling.

## Working hours
Human sales agents: Monday to Saturday, 10:00 AM to 7:00 PM. The AI voice assistant answers calls 24/7.
