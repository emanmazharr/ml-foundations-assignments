# Developer Profile: Skyline Properties

Skyline Properties was established in 2012 and is headquartered in Islamabad. Approvals: CDA approved. Projects delivered: 9.

## Track record
Boutique developer of premium apartments in Islamabad sectors; strong resale record.
