# Developer Profile: Metro Heights Pvt Ltd

Metro Heights Pvt Ltd was established in 2015 and is headquartered in Karachi. Approvals: SBCA approved. Projects delivered: 7.

## Track record
Commercial plazas and shopping arcades in high-footfall locations.
