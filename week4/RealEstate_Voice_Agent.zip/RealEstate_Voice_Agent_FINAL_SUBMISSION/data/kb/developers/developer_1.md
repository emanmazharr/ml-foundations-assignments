# Developer Profile: Crescent Developers

Crescent Developers was established in 2004 and is headquartered in Lahore. Approvals: LDA approved. Projects delivered: 18.

## Track record
Delivered 18 residential and mixed-use projects on or before the committed date; known for gated-community houses.
