# Developer Profile: Noor Builders

Noor Builders was established in 2010 and is headquartered in Karachi. Approvals: SBCA approved. Projects delivered: 11.

## Track record
Specialises in mid-range apartment towers with generator backup and secure parking.
