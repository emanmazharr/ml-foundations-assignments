# Developer Profile: Green Valley Group

Green Valley Group was established in 2008 and is headquartered in Lahore. Approvals: Society-approved layouts. Projects delivered: 14.

## Track record
Develops plots and houses inside large societies with park and mosque provisions.
