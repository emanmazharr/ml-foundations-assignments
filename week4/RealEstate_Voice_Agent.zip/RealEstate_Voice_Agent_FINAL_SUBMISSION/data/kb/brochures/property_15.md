# Property 15: 400 sq ft Shop in Johar Town, Lahore

## Overview
Property ID 15 is a shop for sale in Johar Town, Lahore. Ground-floor shop on a busy market road.
Size: 400 sq ft.
Possession: Ready.

## Amenities
Amenities: 24/7 security, covered parking.

## Developer
Developed by Metro Heights Pvt Ltd (SBCA approved). Assigned sales agent: Sana Malik.

## Investment note
Indicative rental yield estimate: 7.5% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Johar Grammar School (0.7 km); Modern Science College (1.3 km).
Hospitals nearby: Johar Care Hospital (1.1 km); Zaitoon Women Hospital (2.2 km).