# Property 8: 2-Bed Apartment in Gulberg III, Lahore

## Overview
Property ID 8 is a apartment for rent in Gulberg III, Lahore. Furnished 2-bed apartment for professionals.
Size: 1100 sq ft. Bedrooms: 2. Bathrooms: 2.
Possession: Immediate.

## Amenities
Amenities: elevator, backup generator, covered parking, 24/7 security.

## Developer
Developed by Skyline Properties (CDA approved). Assigned sales agent: Ahmed Raza.

## Nearby
Schools nearby: Lahore Model Academy (1.0 km); Gulberg Girls College (1.6 km).
Hospitals nearby: Shifa Central Hospital (1.4 km); Heart Care Institute (2.8 km).