# Property 29: 2-Bed Apartment in F-11, Islamabad

## Overview
Property ID 29 is a apartment for sale in F-11, Islamabad. Boutique apartment near F-11 Markaz.
Size: 1250 sq ft. Bedrooms: 2. Bathrooms: 2.
Possession: Ready.

## Amenities
Amenities: elevator, backup generator, 24/7 security, covered parking, gym.

## Developer
Developed by Skyline Properties (CDA approved). Assigned sales agent: Usman Tariq.

## Investment note
Indicative rental yield estimate: 5.0% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: F-11 Public School (0.8 km); Capital Grammar College (1.7 km).
Hospitals nearby: Capital Care Hospital (1.2 km); Margalla Specialist Clinic (2.0 km).