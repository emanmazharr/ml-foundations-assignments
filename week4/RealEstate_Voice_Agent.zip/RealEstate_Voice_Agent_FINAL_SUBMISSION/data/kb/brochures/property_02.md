# Property 2: 10 marla House in DHA Phase 6, Lahore

## Overview
Property ID 2 is a house for sale in DHA Phase 6, Lahore. Double-storey home with a separate servant quarter.
Size: 10 marla. Bedrooms: 4. Bathrooms: 5.
Possession: Ready.

## Amenities
Amenities: gated security, 24/7 security, park, gas, underground electricity, covered parking, jogging track.

## Developer
Developed by Crescent Developers (LDA approved). Assigned sales agent: Ahmed Raza.

## Investment note
Indicative rental yield estimate: 4.0% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Iqra Grammar School (1.2 km); City Foundation College (2.0 km).
Hospitals nearby: Meraj Care Hospital (2.5 km); Noor Children Hospital (3.4 km).