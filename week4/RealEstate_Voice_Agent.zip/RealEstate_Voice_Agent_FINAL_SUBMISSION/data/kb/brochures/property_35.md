# Property 35: 350 sq ft Shop in E-11, Islamabad

## Overview
Property ID 35 is a shop for sale in E-11, Islamabad. Shop in the busy E-11 Markaz.
Size: 350 sq ft.
Possession: Ready.

## Amenities
Amenities: 24/7 security, covered parking.

## Developer
Developed by Metro Heights Pvt Ltd (SBCA approved). Assigned sales agent: Usman Tariq.

## Investment note
Indicative rental yield estimate: 7.2% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: E-11 Model School (0.5 km); Islamabad Junior College (1.4 km).
Hospitals nearby: E-11 Family Hospital (1.0 km).