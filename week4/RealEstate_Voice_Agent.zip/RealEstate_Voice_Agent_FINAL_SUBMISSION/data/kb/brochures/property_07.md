# Property 7: 1200 sq ft Office in Gulberg III, Lahore

## Overview
Property ID 7 is a office for sale in Gulberg III, Lahore. Grade-A office floor in a busy commercial corridor.
Size: 1200 sq ft.
Possession: Ready.

## Amenities
Amenities: elevator, backup generator, covered parking, 24/7 security.

## Developer
Developed by Metro Heights Pvt Ltd (SBCA approved). Assigned sales agent: Sana Malik.

## Investment note
Indicative rental yield estimate: 7.0% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Lahore Model Academy (1.0 km); Gulberg Girls College (1.6 km).
Hospitals nearby: Shifa Central Hospital (1.4 km); Heart Care Institute (2.8 km).