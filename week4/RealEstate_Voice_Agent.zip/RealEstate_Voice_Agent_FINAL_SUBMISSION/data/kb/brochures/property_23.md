# Property 23: 3-Bed Apartment in Gulshan-e-Iqbal, Karachi

## Overview
Property ID 23 is a apartment for sale in Gulshan-e-Iqbal, Karachi. Family apartment on a high floor.
Size: 1600 sq ft. Bedrooms: 3. Bathrooms: 3.
Possession: Ready.

## Amenities
Amenities: elevator, backup generator, 24/7 security, covered parking, kids play area.

## Developer
Developed by Noor Builders (SBCA approved). Assigned sales agent: Ayesha Siddiqui.

## Investment note
Indicative rental yield estimate: 6.0% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Gulshan Public School (0.6 km); Karachi Science University Campus (2.1 km).
Hospitals nearby: Gulshan Medical Complex (0.9 km).