# Property 31: 2-Bed Apartment in F-11, Islamabad

## Overview
Property ID 31 is a apartment for rent in F-11, Islamabad. Well-maintained rental with covered parking.
Size: 1250 sq ft. Bedrooms: 2. Bathrooms: 2.
Possession: Immediate.

## Amenities
Amenities: elevator, backup generator, 24/7 security, covered parking.

## Developer
Developed by Skyline Properties (CDA approved). Assigned sales agent: Usman Tariq.

## Nearby
Schools nearby: F-11 Public School (0.8 km); Capital Grammar College (1.7 km).
Hospitals nearby: Capital Care Hospital (1.2 km); Margalla Specialist Clinic (2.0 km).