# Property 36: 8 marla House in Bahria Enclave, Islamabad

## Overview
Property ID 36 is a house for sale in Bahria Enclave, Islamabad. Quiet street, family-friendly layout.
Size: 8 marla. Bedrooms: 3. Bathrooms: 3.
Possession: Ready.

## Amenities
Amenities: gated security, 24/7 security, park, mosque, underground electricity.

## Developer
Developed by Green Valley Group (Society-approved layouts). Assigned sales agent: Hira Farooq.

## Investment note
Indicative rental yield estimate: 4.8% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Enclave Grammar School (0.9 km).
Hospitals nearby: Enclave Health Centre (1.4 km).