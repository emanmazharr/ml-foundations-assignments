# Property 39: 10 marla House in DHA Phase 2, Islamabad

## Overview
Property ID 39 is a house for sale in DHA Phase 2, Islamabad. Spacious 10 marla house near the clubhouse.
Size: 10 marla. Bedrooms: 4. Bathrooms: 4.
Possession: Ready.

## Amenities
Amenities: gated security, 24/7 security, clubhouse, park, underground electricity, gas.

## Developer
Developed by Crescent Developers (LDA approved). Assigned sales agent: Hira Farooq.

## Investment note
Indicative rental yield estimate: 4.3% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Phase 2 International School (1.3 km); DHA Junior Academy (0.9 km).
Hospitals nearby: DHA Medical Centre (1.5 km).