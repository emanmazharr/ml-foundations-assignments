# Property 32: 2-Bed Apartment in E-11, Islamabad

## Overview
Property ID 32 is a apartment for sale in E-11, Islamabad. Good rental-yield apartment near E-11 Markaz.
Size: 1000 sq ft. Bedrooms: 2. Bathrooms: 2.
Possession: Ready.

## Amenities
Amenities: elevator, backup generator, 24/7 security, covered parking.

## Developer
Developed by Skyline Properties (CDA approved). Assigned sales agent: Hira Farooq.

## Investment note
Indicative rental yield estimate: 6.2% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: E-11 Model School (0.5 km); Islamabad Junior College (1.4 km).
Hospitals nearby: E-11 Family Hospital (1.0 km).