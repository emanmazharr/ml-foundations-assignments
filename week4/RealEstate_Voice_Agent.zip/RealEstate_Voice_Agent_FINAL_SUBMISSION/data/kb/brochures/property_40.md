# Property 40: 1 kanal Plot in DHA Phase 2, Islamabad

## Overview
Property ID 40 is a plot for sale in DHA Phase 2, Islamabad. Corner 1 kanal plot on a wide road.
Size: 1 kanal.
Possession: Ready for construction.

## Amenities
Amenities: gated security, 24/7 security, clubhouse, park, underground electricity.

## Developer
Developed by Crescent Developers (LDA approved). Assigned sales agent: Usman Tariq.

## Nearby
Schools nearby: Phase 2 International School (1.3 km); DHA Junior Academy (0.9 km).
Hospitals nearby: DHA Medical Centre (1.5 km).