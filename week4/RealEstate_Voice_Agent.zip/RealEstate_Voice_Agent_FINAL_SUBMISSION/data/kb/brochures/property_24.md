# Property 24: 300 sq ft Shop in Gulshan-e-Iqbal, Karachi

## Overview
Property ID 24 is a shop for sale in Gulshan-e-Iqbal, Karachi. High-footfall shop on the main road.
Size: 300 sq ft.
Possession: Ready.

## Amenities
Amenities: 24/7 security, covered parking.

## Developer
Developed by Metro Heights Pvt Ltd (SBCA approved). Assigned sales agent: Bilal Hussain.

## Investment note
Indicative rental yield estimate: 8.0% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Gulshan Public School (0.6 km); Karachi Science University Campus (2.1 km).
Hospitals nearby: Gulshan Medical Complex (0.9 km).