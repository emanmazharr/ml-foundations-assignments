# Property 19: 3-Bed Apartment in Clifton, Karachi

## Overview
Property ID 19 is a apartment for sale in Clifton, Karachi. Sea-facing apartment with a large balcony.
Size: 2400 sq ft. Bedrooms: 3. Bathrooms: 3.
Possession: Ready.

## Amenities
Amenities: elevator, backup generator, 24/7 security, covered parking, gym, swimming pool.

## Developer
Developed by Noor Builders (SBCA approved). Assigned sales agent: Ayesha Siddiqui.

## Investment note
Indicative rental yield estimate: 4.5% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Clifton Grammar Junior (1.1 km); Harbour Girls School (1.9 km).
Hospitals nearby: Sea Breeze Hospital (1.3 km); Karachi Eye Centre (2.6 km).