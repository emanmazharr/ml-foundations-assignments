# Property 4: 10 marla Plot in DHA Phase 6, Lahore

## Overview
Property ID 4 is a plot for sale in DHA Phase 6, Lahore. Possession-ready plot on a 60-ft road.
Size: 10 marla.
Possession: Ready for construction.

## Amenities
Amenities: gated security, 24/7 security, park, underground electricity, gas.

## Developer
Developed by Green Valley Group (Society-approved layouts). Assigned sales agent: Sana Malik.

## Nearby
Schools nearby: Iqra Grammar School (1.2 km); City Foundation College (2.0 km).
Hospitals nearby: Meraj Care Hospital (2.5 km); Noor Children Hospital (3.4 km).