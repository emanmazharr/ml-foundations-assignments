# Property 13: 5 marla House in Johar Town, Lahore

## Overview
Property ID 13 is a house for sale in Johar Town, Lahore. Corner 5 marla house near the main market.
Size: 5 marla. Bedrooms: 3. Bathrooms: 3.
Possession: Ready.

## Amenities
Amenities: 24/7 security, park, gas, covered parking.

## Developer
Developed by Green Valley Group (Society-approved layouts). Assigned sales agent: Sana Malik.

## Investment note
Indicative rental yield estimate: 5.2% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Johar Grammar School (0.7 km); Modern Science College (1.3 km).
Hospitals nearby: Johar Care Hospital (1.1 km); Zaitoon Women Hospital (2.2 km).