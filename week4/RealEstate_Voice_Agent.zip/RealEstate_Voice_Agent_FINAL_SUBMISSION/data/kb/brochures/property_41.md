# Property 41: 10 marla House in DHA Phase 2, Islamabad

## Overview
Property ID 41 is a house for rent in DHA Phase 2, Islamabad. Family house for rent near the clubhouse.
Size: 10 marla. Bedrooms: 4. Bathrooms: 4.
Possession: Immediate.

## Amenities
Amenities: gated security, 24/7 security, park, underground electricity, gas.

## Developer
Developed by Crescent Developers (LDA approved). Assigned sales agent: Hira Farooq.

## Nearby
Schools nearby: Phase 2 International School (1.3 km); DHA Junior Academy (0.9 km).
Hospitals nearby: DHA Medical Centre (1.5 km).