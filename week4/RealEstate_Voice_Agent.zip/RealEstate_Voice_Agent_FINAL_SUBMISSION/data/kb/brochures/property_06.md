# Property 6: 3-Bed Apartment in Gulberg III, Lahore

## Overview
Property ID 6 is a apartment for sale in Gulberg III, Lahore. Corner unit with city views.
Size: 1750 sq ft. Bedrooms: 3. Bathrooms: 3.
Possession: Ready.

## Amenities
Amenities: elevator, backup generator, covered parking, 24/7 security, gym, swimming pool.

## Developer
Developed by Skyline Properties (CDA approved). Assigned sales agent: Ahmed Raza.

## Investment note
Indicative rental yield estimate: 5.5% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Lahore Model Academy (1.0 km); Gulberg Girls College (1.6 km).
Hospitals nearby: Shifa Central Hospital (1.4 km); Heart Care Institute (2.8 km).