# Property 25: 2-Bed Apartment in Gulshan-e-Iqbal, Karachi

## Overview
Property ID 25 is a apartment for rent in Gulshan-e-Iqbal, Karachi. Neat 2-bed apartment for small families.
Size: 1050 sq ft. Bedrooms: 2. Bathrooms: 2.
Possession: Immediate.

## Amenities
Amenities: elevator, backup generator, 24/7 security.

## Developer
Developed by Noor Builders (SBCA approved). Assigned sales agent: Ayesha Siddiqui.

## Nearby
Schools nearby: Gulshan Public School (0.6 km); Karachi Science University Campus (2.1 km).
Hospitals nearby: Gulshan Medical Complex (0.9 km).