# Property 42: 2000 sq ft Office in DHA Phase 6, Lahore

## Overview
Property ID 42 is a office for sale in DHA Phase 6, Lahore. Sky-tower office floor with a corporate lobby.
Size: 2000 sq ft.
Possession: Ready.

## Amenities
Amenities: elevator, backup generator, covered parking, 24/7 security.

## Developer
Developed by Metro Heights Pvt Ltd (SBCA approved). Assigned sales agent: Sana Malik.

## Investment note
Indicative rental yield estimate: 6.8% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Iqra Grammar School (1.2 km); City Foundation College (2.0 km).
Hospitals nearby: Meraj Care Hospital (2.5 km); Noor Children Hospital (3.4 km).