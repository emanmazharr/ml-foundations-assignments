# Property 5: 2-Bed Apartment in Gulberg III, Lahore

## Overview
Property ID 5 is a apartment for sale in Gulberg III, Lahore. Tower apartment close to the main boulevard.
Size: 1100 sq ft. Bedrooms: 2. Bathrooms: 2.
Possession: Ready.

## Amenities
Amenities: elevator, backup generator, covered parking, 24/7 security, gym.

## Developer
Developed by Skyline Properties (CDA approved). Assigned sales agent: Sana Malik.

## Investment note
Indicative rental yield estimate: 6.0% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Lahore Model Academy (1.0 km); Gulberg Girls College (1.6 km).
Hospitals nearby: Shifa Central Hospital (1.4 km); Heart Care Institute (2.8 km).