# Property 30: 3-Bed Apartment in F-11, Islamabad

## Overview
Property ID 30 is a apartment for sale in F-11, Islamabad. Spacious apartment with Margalla views.
Size: 1900 sq ft. Bedrooms: 3. Bathrooms: 3.
Possession: Ready.

## Amenities
Amenities: elevator, backup generator, 24/7 security, covered parking, gym, swimming pool.

## Developer
Developed by Skyline Properties (CDA approved). Assigned sales agent: Hira Farooq.

## Investment note
Indicative rental yield estimate: 4.6% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: F-11 Public School (0.8 km); Capital Grammar College (1.7 km).
Hospitals nearby: Capital Care Hospital (1.2 km); Margalla Specialist Clinic (2.0 km).