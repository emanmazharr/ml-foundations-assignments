# Property 14: 10 marla House in Johar Town, Lahore

## Overview
Property ID 14 is a house for sale in Johar Town, Lahore. Spacious family house.
Size: 10 marla. Bedrooms: 4. Bathrooms: 4.
Possession: Ready.

## Amenities
Amenities: 24/7 security, park, gas, covered parking.

## Developer
Developed by Green Valley Group (Society-approved layouts). Assigned sales agent: Ahmed Raza.

## Investment note
Indicative rental yield estimate: 4.4% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Johar Grammar School (0.7 km); Modern Science College (1.3 km).
Hospitals nearby: Johar Care Hospital (1.1 km); Zaitoon Women Hospital (2.2 km).