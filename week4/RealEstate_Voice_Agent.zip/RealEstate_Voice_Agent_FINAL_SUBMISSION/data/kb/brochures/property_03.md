# Property 3: 1 kanal House in DHA Phase 6, Lahore

## Overview
Property ID 3 is a house for sale in DHA Phase 6, Lahore. Luxury 1 kanal residence with a basement.
Size: 1 kanal. Bedrooms: 5. Bathrooms: 6.
Possession: Ready.

## Amenities
Amenities: gated security, 24/7 security, park, gas, underground electricity, covered parking, swimming pool.

## Developer
Developed by Crescent Developers (LDA approved). Assigned sales agent: Sana Malik.

## Investment note
Indicative rental yield estimate: 3.6% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Iqra Grammar School (1.2 km); City Foundation College (2.0 km).
Hospitals nearby: Meraj Care Hospital (2.5 km); Noor Children Hospital (3.4 km).