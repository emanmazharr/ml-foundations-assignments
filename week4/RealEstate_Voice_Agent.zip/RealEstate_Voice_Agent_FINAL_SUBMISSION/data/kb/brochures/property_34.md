# Property 34: 3-Bed Apartment in E-11, Islamabad

## Overview
Property ID 34 is a apartment for rent in E-11, Islamabad. Spacious rental for families.
Size: 1500 sq ft. Bedrooms: 3. Bathrooms: 3.
Possession: Immediate.

## Amenities
Amenities: elevator, backup generator, 24/7 security, covered parking.

## Developer
Developed by Skyline Properties (CDA approved). Assigned sales agent: Hira Farooq.

## Nearby
Schools nearby: E-11 Model School (0.5 km); Islamabad Junior College (1.4 km).
Hospitals nearby: E-11 Family Hospital (1.0 km).