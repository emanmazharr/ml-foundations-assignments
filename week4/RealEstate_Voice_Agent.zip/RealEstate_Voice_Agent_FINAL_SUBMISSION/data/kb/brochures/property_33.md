# Property 33: 1-Bed Apartment in E-11, Islamabad

## Overview
Property ID 33 is a apartment for sale in E-11, Islamabad. Studio-style unit for investors.
Size: 650 sq ft. Bedrooms: 1. Bathrooms: 1.
Possession: Ready.

## Amenities
Amenities: elevator, backup generator, 24/7 security.

## Developer
Developed by Skyline Properties (CDA approved). Assigned sales agent: Usman Tariq.

## Investment note
Indicative rental yield estimate: 6.8% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: E-11 Model School (0.5 km); Islamabad Junior College (1.4 km).
Hospitals nearby: E-11 Family Hospital (1.0 km).