# Property 17: 3-Bed Apartment in DHA Phase 8, Karachi

## Overview
Property ID 17 is a apartment for sale in DHA Phase 8, Karachi. Under-construction tower with sea-breeze views.
Size: 2100 sq ft. Bedrooms: 3. Bathrooms: 3.
Possession: Dec 2027.

## Amenities
Amenities: elevator, backup generator, 24/7 security, covered parking, gym, swimming pool.

## Developer
Developed by Noor Builders (SBCA approved). Assigned sales agent: Ayesha Siddiqui.

## Investment note
Indicative rental yield estimate: 5.0% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Seaview Grammar School (1.5 km); Defence Junior Academy (0.9 km).
Hospitals nearby: Creek General Hospital (2.4 km).