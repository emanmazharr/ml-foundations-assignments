# Property 1: 5 marla House in DHA Phase 6, Lahore

## Overview
Property ID 1 is a house for sale in DHA Phase 6, Lahore. Modern 5 marla design with a lawn and car porch.
Size: 5 marla. Bedrooms: 3. Bathrooms: 3.
Possession: Ready.

## Amenities
Amenities: gated security, 24/7 security, park, gas, underground electricity, covered parking.

## Developer
Developed by Crescent Developers (LDA approved). Assigned sales agent: Ahmed Raza.

## Investment note
Indicative rental yield estimate: 4.2% per year (company research estimate, not a guarantee).

## Nearby
Schools nearby: Iqra Grammar School (1.2 km); City Foundation College (2.0 km).
Hospitals nearby: Meraj Care Hospital (2.5 km); Noor Children Hospital (3.4 km).