# Area Guide: Johar Town, Lahore

## About the area
Established family neighbourhood with strong resale demand, markets, universities and hospitals nearby.

## Schools
- Johar Grammar School (Primary-Matric) is 0.7 km away.
- Modern Science College (College) is 1.3 km away.

## Hospitals
- Johar Care Hospital (General & Emergency) is 1.1 km away.
- Zaitoon Women Hospital (Gynaecology) is 2.2 km away.