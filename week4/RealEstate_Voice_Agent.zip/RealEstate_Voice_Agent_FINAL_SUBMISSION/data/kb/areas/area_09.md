# Area Guide: F-11, Islamabad

## About the area
Green, upscale sector known for high-rise apartments, Markaz shopping and quick access to the Margalla side.

## Schools
- F-11 Public School (Primary-Matric) is 0.8 km away.
- Capital Grammar College (A Levels) is 1.7 km away.

## Hospitals
- Capital Care Hospital (General & Emergency) is 1.2 km away.
- Margalla Specialist Clinic (Specialist OPD) is 2.0 km away.