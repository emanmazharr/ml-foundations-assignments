# Area Guide: DHA Phase 8, Karachi

## About the area
Premium gated waterfront-adjacent community with wide roads, community clubs and controlled entry.

## Schools
- Seaview Grammar School (Primary-A Levels) is 1.5 km away.
- Defence Junior Academy (Primary) is 0.9 km away.

## Hospitals
- Creek General Hospital (General & Emergency) is 2.4 km away.