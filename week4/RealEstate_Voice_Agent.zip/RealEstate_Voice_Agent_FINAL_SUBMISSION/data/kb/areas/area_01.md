# Area Guide: DHA Phase 6, Lahore

## About the area
A well-planned, gated, premium residential phase with wide roads, parks, commercial belts and 24/7 security.

## Schools
- Iqra Grammar School (Primary-Secondary) is 1.2 km away.
- City Foundation College (Secondary-A Levels) is 2.0 km away.

## Hospitals
- Meraj Care Hospital (General & Emergency) is 2.5 km away.
- Noor Children Hospital (Paediatrics) is 3.4 km away.