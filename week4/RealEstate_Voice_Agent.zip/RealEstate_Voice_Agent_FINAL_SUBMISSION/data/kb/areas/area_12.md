# Area Guide: DHA Phase 2, Islamabad

## About the area
Secure, planned phase on the GT Road side with wide boulevards, a clubhouse and steady capital appreciation.

## Schools
- Phase 2 International School (Primary-A Levels) is 1.3 km away.
- DHA Junior Academy (Primary) is 0.9 km away.

## Hospitals
- DHA Medical Centre (General & Emergency) is 1.5 km away.