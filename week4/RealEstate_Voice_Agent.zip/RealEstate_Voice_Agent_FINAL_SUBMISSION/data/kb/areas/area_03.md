# Area Guide: Bahria Town Lahore, Lahore

## About the area
A large secure society with underground utilities, mosques, parks, a commercial hub and its own schools.

## Schools
- Bahria Garden School (Primary-Secondary) is 0.8 km away.
- Beacon Point Academy (Montessori-O Levels) is 1.5 km away.

## Hospitals
- Bahria Medical Centre (General & Emergency) is 1.8 km away.