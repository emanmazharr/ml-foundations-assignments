# Area Guide: Gulshan-e-Iqbal, Karachi

## About the area
Densely populated, well-connected family area with markets, universities and excellent value for apartments.

## Schools
- Gulshan Public School (Primary-Matric) is 0.6 km away.
- Karachi Science University Campus (University) is 2.1 km away.

## Hospitals
- Gulshan Medical Complex (General & Emergency) is 0.9 km away.