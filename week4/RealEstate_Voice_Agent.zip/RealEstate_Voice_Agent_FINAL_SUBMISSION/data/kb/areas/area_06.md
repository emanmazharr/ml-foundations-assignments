# Area Guide: Clifton, Karachi

## About the area
Karachi's iconic upscale locality with sea-facing apartments, malls, restaurants and quick access to Defence.

## Schools
- Clifton Grammar Junior (Primary-O Levels) is 1.1 km away.
- Harbour Girls School (Secondary) is 1.9 km away.

## Hospitals
- Sea Breeze Hospital (General & Emergency) is 1.3 km away.
- Karachi Eye Centre (Ophthalmology) is 2.6 km away.