# Area Guide: E-11, Islamabad

## About the area
Popular for reasonably priced apartments, strong rental demand from professionals and a busy commercial Markaz.

## Schools
- E-11 Model School (Primary-Matric) is 0.5 km away.
- Islamabad Junior College (College) is 1.4 km away.

## Hospitals
- E-11 Family Hospital (General & Emergency) is 1.0 km away.