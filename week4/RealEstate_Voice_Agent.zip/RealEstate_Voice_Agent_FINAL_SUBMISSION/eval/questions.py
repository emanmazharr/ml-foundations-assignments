"""Ground-truth question sets.

EVAL_QUESTIONS  - the 20 hallucination-evaluation questions (Day 2, Task 5).
RETRIEVAL_EXTRA - extra retrieval-only questions to make the chunk-size experiment statistically meaningful.

Fields
  q               caller question (mixed English / Roman-Urdu, like real callers)
  route           expected retrieval path: rag | sql | sql_search
  sources         acceptable gold source(s) - doc path for rag, "sql:properties" for sql
  must            lower-case facts the answer must contain to be *correct*
  abstain         True when the KB does NOT contain the answer -> agent must refuse to guess
"""

EVAL_QUESTIONS = [
    # ---- semantic / RAG (10) ----
    dict(q="Are property visits free and what are the timings?", route="rag", sources=["faqs/faq_00", "faqs/faq_01"], must=["free", "10:00"]),
    dict(q="Bahria Town Lahore mein schools kahan hain?", route="rag", sources=["areas/area_03.md"], must=["bahria garden school"]),
    dict(q="Which hospitals are near Clifton?", route="rag", sources=["areas/area_06.md"], must=["sea breeze hospital"]),
    dict(q="Tell me about Crescent Developers track record", route="rag", sources=["developers/developer_1.md"], must=["18"]),
    dict(q="Overseas Pakistani ke liye purchase ka kya process hai?", route="rag", sources=["faqs/faq_05", "faqs/faq_04"], must=["power of attorney"]),
    dict(q="What amenities does property 10 have?", route="rag", sources=["brochures/property_10.md"], must=["school in society"]),
    dict(q="Property 30 mein swimming pool hai kya?", route="rag", sources=["brochures/property_30.md"], must=["swimming pool"]),
    dict(q="Rental process kya hai, security deposit kitna hota hai?", route="rag", sources=["faqs/faq_08"], must=["two months security"]),
    dict(q="Who is the developer of property 16?", route="rag", sources=["brochures/property_16.md"], must=["noor builders"]),
    dict(q="Is real estate investment guaranteed profit?", route="rag", sources=["faqs/faq_14"], must=["guaranteed"]),
    # ---- structured / SQL (7) ----
    dict(q="Property 1 ki price kya hai?", route="sql", sources=["sql:properties"], must=["3.4 crore"]),
    dict(q="Is property 14 available?", route="sql", sources=["sql:properties"], must=["sold"]),
    dict(q="Property 4 ka plot size kya hai?", route="sql", sources=["sql:properties"], must=["10 marla"]),
    dict(q="Property 9 ke agent ka naam kya hai?", route="sql", sources=["sql:properties"], must=["sana malik"]),
    dict(q="Bahria Town Lahore mein 2 crore tak ghar chahiye", route="sql_search", sources=["sql:properties"], must=["1.75 crore"]),
    dict(q="Property 11 ki installment plan kya hai?", route="sql", sources=["sql:properties"], must=["plot easy-24"]),
    dict(q="Karachi mein 4 crore tak koi apartment chahiye", route="sql_search", sources=["sql:properties"], must=["gulshan"]),
    # ---- must abstain (3) ----
    dict(q="Kya Bahria Town Lahore mein helipad hai?", route="rag", sources=[], must=[], abstain=True),
    dict(q="What is the salary of your CEO?", route="rag", sources=[], must=[], abstain=True),
    dict(q="Property 99 ki price kya hai?", route="sql", sources=[], must=[], abstain=True),
]

RETRIEVAL_EXTRA = [
    dict(q="Which schools are near F-11?", sources=["areas/area_09.md"]),
    dict(q="Gulshan-e-Iqbal mein aspatal kaunse hain?", sources=["areas/area_07.md"]),
    dict(q="Who developed property 5?", sources=["brochures/property_05.md"]),
    dict(q="Does property 6 have a swimming pool?", sources=["brochures/property_06.md"]),
    dict(q="Skyline Properties ke approvals kya hain?", sources=["developers/developer_3.md"]),
    dict(q="How many projects has Green Valley Group delivered?", sources=["developers/developer_4.md"]),
    dict(q="What is the token amount to reserve a property?", sources=["faqs/faq_03"]),
    dict(q="Can I get a home loan from a bank?", sources=["faqs/faq_10"]),
    dict(q="Is the legal title verified before listing?", sources=["faqs/faq_11"]),
    dict(q="Do you sell commercial shops and offices?", sources=["faqs/faq_18"]),
    dict(q="How can I speak to a human agent?", sources=["faqs/faq_21"]),
    dict(q="Apartment maintenance charges kya hote hain?", sources=["faqs/faq_15"]),
    dict(q="Bahria Enclave ka area kaisa hai?", sources=["areas/area_11.md"]),
    dict(q="Which agent handles property 40?", sources=["brochures/property_40.md"]),
    dict(q="What is your company commission?", sources=["faqs/faq_07"]),
]
