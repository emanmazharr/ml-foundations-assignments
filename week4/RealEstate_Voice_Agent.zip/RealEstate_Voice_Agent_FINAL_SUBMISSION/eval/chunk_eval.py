"""Chunk-size experiment (Day 2, Task 2).

Rebuilds the index for several chunk sizes and measures retrieval quality on
HELD-OUT questions (RETRIEVAL_EXTRA were never used while tuning the pipeline)
plus the RAG-route questions of the main eval set.

Metrics: Hit@1, Hit@k (k=4), MRR at document level, chunk count, mean chunk length.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.rag.retriever import Retriever  # noqa: E402
from eval.questions import EVAL_QUESTIONS, RETRIEVAL_EXTRA  # noqa: E402

SIZES = [200, 350, 600, 900, 1400]


def evaluate(size: int, overlap_ratio: float = 0.15, k: int = 4) -> dict:
    r = Retriever.build(chunk_size=size, overlap=int(size * overlap_ratio), backend="numpy", persist=False)
    heldout = [(x["q"], x["sources"]) for x in RETRIEVAL_EXTRA]
    main = [(x["q"], x["sources"]) for x in EVAL_QUESTIONS if x["route"] == "rag" and not x.get("abstain")]
    res = {}
    for name, qs in (("heldout", heldout), ("main_rag", main)):
        h1 = hk = rr = 0.0
        for q, gold in qs:
            docs: list[str] = []
            for h in r.retrieve(q, k=k * 3):       # doc-level ranking (dedupe chunks of same doc)
                if h.source not in docs:
                    docs.append(h.source)
            docs = docs[:k]
            ranks = [docs.index(g) + 1 for g in gold if g in docs]
            if ranks:
                best = min(ranks)
                hk += 1; rr += 1 / best; h1 += best == 1
        n = len(qs)
        res[name] = dict(hit1=round(h1 / n, 3), hitk=round(hk / n, 3), mrr=round(rr / n, 3), n=n)
    lens = [len(c.text) for c in r.store.chunks]
    return dict(chunk_size=size, overlap=int(size * overlap_ratio), n_chunks=len(lens),
                mean_len=round(sum(lens) / len(lens)), **{f"{a}_{b}": v for a, d in res.items() for b, v in d.items()})


def main():
    rows = [evaluate(s) for s in SIZES]
    print(f"{'size':>5} {'chunks':>6} {'meanLen':>7} | {'held Hit@1':>10} {'Hit@4':>6} {'MRR':>6} | {'main Hit@1':>10} {'Hit@4':>6} {'MRR':>6}")
    for r in rows:
        print(f"{r['chunk_size']:>5} {r['n_chunks']:>6} {r['mean_len']:>7} | {r['heldout_hit1']:>10} {r['heldout_hitk']:>6} {r['heldout_mrr']:>6} | {r['main_rag_hit1']:>10} {r['main_rag_hitk']:>6} {r['main_rag_mrr']:>6}")
    out = Path(__file__).parent / "results"; out.mkdir(exist_ok=True)
    (out / "chunk_eval.json").write_text(json.dumps(rows, indent=2))
    md = ["# Chunk-size Experiment", "", "| Chunk size | Overlap | Chunks | Mean len | Held-out Hit@1 | Held-out Hit@4 | Held-out MRR | Main Hit@1 | Main Hit@4 | Main MRR |", "|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r['chunk_size']} | {r['overlap']} | {r['n_chunks']} | {r['mean_len']} | {r['heldout_hit1']} | {r['heldout_hitk']} | {r['heldout_mrr']} | {r['main_rag_hit1']} | {r['main_rag_hitk']} | {r['main_rag_mrr']} |")
    (out / "chunk_eval.md").write_text("\n".join(md))


if __name__ == "__main__":
    main()
