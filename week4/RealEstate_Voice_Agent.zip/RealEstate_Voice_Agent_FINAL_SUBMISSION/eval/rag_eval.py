"""Hallucination evaluation (Day 2, Task 5).

Metrics
  Retrieval Accuracy : right route AND gold source/fact retrieved (answerable questions)
  Answer Accuracy    : answer contains the expected facts
  Grounding Rate     : answered responses whose every sentence + number is supported by retrieved context
  Hallucination Rate : questions where the system asserted something unsupported / wrong,
                       or answered when the KB had no answer  (LOWER IS BETTER)
  Abstention Rate    : correct refusals on unanswerable questions
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import engine  # noqa: E402
from app.rag.generator import _content_tokens  # noqa: E402
from eval.questions import EVAL_QUESTIONS  # noqa: E402

_NUM = re.compile(r"\d[\d,]*(?:\.\d+)?")


def _norm_nums(text: str) -> set[str]:
    return {n.replace(",", "") for n in _NUM.findall(text)}


def is_grounded(answer: str, context: list[str], thresh: float = 0.75) -> bool:
    """Every number in the answer must appear in context; every sentence must be >=75% token-supported."""
    ctx_text = " ".join(context)
    if not _norm_nums(answer) <= _norm_nums(ctx_text):
        return False
    ctx_tok = _content_tokens(ctx_text)
    for sent in re.split(r"(?<=[.!?])\s+", answer):
        st = _content_tokens(sent)
        if st and len(st & ctx_tok) / len(st) < thresh:
            return False
    return True


def run(verbose: bool = True) -> dict:
    rows = []
    for item in EVAL_QUESTIONS:
        out = engine.ask(item["q"])
        ans, abst = out["answer"], out["abstained"]
        should_abstain = item.get("abstain", False)
        low = ans.lower()
        correct = (not should_abstain) and (not abst) and all(m in low for m in item["must"])
        if should_abstain:
            retrieval_ok = None
        elif item["route"] in ("sql", "sql_search"):
            retrieval_ok = out["route"] == item["route"] and all(m in " ".join(out["context"]).lower() for m in item["must"])
        else:
            retrieval_ok = out["route"] == "rag" and any(s in item["sources"] for s in out["sources"])
        grounded = None if abst else is_grounded(ans, out.get("context", []))
        hallucinated = (
            (should_abstain and not abst)                 # answered a question with no KB answer
            or (not abst and grounded is False)           # unsupported claim / number
            or (not should_abstain and not abst and not correct)   # confident but wrong
        )
        rows.append(dict(q=item["q"], route=out["route"], abstained=abst, should_abstain=should_abstain,
                         retrieval_ok=retrieval_ok, correct=correct, grounded=grounded,
                         hallucinated=bool(hallucinated), answer=ans[:160], sources=out["sources"][:3]))

    answerable = [r for r in rows if not r["should_abstain"]]
    answered = [r for r in rows if not r["abstained"]]
    unans = [r for r in rows if r["should_abstain"]]
    m = {
        "n_questions": len(rows),
        "retrieval_accuracy": round(sum(bool(r["retrieval_ok"]) for r in answerable) / len(answerable), 3),
        "answer_accuracy": round(sum(r["correct"] for r in answerable) / len(answerable), 3),
        "grounding_rate": round(sum(bool(r["grounded"]) for r in answered) / max(1, len(answered)), 3),
        "hallucination_rate": round(sum(r["hallucinated"] for r in rows) / len(rows), 3),
        "correct_abstention_rate": round(sum(r["abstained"] for r in unans) / max(1, len(unans)), 3),
        "false_abstention_rate": round(sum(r["abstained"] for r in answerable) / len(answerable), 3),
    }
    if verbose:
        print(f"{'#':>2} {'route':<11} {'retr':<5} {'corr':<5} {'grnd':<5} {'hall':<5} question")
        for i, r in enumerate(rows, 1):
            f = lambda v: "-" if v is None else ("Y" if v else "N")
            print(f"{i:>2} {r['route']:<11} {f(r['retrieval_ok']):<5} {f(r['correct']):<5} {f(r['grounded']):<5} {f(r['hallucinated']):<5} {r['q']}")
        print("\n" + json.dumps(m, indent=2))
    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "rag_eval.json").write_text(
        json.dumps({"metrics": m, "rows": rows}, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    md = ["# RAG Hallucination Evaluation", "", "| Metric | Value |", "|---|---|"]
    md += [f"| {k.replace('_', ' ').title()} | {v} |" for k, v in m.items()]
    md += ["", "| # | Route | Retrieval | Correct | Grounded | Hallucinated | Question |", "|---|---|---|---|---|---|---|"]
    for i, r in enumerate(rows, 1):
        f = lambda v: "-" if v is None else ("✅" if v else "❌")
        md.append(f"| {i} | {r['route']} | {f(r['retrieval_ok'])} | {f(r['correct'])} | {f(r['grounded'])} | {'❌' if r['hallucinated'] else '✅'} | {r['q']} |")
    (out_dir / "rag_eval.md").write_text("\n".join(md), encoding="utf-8")
    return m


if __name__ == "__main__":
    run()
