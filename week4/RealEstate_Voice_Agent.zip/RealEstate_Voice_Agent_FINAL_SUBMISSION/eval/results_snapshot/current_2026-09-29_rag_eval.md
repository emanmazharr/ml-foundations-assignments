# RAG Hallucination Evaluation

| Metric | Value |
|---|---|
| N Questions | 20 |
| Retrieval Accuracy | 1.0 |
| Answer Accuracy | 1.0 |
| Grounding Rate | 1.0 |
| Hallucination Rate | 0.0 |
| Correct Abstention Rate | 1.0 |
| False Abstention Rate | 0.0 |

| # | Route | Retrieval | Correct | Grounded | Hallucinated | Question |
|---|---|---|---|---|---|---|
| 1 | rag | ✅ | ✅ | ✅ | ✅ | Are property visits free and what are the timings? |
| 2 | rag | ✅ | ✅ | ✅ | ✅ | Bahria Town Lahore mein schools kahan hain? |
| 3 | rag | ✅ | ✅ | ✅ | ✅ | Which hospitals are near Clifton? |
| 4 | rag | ✅ | ✅ | ✅ | ✅ | Tell me about Crescent Developers track record |
| 5 | rag | ✅ | ✅ | ✅ | ✅ | Overseas Pakistani ke liye purchase ka kya process hai? |
| 6 | rag | ✅ | ✅ | ✅ | ✅ | What amenities does property 10 have? |
| 7 | rag | ✅ | ✅ | ✅ | ✅ | Property 30 mein swimming pool hai kya? |
| 8 | rag | ✅ | ✅ | ✅ | ✅ | Rental process kya hai, security deposit kitna hota hai? |
| 9 | rag | ✅ | ✅ | ✅ | ✅ | Who is the developer of property 16? |
| 10 | rag | ✅ | ✅ | ✅ | ✅ | Is real estate investment guaranteed profit? |
| 11 | sql | ✅ | ✅ | ✅ | ✅ | Property 1 ki price kya hai? |
| 12 | sql | ✅ | ✅ | ✅ | ✅ | Is property 14 available? |
| 13 | sql | ✅ | ✅ | ✅ | ✅ | Property 4 ka plot size kya hai? |
| 14 | sql | ✅ | ✅ | ✅ | ✅ | Property 9 ke agent ka naam kya hai? |
| 15 | sql_search | ✅ | ✅ | ✅ | ✅ | Bahria Town Lahore mein 2 crore tak ghar chahiye |
| 16 | sql | ✅ | ✅ | ✅ | ✅ | Property 11 ki installment plan kya hai? |
| 17 | sql_search | ✅ | ✅ | ✅ | ✅ | Karachi mein 4 crore tak koi apartment chahiye |
| 18 | rag | - | ❌ | - | ✅ | Kya Bahria Town Lahore mein helipad hai? |
| 19 | rag | - | ❌ | - | ✅ | What is the salary of your CEO? |
| 20 | sql | - | ❌ | - | ✅ | Property 99 ki price kya hai? |