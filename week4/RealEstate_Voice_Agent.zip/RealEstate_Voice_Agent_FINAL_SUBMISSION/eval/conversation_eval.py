"""Runs every scenario in conversations.py through the REAL LangGraph agent
(Day 6, Task 1 + Task 3 latency/success metrics). No mocking of business logic -
only the LLM provider depends on your .env (mock by default, so this is fully offline).

Usage:  python eval/conversation_eval.py
"""
from __future__ import annotations

import json
import sys
import time
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import os
os.environ.setdefault("DATABASE_URL", f"sqlite:///{Path(__file__).resolve().parent}/eval_isolated.db")
os.environ.setdefault("CALENDAR_MODE", "mock")
os.environ.setdefault("EMAIL_MODE", "mock")
os.environ.setdefault("OUTBOX_DIR", str(Path(__file__).resolve().parent / "eval_outbox"))

from app import timeutil  # noqa: E402
from app.agent.session import CallSession  # noqa: E402
from app.services import appointments as ap, crm  # noqa: E402
from eval.conversations import CONVERSATIONS  # noqa: E402
from scripts.build_kb import main as build_kb  # noqa: E402

TZ = ZoneInfo("Asia/Karachi")


def _reset_operational_tables() -> None:
    """Each conversation must be independent - one caller's booking must never block another's
    identical request in a different scenario. Keep properties/areas/agents/etc (built once); wipe
    calls, messages, appointments, follow-ups, node_events, outbox and customers between scenarios."""
    from sqlalchemy import text
    from app.db import conn
    with conn() as c:
        for t in ("appointments", "follow_ups", "messages", "calls", "node_events", "outbox", "customers"):
            c.execute(text(f"DELETE FROM {t}"))


def _run_one(sc: dict) -> dict:
    _reset_operational_tables()
    timeutil.freeze(datetime(2026, 9, 24, 11, 0, tzinfo=TZ))  # fixed clock: Thursday 11:00 (deterministic slot math)
    if sc.get("pre_prefs"):
        crm.upsert_customer(sc["phone"], name=sc.get("pre_name"))
        crm.save_preferences(sc["phone"], sc["pre_prefs"])
    s = CallSession(caller_phone=sc["phone"])
    lat = []
    replies = [s.greet()]
    t_node_errors = 0
    for turn in sc["turns"]:
        t0 = time.perf_counter()
        replies.append(s.say(turn))
        lat.append((time.perf_counter() - t0) * 1000)
    for ev in s.trace():
        if ev["detail"].get("error"):
            t_node_errors += 1
    st = s.state()
    last = replies[-1].lower()
    all_text = " ".join(replies).lower()
    checks, results, ok = sc["checks"], {}, True

    def fail(k, msg):
        nonlocal ok
        results[k] = f"FAIL: {msg}"; ok = False

    if "outcome" in checks:
        got = st.get("outcome")
        (results.__setitem__("outcome", "OK") if got == checks["outcome"] else fail("outcome", f"expected {checks['outcome']!r} got {got!r}"))
    if "booked" in checks:
        is_booked = bool(st.get("appointment") and st["appointment"].get("status") in ("booked", "rescheduled"))
        (results.__setitem__("booked", "OK") if is_booked == checks["booked"] else fail("booked", f"expected {checks['booked']} got {is_booked}"))
    if "escalated" in checks:
        (results.__setitem__("escalated", "OK") if bool(st.get("escalated")) == checks["escalated"] else fail("escalated", f"got {st.get('escalated')}"))
    if "ended" in checks:
        (results.__setitem__("ended", "OK") if bool(s.ended) == checks["ended"] else fail("ended", f"got {s.ended}"))
    if "contains" in checks:
        missing = [w for w in checks["contains"] if w.lower() not in all_text]
        (results.__setitem__("contains", "OK") if not missing else fail("contains", f"missing {missing} anywhere in the call"))
    if "not_contains" in checks:
        found = [w for w in checks["not_contains"] if w.lower() in all_text]
        (results.__setitem__("not_contains", "OK") if not found else fail("not_contains", f"forbidden text leaked: {found}"))
    if "min_turns" in checks:
        (results.__setitem__("min_turns", "OK") if len(sc["turns"]) >= checks["min_turns"] and len(replies) >= checks["min_turns"] else fail("min_turns", f"only {len(replies)} replies"))
    if t_node_errors:
        fail("node_errors", f"{t_node_errors} node(s) crashed and fell back")

    timeutil.freeze(None)
    return dict(name=sc["name"], category=sc["category"], ok=ok, results=results,
               n_turns=len(sc["turns"]), avg_latency_ms=round(sum(lat) / max(1, len(lat)), 1),
               max_latency_ms=round(max(lat), 1) if lat else 0, outcome=st.get("outcome"),
               escalated=bool(st.get("escalated")), booked=bool(st.get("appointment")),
               node_errors=t_node_errors, last_reply=replies[-1][:150])


def run() -> dict:
    db_path = Path(__file__).resolve().parent / "eval_isolated.db"
    if db_path.exists():
        db_path.unlink()
    build_kb()   # fresh, isolated DB + KB -> no leakage from interactive debugging or other test runs
    rows = [_run_one(sc) for sc in CONVERSATIONS]
    n = len(rows)
    passed = sum(r["ok"] for r in rows)
    by_cat: dict[str, list] = {}
    for r in rows:
        by_cat.setdefault(r["category"], []).append(r)
    cat_summary = {c: dict(n=len(v), passed=sum(x["ok"] for x in v)) for c, v in by_cat.items()}
    booking_cats = [r for r in rows if r["category"] in ("buyer", "rental", "appointment")]
    metrics = dict(
        n_conversations=n,
        conversation_success_rate=round(passed / n, 3),
        booking_related_pass_rate=round(sum(r["ok"] for r in booking_cats) / max(1, len(booking_cats)), 3),
        security_pass_rate=round(sum(r["ok"] for r in by_cat.get("injection", [])) / max(1, len(by_cat.get("injection", []))), 3),
        avg_latency_ms=round(sum(r["avg_latency_ms"] for r in rows) / n, 1),
        p95_latency_ms=round(sorted(r["max_latency_ms"] for r in rows)[int(n * 0.95)], 1),
        node_crash_rate=round(sum(r["node_errors"] for r in rows) / n, 3),
        total_node_errors=sum(r["node_errors"] for r in rows),
    )
    out = Path(__file__).parent / "results"; out.mkdir(exist_ok=True)
    (out / "conversation_eval.json").write_text(json.dumps({"metrics": metrics, "by_category": cat_summary, "rows": rows}, indent=2, ensure_ascii=False))
    md = ["# Conversation Evaluation Suite (49 scenarios)", "", "| Metric | Value |", "|---|---|"]
    md += [f"| {k.replace('_', ' ').title()} | {v} |" for k, v in metrics.items()]
    md += ["", "| Category | Passed | Total |", "|---|---|---|"]
    md += [f"| {c} | {v['passed']} | {v['n']} |" for c, v in sorted(cat_summary.items())]
    md += ["", "| Scenario | Category | Result | Latency (avg/max ms) |", "|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r['name']} | {r['category']} | {'✅' if r['ok'] else '❌ ' + str(r['results'])} | {r['avg_latency_ms']}/{r['max_latency_ms']} |")
    (out / "conversation_eval.md").write_text("\n".join(md), encoding="utf-8")

    print(f"{passed}/{n} conversations passed ({metrics['conversation_success_rate']*100:.1f}%)")
    print(json.dumps(metrics, indent=2))
    if passed < n:
        print("\nFAILURES:")
        for r in rows:
            if not r["ok"]:
                print(f"  - {r['name']}: {r['results']}")
    return metrics


if __name__ == "__main__":
    run()
