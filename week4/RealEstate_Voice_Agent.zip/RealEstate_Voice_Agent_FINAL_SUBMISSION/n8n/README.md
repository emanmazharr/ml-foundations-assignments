# n8n Workflow — Call → Intent → Property Match → Appointment → Calendar → Email → CRM

`realestate_voice_agent.json` is importable into n8n (Import from File). It is a **thin orchestration
layer around the FastAPI backend** — all business logic (validation, availability, grounding) stays in
the Python service, so this workflow only ever calls `/call/start`, `/call/turn` and reads the result.
This is deliberate: n8n orchestrates the *business workflow* (retries, branching, notifications to ops),
while the agent itself is a single source of truth for correctness.

## Flow
```
Webhook (telephony/STT posts a turn)
   → HTTP: POST /call/turn  { call_id, text }
   → IF ended == true?
        ├─ true  → HTTP GET /call/{id}/transcript → Slack/Email "call summary" to ops
        └─ false → Respond to webhook with { response } for TTS
   → (parallel) IF response contains a booking outcome → HTTP GET /admin/stats (dashboards)
   → Error branch (any HTTP node failure) → Wait 5s → Retry (max 3) → Slack alert to on-call if still failing
```

## Nodes (see the JSON for exact config)
1. **Webhook** — receives `{call_id?, caller_phone?, text}` from the telephony/STT layer.
2. **IF: new call** — no `call_id` → `POST /call/start`; else → `POST /call/turn`.
3. **HTTP Request: /call/start | /call/turn** — calls the FastAPI backend (this IS "Intent → Property Match → Appointment → Calendar → Email → CRM Update": all of it happens server-side in one call, atomically, with the validation rules in `app/services/appointments.py`).
4. **IF: call ended** — branches to a call-summary notification (Slack/email to the sales team) vs. returning the spoken response to the caller.
5. **Error Trigger + Retry** — n8n's built-in error workflow: on any HTTP failure, wait and retry up to 3 times (matches the retry policy already implemented in `app/services/email_service.py` and `appointments.retry_pending_calendar_syncs`), then alert on-call via Slack if still failing.
6. **Cron: retry-outbox** — every 5 minutes, `POST /admin/retry-outbox` and `POST /admin/retry-calendar-sync` so a temporary Gmail/Calendar outage self-heals without a human touching it.

## Import
1. n8n → *Workflows → Import from File* → `realestate_voice_agent.json`.
2. Set the `BASE_URL` environment variable / credential to your deployed FastAPI URL (e.g. `https://your-app.up.railway.app`).
3. Set a Slack webhook credential for the alert node (optional — the workflow runs fine without it, alert node just won't fire).
