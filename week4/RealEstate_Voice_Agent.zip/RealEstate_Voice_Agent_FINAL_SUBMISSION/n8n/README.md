# n8n Workflow — Call → Intent → Property Match → Appointment → Calendar → Email → CRM

`realestate_voice_agent.json` is a supplied workflow design artifact. It calls the text-session endpoints in the FastAPI backend. It does not connect a telephone provider or turn audio into text/audio. Review each node and configure provider credentials and endpoint URLs before importing it into a live n8n instance. No live n8n execution was performed for this submission.

## Flow
```
Webhook (telephony/STT posts a turn)
   → HTTP: POST /call/turn  { call_id, text }
   → IF ended == true?
        ├─ true  → HTTP GET /call/{id}/transcript → Slack/Email "call summary" to ops
        └─ false → Respond to webhook with { response } for TTS
   → (parallel) IF response contains a booking outcome → HTTP GET /admin/stats (dashboards)
   → Error branch (any HTTP node failure) → Wait 5s → Retry (max 3) → Slack alert to on-call if still failing
```

## Nodes (see the JSON for exact config)
1. **Webhook** — receives `{call_id?, caller_phone?, text}` from the telephony/STT layer.
2. **IF: new call** — no `call_id` → `POST /call/start`; else → `POST /call/turn`.
3. **HTTP Request: /call/start | /call/turn** — calls the FastAPI backend, which may run the local agent and mock workflow services for that text turn. It is not a transaction across external calendar, email and CRM services.
4. **IF: call ended** — branches to a call-summary notification (Slack/email to the sales team) vs. returning the spoken response to the caller.
5. **Error Trigger + Retry** — intended ops workflow. Confirm the imported n8n version's error-branch/retry wiring and configure Slack credentials before relying on it. Provider retry behavior is separate from this proposed flow.
6. **Cron: retry-outbox** — every 5 minutes, `POST /admin/retry-outbox` and `POST /admin/retry-calendar-sync` so a temporary Gmail/Calendar outage self-heals without a human touching it.

## Import
1. n8n → *Workflows → Import from File* → `realestate_voice_agent.json`.
2. Set the `BASE_URL` environment variable / credential to your deployed FastAPI URL (e.g. `https://your-app.up.railway.app`).
3. Set a Slack webhook credential for the alert node (optional — the workflow runs fine without it, alert node just won't fire).
